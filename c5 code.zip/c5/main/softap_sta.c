#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "pwm.h"
#include "wifi.h"
#include "mic.h"
#include "lcd.h"

void app_main(void)
{
    pwm_init();

    tts_say("系统启动");
    vTaskDelay(pdMS_TO_TICKS(300));

    tts_say("正在初始化无线网络");

    esp_err_t ret = wifi_start(NULL);

    if (ret == ESP_OK) {
        tts_say("无线网络连接成功");
    } else {
        tts_say("无线网络连接失败");
    }

    lcd_init();
    tts_say("屏幕初始化成功");
    vTaskDelay(pdMS_TO_TICKS(300));

    while (1) {
        lcd_play_boot_animation();
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}