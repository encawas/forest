#pragma once

#include "esp_err.h"

typedef struct {
    const char *sta_ssid;
    const char *sta_password;

    const char *ap_ssid;
    const char *ap_password;
    int ap_channel;
    int ap_max_connection;
} wifi_config_app_t;

esp_err_t wifi_start(const wifi_config_app_t *config);