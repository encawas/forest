#ifndef __BOOT_ANIM_H_
#define __BOOT_ANIM_H_

#include <stdint.h>

#define BOOT_ANIM_WIDTH 240
#define BOOT_ANIM_HEIGHT 284
#define BOOT_ANIM_FRAME_COUNT 10
#define BOOT_ANIM_FRAME_SIZE 136320

extern const uint8_t boot_anim[BOOT_ANIM_FRAME_COUNT][BOOT_ANIM_FRAME_SIZE];

#endif
