#include "lcd.h"
#include "spi.h"
#include "animation.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include <stdio.h>

#define LCD_WIDTH           240
#define LCD_HEIGHT          284

#define TP_I2C_PORT         I2C_NUM_0
#define TP_SCL_GPIO         GPIO_NUM_3
#define TP_SDA_GPIO         GPIO_NUM_2
#define TP_I2C_FREQ_HZ      100000
#define TP_ADDR             0x15

#define BTN1_X1             20
#define BTN1_Y1             40
#define BTN1_X2             220
#define BTN1_Y2             125

#define BTN2_X1             20
#define BTN2_Y1             160
#define BTN2_X2             220
#define BTN2_Y2             245

static const char *TAG_TOUCH = "LCD_TOUCH";

uint8_t lcd_buf[480];

void lcd_write_cmd(uint8_t cmd)
{
    LCD_DC(0);
    spi2_write_data(&cmd , 1);
}

void lcd_write_data(uint8_t data)
{
    LCD_DC(1);
    spi2_write_data(&data , 1);    
}

void lcd_write_data16(uint16_t data)
{
    uint8_t databuf[2] = {0,0};
    databuf[0] = data >> 8;
    databuf[1] = data & 0xFF;
    LCD_DC(1);
    spi2_write_data(databuf , 2); 
}

void lcd_write_datan(uint8_t *data,uint16_t length)
{
    LCD_DC(1);
    spi2_write_data(data , length);
}

void lcd_on(void)
{
    LCD_BLK(0);
    vTaskDelay(10);
}

void lcd_off(void)
{
    LCD_BLK(1);
    vTaskDelay(10);
}

void lcd_init(void)
{
    spi2_init();

    gpio_config_t gpio_structure = {0};

    gpio_structure.intr_type = GPIO_INTR_DISABLE;
    gpio_structure.mode = GPIO_MODE_OUTPUT;
    gpio_structure.pin_bit_mask = 1ull << GPIO_NUM_26;
    gpio_structure.pull_down_en = GPIO_PULLDOWN_DISABLE;
    gpio_structure.pull_up_en = GPIO_PULLUP_ENABLE;
    gpio_config(&gpio_structure);

    gpio_structure.intr_type = GPIO_INTR_DISABLE;
    gpio_structure.mode = GPIO_MODE_OUTPUT;
    gpio_structure.pin_bit_mask = 1ull << GPIO_NUM_5;
    gpio_structure.pull_down_en = GPIO_PULLDOWN_ENABLE;
    gpio_structure.pull_up_en = GPIO_PULLUP_DISABLE;
    gpio_config(&gpio_structure);

    lcd_on();
    vTaskDelay(pdMS_TO_TICKS(100));

    // Software Reset，若没有硬件 RST，建议加这个
    lcd_write_cmd(0x01);
    vTaskDelay(pdMS_TO_TICKS(120));

    // Sleep Out
    lcd_write_cmd(0x11);
    vTaskDelay(pdMS_TO_TICKS(120));

    // Porch Setting
    lcd_write_cmd(0xB2);
    lcd_write_data(0x0C);
    lcd_write_data(0x0C);
    lcd_write_data(0x00);
    lcd_write_data(0x33);
    lcd_write_data(0x33);

    // Tearing Effect Line OFF/ON 可选
    // 如果不用 TE，可以先不写 0x35
    // lcd_write_cmd(0x35);
    // lcd_write_data(0x00);

    // Memory Data Access Control
    // 竖屏优先试 0x00 或 0x08
    // 如果颜色红蓝反了，把 0x00 改成 0x08
    lcd_write_cmd(0x36);
    lcd_write_data(0x00);

    // Interface Pixel Format: 16-bit/pixel RGB565
    lcd_write_cmd(0x3A);
    lcd_write_data(0x05);

    // Gate Control
    lcd_write_cmd(0xB7);
    lcd_write_data(0x35);

    // VCOM Setting
    lcd_write_cmd(0xBB);
    lcd_write_data(0x2D);

    // LCM Control
    lcd_write_cmd(0xC0);
    lcd_write_data(0x2C);

    // VDV and VRH Command Enable
    lcd_write_cmd(0xC2);
    lcd_write_data(0x01);

    // VRH Set
    lcd_write_cmd(0xC3);
    lcd_write_data(0x15);

    // VDV Set
    lcd_write_cmd(0xC4);
    lcd_write_data(0x20);

    // Frame Rate Control
    lcd_write_cmd(0xC6);
    lcd_write_data(0x0F);

    // Power Control
    lcd_write_cmd(0xD0);
    lcd_write_data(0xA4);
    lcd_write_data(0xA1);

    // Positive Voltage Gamma Control
    lcd_write_cmd(0xE0);
    lcd_write_data(0xD0);
    lcd_write_data(0x00);
    lcd_write_data(0x05);
    lcd_write_data(0x0E);
    lcd_write_data(0x15);
    lcd_write_data(0x0D);
    lcd_write_data(0x37);
    lcd_write_data(0x43);
    lcd_write_data(0x47);
    lcd_write_data(0x09);
    lcd_write_data(0x15);
    lcd_write_data(0x12);
    lcd_write_data(0x16);
    lcd_write_data(0x19);

    // Negative Voltage Gamma Control
    lcd_write_cmd(0xE1);
    lcd_write_data(0xD0);
    lcd_write_data(0x00);
    lcd_write_data(0x05);
    lcd_write_data(0x0D);
    lcd_write_data(0x0C);
    lcd_write_data(0x06);
    lcd_write_data(0x2D);
    lcd_write_data(0x44);
    lcd_write_data(0x40);
    lcd_write_data(0x0E);
    lcd_write_data(0x1C);
    lcd_write_data(0x18);
    lcd_write_data(0x16);
    lcd_write_data(0x19);

    // Display Inversion ON
    lcd_write_cmd(0x21);

    // Display ON
    lcd_write_cmd(0x29);
    vTaskDelay(pdMS_TO_TICKS(20));

    // Memory Write
    lcd_write_cmd(0x2C);

    lcd_clear(WHITE);
}

void lcd_set_window(uint16_t xstar,uint16_t ystar,uint16_t xend,uint16_t yend)
{
    lcd_write_cmd(0x2a);
    lcd_write_data16(xstar);
    lcd_write_data16(xend);

    lcd_write_cmd(0x2b);
    lcd_write_data16(ystar);
    lcd_write_data16(yend);

    lcd_write_cmd(0x2c);
}

void lcd_show_dot(uint16_t color)
{
    lcd_set_window(100,100,100,100);
    lcd_write_data16(color);
}

void lcd_show_line(uint16_t color)
{
    uint8_t data[2] = {0,0};
    data[0] = color >> 8;
    data[1] = color & 0xFF; 
    lcd_set_window(0,10,99,10);

    for(uint16_t i = 0; i < 100 ; i ++)
    {
        lcd_buf[2 * i] = data[0];
        lcd_buf[2 * i + 1] = data[1];
    }
    lcd_write_datan(lcd_buf,100);
}

void lcd_clear(uint16_t color)
{
    uint8_t high = color >> 8;
    uint8_t low = color & 0xFF;

    lcd_set_window(0, 0, 239, 283);

    for (uint16_t i = 0; i < 240; i++) {
        lcd_buf[2 * i] = high;
        lcd_buf[2 * i + 1] = low;
    }

    for (uint16_t y = 0; y < 284; y++) {
        lcd_write_datan(lcd_buf, 480);
    }
}

void lcd_show_picture(uint8_t *img)
{
    uint32_t total = 240 * 284 * 2;
    uint32_t offset = 0;

    lcd_set_window(0, 0, 239, 283);

    while (offset < total) {
        uint32_t len = total - offset;
        if (len > 480) {
            len = 480;
        }

        lcd_write_datan((uint8_t *)&img[offset], len);
        offset += len;
    }
}

void lcd_play_boot_animation(void)
{
    for (int i = 0; i < BOOT_ANIM_FRAME_COUNT; i++) {
        lcd_show_picture((uint8_t *)boot_anim[i]);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

static void lcd_fill_rect(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color)
{
    uint8_t high = color >> 8;
    uint8_t low = color & 0xFF;

    lcd_set_window(x1, y1, x2, y2);

    uint16_t width = x2 - x1 + 1;

    for (uint16_t i = 0; i < width; i++) {
        lcd_buf[2 * i] = high;
        lcd_buf[2 * i + 1] = low;
    }

    for (uint16_t y = y1; y <= y2; y++) {
        lcd_write_datan(lcd_buf, width * 2);
    }
}

static void lcd_draw_digit_1(uint16_t x, uint16_t y, uint16_t color)
{
    lcd_fill_rect(x + 24, y + 5, x + 34, y + 70, color);
    lcd_fill_rect(x + 14, y + 15, x + 24, y + 25, color);
    lcd_fill_rect(x + 14, y + 70, x + 44, y + 80, color);
}

static void lcd_draw_digit_2(uint16_t x, uint16_t y, uint16_t color)
{
    lcd_fill_rect(x + 5, y, x + 45, y + 10, color);
    lcd_fill_rect(x + 35, y, x + 45, y + 35, color);
    lcd_fill_rect(x + 5, y + 30, x + 45, y + 40, color);
    lcd_fill_rect(x + 5, y + 35, x + 15, y + 70, color);
    lcd_fill_rect(x + 5, y + 60, x + 45, y + 70, color);
}

static void lcd_show_touch_menu(void)
{
    lcd_clear(WHITE);

    lcd_fill_rect(BTN1_X1, BTN1_Y1, BTN1_X2, BTN1_Y2, BLUE);
    lcd_fill_rect(BTN2_X1, BTN2_Y1, BTN2_X2, BTN2_Y2, GREEN);

    lcd_draw_digit_1(95, 48, WHITE);
    lcd_draw_digit_2(95, 168, WHITE);
}

static esp_err_t tp_i2c_write_read(uint8_t reg, uint8_t *data, size_t len)
{
    return i2c_master_write_read_device(
        TP_I2C_PORT,
        TP_ADDR,
        &reg,
        1,
        data,
        len,
        pdMS_TO_TICKS(100)
    );
}

static void tp_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = TP_SDA_GPIO,
        .scl_io_num = TP_SCL_GPIO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = TP_I2C_FREQ_HZ,
    };

    ESP_ERROR_CHECK(i2c_param_config(TP_I2C_PORT, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(TP_I2C_PORT, conf.mode, 0, 0, 0));
}

static bool tp_read_point(uint16_t *x, uint16_t *y)
{
    uint8_t points = 0;

    if (tp_i2c_write_read(0x02, &points, 1) != ESP_OK) {
        return false;
    }

    if ((points & 0x0F) == 0) {
        return false;
    }

    uint8_t buf[4] = {0};

    if (tp_i2c_write_read(0x03, buf, sizeof(buf)) != ESP_OK) {
        return false;
    }

    uint16_t raw_x = ((buf[0] & 0x0F) << 8) | buf[1];
    uint16_t raw_y = ((buf[2] & 0x0F) << 8) | buf[3];

    *x = raw_x;
    *y = LCD_HEIGHT - 1 - raw_y;

    return true;
}

static int touch_hit_test(uint16_t x, uint16_t y)
{
    if (x >= BTN1_X1 && x <= BTN1_X2 && y >= BTN1_Y1 && y <= BTN1_Y2) {
        return 1;
    }

    if (x >= BTN2_X1 && x <= BTN2_X2 && y >= BTN2_Y1 && y <= BTN2_Y2) {
        return 2;
    }

    return 0;
}

void lcd_touch_menu_start(void)
{
    tp_init();
    lcd_show_touch_menu();

    int last_choice = 0;

    while (1) {
        uint16_t x = 0;
        uint16_t y = 0;

        if (tp_read_point(&x, &y)) {
            int choice = touch_hit_test(x, y);

            if (choice != 0 && choice != last_choice) {
                printf("%d\n", choice);
                last_choice = choice;
            }
        } else {
            last_choice = 0;
        }

        vTaskDelay(pdMS_TO_TICKS(50));
    }
}