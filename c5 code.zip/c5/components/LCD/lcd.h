#ifndef __MYLCD_H_
#define __MYLCD_H_

#include <stdint.h>
#include "driver/gpio.h"

#define LCD_DC(x)  x ? gpio_set_level(GPIO_NUM_26,1) : gpio_set_level(GPIO_NUM_26,0)
#define LCD_CS(x)  x ? gpio_set_level(GPIO_NUM_25,1) : gpio_set_level(GPIO_NUM_25,0)
#define LCD_BLK(x) x ? gpio_set_level(GPIO_NUM_5,1) : gpio_set_level(GPIO_NUM_5,0)

#define WHITE           0xFFFF      /* 白色 */
#define BLACK           0x0000      /* 黑色 */
#define RED             0xF800      /* 红色 */
#define GREEN           0x07E0      /* 绿色 */
#define BLUE            0x001F      /* 蓝色 */ 
#define MAGENTA         0XF81F      /* 品红色/紫红色 = BLUE + RED */
#define YELLOW          0XFFE0      /* 黄色 = GREEN + RED */
#define CYAN            0X07FF      /* 青色 = GREEN + BLUE */  
#define BROWN           0XBC40      /* 棕色 */
#define BRRED           0XFC07      /* 棕红色 */
#define GRAY            0X8430      /* 灰色 */ 
#define DARKBLUE        0X01CF      /* 深蓝色 */
#define LIGHTBLUE       0X7D7C      /* 浅蓝色 */ 
#define GRAYBLUE        0X5458      /* 灰蓝色 */ 
#define LIGHTGREEN      0X841F      /* 浅绿色 */  
#define LGRAY           0XC618      /* 浅灰色(PANNEL),窗体背景色 */ 
#define LGRAYBLUE       0XA651      /* 浅灰蓝色(中间层颜色) */ 
#define LBBLUE          0X2B12      /* 浅棕蓝色(选择条目的反色) */ 

void lcd_init(void);
void lcd_show_dot(uint16_t color);
void lcd_show_line(uint16_t color);
void lcd_clear(uint16_t color);
void lcd_show_picture(uint8_t *img);
void lcd_touch_menu_start(void);
void lcd_play_boot_animation(void);
#endif