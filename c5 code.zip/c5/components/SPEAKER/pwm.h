#ifndef __PWM_H_
#define __PWM_H_

#include <stdint.h>
#include <stddef.h>

void pwm_init(void);
void speaker_beep(uint32_t freq_hz, uint32_t duration_ms);
void speaker_play_pcm(const int16_t *pcm, size_t sample_count);
void speaker_enable(void);
void speaker_disable(void);

#endif
