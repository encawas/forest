#include "pwm.h"
#include <math.h>
#include <string.h>
#include "driver/gpio.h"
#include "driver/i2s_pdm.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_check.h"

#define PA_CTL_GPIO      GPIO_NUM_1
#define PDM_P_GPIO       GPIO_NUM_7
#define PDM_N_GPIO       GPIO_NUM_8

#define SAMPLE_RATE      16000
#define AMPLITUDE        12000
#define SPEAKER_VOLUME_GAIN  2.0f

static i2s_chan_handle_t tx_chan;

void pwm_init(void)
{
    gpio_config_t gpio_cfg = {
        .pin_bit_mask = (1ULL << PA_CTL_GPIO) | (1ULL << PDM_N_GPIO),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&gpio_cfg));

    gpio_set_level(PDM_N_GPIO, 0);
    gpio_set_level(PA_CTL_GPIO, 1);
    gpio_set_level(PA_CTL_GPIO, 0);
    vTaskDelay(pdMS_TO_TICKS(200));

    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_AUTO, I2S_ROLE_MASTER);
    ESP_ERROR_CHECK(i2s_new_channel(&chan_cfg, &tx_chan, NULL));

    i2s_pdm_tx_config_t pdm_cfg = {
        .clk_cfg = I2S_PDM_TX_CLK_DEFAULT_CONFIG(SAMPLE_RATE),
        .slot_cfg = I2S_PDM_TX_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .clk = I2S_GPIO_UNUSED,
            .dout = PDM_P_GPIO,
            .invert_flags = {
                .clk_inv = false,
            },
        },
    };

    ESP_ERROR_CHECK(i2s_channel_init_pdm_tx_mode(tx_chan, &pdm_cfg));
    ESP_ERROR_CHECK(i2s_channel_enable(tx_chan));
}

void speaker_beep(uint32_t freq_hz, uint32_t duration_ms)
{
    speaker_enable();
    int16_t samples[256];
    size_t bytes_written = 0;
    uint32_t total_samples = SAMPLE_RATE * duration_ms / 1000;
    uint32_t written_samples = 0;

    while (written_samples < total_samples) {
        uint32_t block_samples = 256;

        if (total_samples - written_samples < block_samples) {
            block_samples = total_samples - written_samples;
        }

        for (uint32_t i = 0; i < block_samples; i++) {
            float t = (float)(written_samples + i) / SAMPLE_RATE;
            samples[i] = (int16_t)(AMPLITUDE * sinf(2.0f * 3.1415926f * freq_hz * t));
        }

        ESP_ERROR_CHECK(i2s_channel_write(
            tx_chan,
            samples,
            block_samples * sizeof(int16_t),
            &bytes_written,
            portMAX_DELAY
        ));

        written_samples += block_samples;
    }

    memset(samples, 0, sizeof(samples));
    for (int i = 0; i < 8; i++) {
        ESP_ERROR_CHECK(i2s_channel_write(
            tx_chan,
            samples,
            sizeof(samples),
            &bytes_written,
            portMAX_DELAY
        ));
    }
    speaker_disable();
}

static int16_t clamp_i16(int32_t sample)
{
    if (sample > 32767) {
        return 32767;
    }

    if (sample < -32768) {
        return -32768;
    }

    return (int16_t)sample;
}

void speaker_play_pcm(const int16_t *pcm, size_t sample_count)
{
    size_t bytes_written = 0;
    size_t written_samples = 0;
    int16_t samples[512];

    while (written_samples < sample_count) {
        size_t block_samples = sample_count - written_samples;

        if (block_samples > 512) {
            block_samples = 512;
        }

        for (size_t i = 0; i < block_samples; i++) {
            samples[i] = clamp_i16((int32_t)(pcm[written_samples + i] * SPEAKER_VOLUME_GAIN));
        }

        ESP_ERROR_CHECK(i2s_channel_write(
            tx_chan,
            samples,
            block_samples * sizeof(int16_t),
            &bytes_written,
            portMAX_DELAY
        ));

        written_samples += block_samples;
    }
}

void speaker_enable(void)
{
    gpio_set_level(PA_CTL_GPIO, 1);
    vTaskDelay(pdMS_TO_TICKS(50));
}

void speaker_disable(void)
{
    int16_t silence[256] = {0};
    size_t bytes_written = 0;

    for (int i = 0; i < 8; i++) {
        ESP_ERROR_CHECK(i2s_channel_write(
            tx_chan,
            silence,
            sizeof(silence),
            &bytes_written,
            portMAX_DELAY
        ));
    }

    vTaskDelay(pdMS_TO_TICKS(50));
    gpio_set_level(PA_CTL_GPIO, 0);
}