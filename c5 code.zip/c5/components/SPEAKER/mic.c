#include <stdio.h>
#include "pwm.h"
#include "esp_tts.h"
#include "esp_tts_voice_xiaole.h"
#include "esp_partition.h"

void tts_say(const char *text)
{
    const esp_partition_t *part = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA,
        ESP_PARTITION_SUBTYPE_DATA_FAT,
        "voice_data"
    );

    if (part == NULL) {
        printf("Couldn't find voice_data partition\n");
        return;
    }

    esp_partition_mmap_handle_t mmap;
    const void *voicedata = NULL;

    esp_err_t err = esp_partition_mmap(
        part,
        0,
        part->size,
        ESP_PARTITION_MMAP_DATA,
        &voicedata,
        &mmap
    );

    if (err != ESP_OK) {
        printf("voice_data mmap failed\n");
        return;
    }

    esp_tts_voice_t *voice = esp_tts_voice_set_init(
        &esp_tts_voice_xiaole,
        (void *)voicedata
    );

    esp_tts_handle_t tts_handle = esp_tts_create(voice);

    if (esp_tts_parse_chinese(tts_handle, text)) {
        int len[1] = {0};

        speaker_enable();

        do {
            short *data = esp_tts_stream_play(tts_handle, len, 2);

            if (len[0] > 0) {
                speaker_play_pcm(data, len[0]);
            }
        } while (len[0] > 0);

        speaker_disable();
    }

    esp_tts_destroy(tts_handle);
    esp_tts_voice_set_free(voice);
    esp_partition_munmap(mmap);
}