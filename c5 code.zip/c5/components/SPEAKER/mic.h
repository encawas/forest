#ifndef __TTS_H_
#define __TTS_H_

void tts_say(const char *text);

#endif