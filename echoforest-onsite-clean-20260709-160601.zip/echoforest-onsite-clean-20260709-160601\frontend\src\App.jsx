import React, { useEffect, useMemo, useState } from 'react';

const DEFAULT_STATE = {
  mode: 'idle',
  forest_state: 'normal',
  light: null,
  noise: null,
  temp: null,
  humi: null,
  screen_line1: 'EchoForest',
  screen_line2: '准备就绪',
  rgb_mode: 'ready',
  buzzer_mode: 'none',
  message: '等待后端状态...',
  task_title: 'EchoForest 就绪',
  log: null,
  counts: {},
  device_id: null,
  button: null,
  camera_used: null,
};

const FOREST_LABELS = {
  normal: '准备就绪',
  growing: '森林成长中',
  low_light: '光线过暗',
  noisy: '环境偏吵',
  uncomfortable: '环境不适',
  completed: '学习完成',
  recovering: '休息中',
};

const SCENE_CLASS = {
  normal: 'scene-normal',
  growing: 'scene-growing',
  low_light: 'scene-low-light',
  noisy: 'scene-noisy',
  uncomfortable: 'scene-uncomfortable',
  completed: 'scene-completed',
  recovering: 'scene-recovering',
};

const RGB_DESCRIPTIONS = {
  ready: '待机灯效',
  focus: '专注灯效',
  warning_slow: '慢速提醒灯',
  warning_fast: '快速提醒灯',
  warning_soft: '柔和提醒灯',
  done: '完成提示灯',
  rest: '休息灯效',
};

const BUZZER_DESCRIPTIONS = {
  none: '无提示音',
  warning: '环境提醒音',
  short: '短提示音',
  done: '完成提示音',
};

const EMPTY_LOG_TEXT = '暂无学习日志。点击“结束学习”后，这里会显示本轮目标、用时和总结。';

async function postJson(path, body = {}) {
  const response = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error(`${path} failed with ${response.status}`);
  }
  return response.json();
}

async function getState() {
  const response = await fetch('/api/state');
  if (!response.ok) {
    throw new Error(`/api/state failed with ${response.status}`);
  }
  return response.json();
}

function normalizeState(data) {
  return {
    ...DEFAULT_STATE,
    ...data,
    light: data?.light ?? data?.device_data?.light ?? data?.latestDeviceData?.light ?? null,
    noise: data?.noise ?? data?.device_data?.noise ?? data?.latestDeviceData?.noise ?? null,
    temp: data?.temp ?? data?.device_data?.temp ?? data?.latestDeviceData?.temp ?? null,
    humi: data?.humi ?? data?.device_data?.humi ?? data?.latestDeviceData?.humi ?? null,
    counts: data?.counts ?? {},
  };
}

function formatValue(value, unit = '') {
  if (value === undefined || value === null || value === '') return '--';
  return `${value}${unit}`;
}

function sensorTone(field, value) {
  if (value === undefined || value === null) return 'sensor-idle';
  if (field === 'light') return value < 100 ? 'sensor-warn' : 'sensor-ok';
  if (field === 'noise') return value > 65 ? 'sensor-bad' : 'sensor-ok';
  if (field === 'temp') return value < 18 || value > 30 ? 'sensor-warn' : 'sensor-ok';
  if (field === 'humi') return value < 30 || value > 70 ? 'sensor-warn' : 'sensor-ok';
  return 'sensor-ok';
}

function sensorTag(field, value) {
  if (value === undefined || value === null) return '等待';
  if (field === 'light') return value < 100 ? '偏暗' : '正常';
  if (field === 'noise') return value > 65 ? '偏吵' : '安静';
  if (field === 'temp') return value < 18 || value > 30 ? '需调整' : '舒适';
  if (field === 'humi') return value < 30 || value > 70 ? '需调整' : '舒适';
  return '正常';
}

function SensorCard({ name, field, value, unit }) {
  return (
    <div className={`sensor-card ${sensorTone(field, value)}`}>
      <div className="sensor-top">
        <span className="sensor-name">{name}</span>
        <span className="sensor-tag">{sensorTag(field, value)}</span>
      </div>
      <div className="sensor-value">{formatValue(value, unit)}</div>
      <div className="sensor-key">{field}</div>
    </div>
  );
}

function renderLog(log) {
  if (!log) {
    return <div className="log-empty">{EMPTY_LOG_TEXT}</div>;
  }

  if (typeof log === 'string') {
    return <pre className="log-pre">{log}</pre>;
  }

  return (
    <div className="log-entry">
      <div className="log-goal">{log.target ?? '未设置学习目标'}</div>
      <div className="log-meta">
        <span>用时 <b>{log.duration_minutes ?? 0} 分钟</b></span>
        <span>forest_state <b>{log.forest_state ?? '--'}</b></span>
      </div>
      <div className="log-summary">{log.summary ?? JSON.stringify(log)}</div>
    </div>
  );
}

export default function App() {
  const [targetText, setTargetText] = useState('');
  const [state, setState] = useState(DEFAULT_STATE);
  const [status, setStatus] = useState('就绪');
  const [error, setError] = useState('');

  async function refreshState() {
    try {
      const nextState = await getState();
      setState(normalizeState(nextState));
      setError('');
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    refreshState();
    const timer = window.setInterval(refreshState, 3000);
    return () => window.clearInterval(timer);
  }, []);

  async function handleAction(action) {
    const endpoints = {
      start: '/api/session/start',
      end: '/api/session/end',
      recover: '/api/session/recover',
    };
    try {
      setStatus('更新中...');
      const body = action === 'start' ? { target_text: targetText } : {};
      const nextState = await postJson(endpoints[action], body);
      setState(normalizeState(nextState));
      setStatus('就绪');
      setError('');
    } catch (err) {
      setStatus('就绪');
      setError(err.message);
    }
  }

  const forestLabel = FOREST_LABELS[state.forest_state] ?? FOREST_LABELS.normal;
  const sceneClass = SCENE_CLASS[state.forest_state] ?? SCENE_CLASS.normal;
  const sessionsCompleted = state.counts?.sessions_completed ?? 0;
  const ringProgress = Math.min(100, sessionsCompleted * 20);
  const appClassName = `app-shell ${sceneClass}`;
  const rgbDescription = RGB_DESCRIPTIONS[state.rgb_mode] ?? '设备灯效';
  const buzzerDescription = BUZZER_DESCRIPTIONS[state.buzzer_mode] ?? '设备提示音';

  const heroTags = useMemo(() => ([
    ['mode', state.mode],
    ['forest_state', state.forest_state],
  ]), [state.mode, state.forest_state]);

  return (
    <main className={appClassName}>
      <div className="page">
        <header className="site-header">
          <p className="eyebrow">第一阶段控制台</p>
          <h1>EchoForest 控制台</h1>
          <p className="subtitle">输入学习目标，开始学习，并查看环境状态与本轮日志。</p>
        </header>

        <section className="hero" aria-label="森林状态概览">
          <div className="forest-scene" aria-hidden="true">
            <svg viewBox="0 0 800 260" preserveAspectRatio="xMidYMax slice">
              <defs>
                <linearGradient id="skyGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" />
                  <stop offset="100%" />
                </linearGradient>
              </defs>
              <rect className="sky" width="800" height="260" />
              <rect className="haze" width="800" height="260" />
              <circle className="moon-glow" cx="676" cy="56" r="42" />
              <circle className="moon" cx="676" cy="56" r="20" />
              {[120, 210, 300, 380, 470, 545, 600, 90].map((x, index) => (
                <circle
                  className="firefly"
                  cx={x}
                  cy={[150, 130, 165, 140, 170, 135, 175, 185][index]}
                  r={index % 2 === 0 ? 2.4 : 2}
                  key={x}
                />
              ))}
              <path className="tree-back" d="M0,205 L45,168 L85,196 L130,158 L172,192 L215,162 L258,197 L300,168 L342,200 L385,158 L428,193 L470,165 L512,198 L555,160 L598,193 L640,167 L682,202 L724,160 L766,196 L800,168 L800,260 L0,260 Z" />
              <path className="tree-mid" d="M0,225 L38,192 L78,220 L122,182 L166,218 L210,188 L252,222 L296,190 L338,224 L382,186 L424,220 L468,190 L510,222 L554,186 L596,220 L638,192 L680,224 L722,188 L764,222 L800,194 L800,260 L0,260 Z" />
              <path className="tree-front" d="M0,246 L34,214 L70,240 L110,204 L150,238 L192,208 L232,242 L274,210 L314,244 L356,206 L398,240 L440,208 L480,242 L522,206 L562,240 L604,212 L644,244 L686,208 L726,242 L766,214 L800,240 L800,260 L0,260 Z" />
            </svg>
          </div>

          <div className="hero-overlay">
            <div className="hero-top">
              <div className="status-pill">
                <span className="status-dot" />
                <span>{forestLabel}</span>
              </div>
              <div className="growth-badge">
                <div className="growth-ring" style={{ '--progress': `${ringProgress}%` }}>
                  <span>{sessionsCompleted}</span>
                </div>
                <div>
                  <div className="badge-label">森林生长度</div>
                  <div className="badge-value">{sessionsCompleted} 次专注</div>
                </div>
              </div>
            </div>

            <div className="hero-bottom">
              <h2>{state.task_title || forestLabel}</h2>
              <p>{state.message}</p>
              <div className="hero-tags">
                {heroTags.map(([key, value]) => (
                  <span className="hero-tag" key={key}>{key}: <b>{value ?? '--'}</b></span>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="dashboard-grid">
          <div className="left-column">
            <section className="panel task-panel" aria-labelledby="task-heading">
              <div className="panel-head">
                <div>
                  <h2 id="task-heading">学习任务</h2>
                  <p>输入目标，开始或结束一轮学习。</p>
                </div>
              </div>

              <label htmlFor="target-text">学习目标</label>
              <input
                id="target-text"
                value={targetText}
                onChange={(event) => setTargetText(event.target.value)}
                placeholder="例如：读完第三章并做笔记"
              />

              <div className="button-row">
                <button type="button" onClick={() => handleAction('start')}>开始学习</button>
                <button type="button" className="ghost" onClick={() => handleAction('end')}>结束学习</button>
                <button type="button" className="quiet rest-button" onClick={() => handleAction('recover')}>开始休息</button>
                <button type="button" className="ghost" onClick={refreshState}>刷新状态</button>
              </div>

              <div className="session-status">
                <span>状态</span>
                <strong>{status}</strong>
              </div>
              {error ? <p className="error-line">错误：{error}</p> : null}
            </section>

            <section className="panel device-panel" aria-labelledby="device-heading">
              <div className="panel-head">
                <div>
                  <h2 id="device-heading">设备反馈预览</h2>
                  <p>与实体设备屏幕、灯光和提示音保持一致。</p>
                </div>
              </div>

              <div className="device-row">
                <div className="device-screen">
                  <span className="line-one">{state.screen_line1 ?? '--'}</span>
                  <span className="line-two">{state.screen_line2 ?? '--'}</span>
                  <small>屏幕显示 / 两行</small>
                </div>
                <div className="device-mini device-feedback-description">
                  <span>RGB 灯效</span>
                  <div className="rgb-swatch" />
                  <strong>{state.rgb_mode ?? '--'}</strong>
                  <em>{rgbDescription}</em>
                </div>
                <div className="device-mini device-feedback-description">
                  <span>蜂鸣器</span>
                  <div className="buzzer-row"><i /> <strong>{state.buzzer_mode ?? '--'}</strong></div>
                  <em>{buzzerDescription}</em>
                </div>
              </div>
            </section>
          </div>

          <div className="right-column">
            <section className="panel sensors-panel" aria-labelledby="sensors-heading">
              <div className="panel-head">
                <div>
                  <h2 id="sensors-heading">环境数据</h2>
                  <p>来自设备上传的实时传感数据。</p>
                </div>
                <span className="device-id">device_id: {state.device_id ?? '--'}</span>
              </div>

              <div className="sensor-grid">
                <SensorCard name="光照" field="light" value={state.light} />
                <SensorCard name="噪声" field="noise" value={state.noise} />
                <SensorCard name="温度" field="temp" value={state.temp} unit="℃" />
                <SensorCard name="湿度" field="humi" value={state.humi} unit="%" />
              </div>
            </section>

            <section className="panel log-panel" aria-labelledby="log-heading">
              <div className="panel-head">
                <div>
                  <h2 id="log-heading">最新学习日志</h2>
                  <p>结束学习后自动生成本轮记录。</p>
                </div>
              </div>
              {renderLog(state.log)}
            </section>
          </div>
        </section>
      </div>
    </main>
  );
}
