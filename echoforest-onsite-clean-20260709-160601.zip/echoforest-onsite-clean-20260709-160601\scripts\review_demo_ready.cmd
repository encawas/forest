@echo off
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo === EchoForest Demo Ready Review ===
echo.

echo Running scripts\verify.cmd...
call scripts\verify.cmd
if %ERRORLEVEL% neq 0 (
  echo FAIL: scripts\verify.cmd failed
  exit /b 1
)
echo.

if not exist "docs\demo_script.md" (
  echo FAIL: missing docs\demo_script.md
  exit /b 1
)
if not exist "simulator\device_simulator.js" (
  echo FAIL: missing simulator\device_simulator.js
  exit /b 1
)
if not exist "frontend\vite.config.js" (
  echo FAIL: missing frontend\vite.config.js
  exit /b 1
)
if not exist "backend\src\app.js" (
  echo FAIL: missing backend\src\app.js
  exit /b 1
)

echo Checking demo script content...
findstr /C:"localhost:3000" docs\demo_script.md >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: demo script missing localhost:3000
  exit /b 1
)
findstr /C:"localhost:5173" docs\demo_script.md >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: demo script missing localhost:5173
  exit /b 1
)
findstr /C:"simulator\device_simulator.js" docs\demo_script.md >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: demo script missing simulator\device_simulator.js
  exit /b 1
)
findstr /C:"/api/device_data" docs\demo_script.md >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: demo script missing /api/device_data
  exit /b 1
)
findstr /C:"/api/state" docs\demo_script.md >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: demo script missing /api/state
  exit /b 1
)
echo Demo script content: OK
echo.

if exist "package-lock.json" (
  echo FAIL: package-lock.json exists at repo root
  exit /b 1
)
if exist "backend\package-lock.json" (
  echo FAIL: backend\package-lock.json exists
  exit /b 1
)
if exist "frontend\package-lock.json" (
  echo FAIL: frontend\package-lock.json exists
  exit /b 1
)
echo Lockfile check: OK
echo.

echo git status --short --untracked-files=all
git status --short --untracked-files=all
if %ERRORLEVEL% neq 0 (
  echo FAIL: git status failed
  exit /b 1
)
echo.

echo PASS
exit /b 0
