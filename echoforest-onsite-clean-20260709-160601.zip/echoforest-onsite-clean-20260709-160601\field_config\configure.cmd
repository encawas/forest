@echo off
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: Node.js is required.
  echo Please install Node.js, then run this tool again.
  exit /b 1
)

node apply_config.js --wizard
exit /b %ERRORLEVEL%
