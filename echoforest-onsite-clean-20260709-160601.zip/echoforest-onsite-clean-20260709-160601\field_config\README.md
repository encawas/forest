# EchoForest 现场配置工具

这个目录给硬件同学现场使用。目标是：现场认为哪个 IP、Wi-Fi、阈值、触摸区域合适，就直接填进去，脚本自动生成配置头文件。

不需要安装 npm 依赖，只需要电脑上有 Node.js。

## 一键入口

在项目根目录运行：

```cmd
field_config\configure.cmd
```

也可以进入目录运行：

```cmd
cd /d field_config
configure.cmd
```

## 它会生成什么

脚本会生成：

```text
field_config\generated\echoforest_field_config.h
```

这个文件包含：

- Wi-Fi SSID
- Wi-Fi password
- 后端地址
- S3 DHT11 引脚
- 光照阈值
- 噪声阈值
- 温湿度舒适范围
- C5 触摸按钮区域

## 怎么复制到 S3/C5 工程

运行菜单后选择复制到 S3 或 C5 工程，输入工程根目录，例如：

```text
D:\s3_project
D:\c5_project
```

脚本会复制到：

```text
D:\s3_project\main\echoforest_field_config.h
D:\c5_project\main\echoforest_field_config.h
```

如果目标工程没有 `main` 目录，脚本会报错，不会乱写。

## 自动改 S3 基础工程

如果使用这次收到的 S3 基础工程，可以在菜单里选择：

```text
8. Patch S3 base project DHT11/Wi-Fi config
```

它会做三件事：

1. 把生成的 `echoforest_field_config.h` 复制到：

```text
S3工程\main\
S3工程\components\dht11\
S3工程\components\WIFISTA\
```

2. 自动修改：

```text
S3工程\components\dht11\dht11.h
```

让：

```c
DHT11_DQ_GPIO_PIN
```

引用：

```c
ECHOFOREST_DHT11_PIN
```

3. 自动修改：

```text
S3工程\components\WIFISTA\wifista.h
```

让：

```c
DEFAULT_SSID
DEFAULT_PWD
```

引用：

```c
ECHOFOREST_WIFI_SSID
ECHOFOREST_WIFI_PASSWORD
```

这样现场换 Wi-Fi、改 DHT11 引脚时，不需要手动找源码里的数字。

## 现场推荐流程

1. 设置电脑后端地址，例如 `http://192.168.1.23:3000`。
2. 设置现场 Wi-Fi 名称和密码。
3. 确认 S3 DHT11 引脚，默认 `GPIO_NUM_0`。
4. 设置光照阈值。
5. 设置噪声阈值。
6. 设置温湿度范围。
7. 设置 C5 触摸区域。
8. 生成配置文件。
9. 复制到 S3/C5 工程。
10. 编译、烧录、现场测试。

## 注意

- 不要把真实 Wi-Fi 密码提交到仓库。
- ESP32 后端地址不要写 `localhost`。
- ESP32 后端地址应该是电脑局域网 IP，例如 `http://192.168.1.23:3000`。
- DHT11 默认按这次 S3 zip 的 `GPIO_NUM_0`。
- 如果现场噪声值不准，直接调 `noise_threshold`，不需要改源码。

## C5 touch helper patch

Menu option:

```text
9. Patch C5 base project touch helper
```

It writes these files into `C5_PROJECT\main`:

```text
echoforest_field_config.h
echoforest_c5_touch_bridge.h
```

After the C5 touch demo reads a point, call:

```c
int action = echoforest_field_touch_action_id(x, y);
const char *name = echoforest_field_touch_action_name(action);
```

The helper returns START, REST, END, or NONE based on the configured rectangles.
