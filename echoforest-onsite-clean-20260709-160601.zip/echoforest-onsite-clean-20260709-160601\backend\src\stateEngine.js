// EchoForest Phase 1 State Engine
// Priority: completed > recovering > low_light > noisy > uncomfortable > growing > normal

// Demo thresholds -- will be calibrated after hardware integration
const LIGHT_THRESHOLD = 100;
const NOISE_THRESHOLD = 65;
const TEMP_MIN = 18;
const TEMP_MAX = 30;
const HUMI_MIN = 30;
const HUMI_MAX = 70;

/**
 * Compute forest_state from mode and environment data.
 * Priority chain: completed -> recovering -> low_light -> noisy -> uncomfortable -> growing -> normal
 */
function computeForestState(mode, light, noise, temp, humi) {
  if (mode === 'completed') return 'completed';
  if (mode === 'rest')     return 'recovering';
  if (light !== undefined && light !== null && light < LIGHT_THRESHOLD) return 'low_light';
  if (noise !== undefined && noise !== null && noise > NOISE_THRESHOLD) return 'noisy';

  const tempOut = temp !== undefined && temp !== null && (temp < TEMP_MIN || temp > TEMP_MAX);
  const humiOut = humi !== undefined && humi !== null && (humi < HUMI_MIN || humi > HUMI_MAX);
  if (tempOut || humiOut) return 'uncomfortable';

  if (mode === 'focus') return 'growing';
  return 'normal';
}

/**
 * Display mapping per state_machine.md
 */
function getDisplayMapping(forestState) {
  const map = {
    normal:        { screen_line1: 'EchoForest',   screen_line2: '准备就绪',     rgb_mode: 'ready',        buzzer_mode: 'none' },
    growing:       { screen_line1: '专注中',       screen_line2: '森林成长中',   rgb_mode: 'focus',        buzzer_mode: 'none' },
    low_light:     { screen_line1: '光线过暗',     screen_line2: '请打开灯',     rgb_mode: 'warning_slow',  buzzer_mode: 'warning' },
    noisy:         { screen_line1: '环境偏吵',     screen_line2: '请降低噪声',   rgb_mode: 'warning_fast',  buzzer_mode: 'warning' },
    uncomfortable: { screen_line1: '环境不适',     screen_line2: '调整温湿度',   rgb_mode: 'warning_soft',  buzzer_mode: 'short' },
    completed:     { screen_line1: '学习完成',     screen_line2: '森林已成长',   rgb_mode: 'done',          buzzer_mode: 'done' },
    recovering:    { screen_line1: '休息中',       screen_line2: '放松一下',     rgb_mode: 'rest',          buzzer_mode: 'none' },
  };
  return map[forestState] || map.normal;
}

module.exports = { computeForestState, getDisplayMapping, LIGHT_THRESHOLD, NOISE_THRESHOLD, TEMP_MIN, TEMP_MAX, HUMI_MIN, HUMI_MAX };
