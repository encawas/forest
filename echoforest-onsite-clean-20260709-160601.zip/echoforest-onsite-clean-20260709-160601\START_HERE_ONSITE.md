# EchoForest 现场先看这个

这份包给现场硬件同学使用。目标是让现场自己完成配置、调参、patch S3/C5 工程和最小闭环测试，不需要项目负责人到现场。

## 先做什么

1. 打开完整流程：

```text
docs\onsite_handoff_workflow.md
```

2. 如果要看后续从软件闭环到真机闭环的任务顺序：

```text
docs\future_task_plan.md
```

3. 启动后端和前端。

4. 运行现场配置工具：

```cmd
field_config\configure.cmd
```

5. 在工具里设置：

- 电脑后端地址，例如 `http://192.168.1.23:3000`
- Wi-Fi 名称和密码
- DHT11 GPIO，默认 `0`
- 光照阈值
- 噪声阈值
- 温湿度范围
- C5 触摸区域

6. 生成配置：

```text
5. Generate echoforest_field_config.h
```

7. Patch S3：

```text
8. Patch S3 base project DHT11/Wi-Fi config
```

8. Patch C5：

```text
9. Patch C5 base project touch helper
```

## 最小成功标准

```text
C5 或网页开始学习
-> S3 上传真实 light/noise/temp/humi
-> 后端返回 forest_state
-> 网页显示真实数据
-> S3 显示后端状态
-> C5 显示后端状态
-> C5 或网页结束学习
```

## 现场调参规则

不要手改很多源码文件。重新运行：

```cmd
field_config\configure.cmd
```

然后改配置、重新生成、重新 patch。

常见情况：

- 光线过暗误报：降低 `low_light_threshold`
- 光线过暗不报：提高 `low_light_threshold`
- 噪声误报：提高 `noise_threshold`
- 噪声不报：降低 `noise_threshold`
- 触摸按钮不准：改 START / REST / END 的 x1/y1/x2/y2

## 注意

- ESP32 后端地址不要写 `localhost`。
- ESP32 后端地址必须写电脑局域网 IP。
- 不要把真实 Wi-Fi 密码提交到仓库。
- Camera recognition、完整森林动画、数据库、登录、WebSocket 都不是当前阶段目标。
