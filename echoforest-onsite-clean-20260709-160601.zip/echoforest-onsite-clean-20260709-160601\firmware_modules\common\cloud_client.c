#include "cloud_client.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "cJSON.h"
#include "esp_err.h"
#include "esp_http_client.h"
#include "esp_log.h"

/*
 * EchoForest reusable ESP-IDF cloud client skeleton.
 * Copy this module into the real S3/C5 ESP-IDF projects and wire CMake include
 * paths/components there. Backend URL must come from local config, not source.
 *
 * Backend paths used through protocol constants:
 * /api/device_data
 * /api/state
 * /api/session/start
 * /api/session/end
 * /api/session/recover
 */

typedef struct {
    char *data;
    int capacity;
    int length;
} response_buffer_t;

static const char *TAG = "echoforest_cloud";
static cloud_client_config_t s_config;

static void copy_string(char *dst, size_t dst_size, const char *src)
{
    if (dst == NULL || dst_size == 0) {
        return;
    }
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    strlcpy(dst, src, dst_size);
}

static void reset_state(echoforest_state_t *state)
{
    if (state != NULL) {
        memset(state, 0, sizeof(*state));
    }
}

static esp_err_t build_url(const char *path, char *out, size_t out_size)
{
    if (path == NULL || out == NULL || out_size == 0 || s_config.base_url[0] == '\0') {
        return ESP_ERR_INVALID_STATE;
    }

    int written = snprintf(out, out_size, "%s%s", s_config.base_url, path);
    if (written < 0 || (size_t)written >= out_size) {
        return ESP_ERR_INVALID_SIZE;
    }
    return ESP_OK;
}

static esp_err_t http_event_handler(esp_http_client_event_t *evt)
{
    if (evt->event_id != HTTP_EVENT_ON_DATA || evt->user_data == NULL || evt->data == NULL) {
        return ESP_OK;
    }

    response_buffer_t *buffer = (response_buffer_t *)evt->user_data;
    int available = buffer->capacity - buffer->length - 1;
    int copy_len = evt->data_len < available ? evt->data_len : available;
    if (copy_len > 0) {
        memcpy(buffer->data + buffer->length, evt->data, copy_len);
        buffer->length += copy_len;
        buffer->data[buffer->length] = '\0';
    }

    return ESP_OK;
}

static void parse_string_field(cJSON *json, const char *name, char *dst, size_t dst_size)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, name);
    if (cJSON_IsString(item) && item->valuestring != NULL) {
        copy_string(dst, dst_size, item->valuestring);
    }
}

static float parse_float_field(cJSON *json, const char *name)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, name);
    return cJSON_IsNumber(item) ? (float)item->valuedouble : 0.0f;
}

static int parse_int_field(cJSON *json, const char *name)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, name);
    return cJSON_IsNumber(item) ? item->valueint : 0;
}

static bool parse_bool_field(cJSON *json, const char *name)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, name);
    return cJSON_IsBool(item) ? cJSON_IsTrue(item) : false;
}

static esp_err_t parse_state_json(const char *body, echoforest_state_t *out_state)
{
    if (body == NULL || out_state == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    reset_state(out_state);
    cJSON *json = cJSON_Parse(body);
    if (json == NULL) {
        ESP_LOGE(TAG, "failed to parse backend response JSON");
        return ESP_FAIL;
    }

    parse_string_field(json, "mode", out_state->mode, sizeof(out_state->mode));
    parse_string_field(json, "forest_state", out_state->forest_state, sizeof(out_state->forest_state));
    parse_string_field(json, "screen_line1", out_state->screen_line1, sizeof(out_state->screen_line1));
    parse_string_field(json, "screen_line2", out_state->screen_line2, sizeof(out_state->screen_line2));
    parse_string_field(json, "rgb_mode", out_state->rgb_mode, sizeof(out_state->rgb_mode));
    parse_string_field(json, "buzzer_mode", out_state->buzzer_mode, sizeof(out_state->buzzer_mode));
    parse_string_field(json, "message", out_state->message, sizeof(out_state->message));
    parse_string_field(json, "task_title", out_state->task_title, sizeof(out_state->task_title));
    parse_string_field(json, "device_id", out_state->device_id, sizeof(out_state->device_id));

    out_state->light = parse_float_field(json, "light");
    out_state->noise = parse_float_field(json, "noise");
    out_state->temp = parse_float_field(json, "temp");
    out_state->humi = parse_float_field(json, "humi");
    out_state->button = parse_int_field(json, "button");
    out_state->camera_used = parse_bool_field(json, "camera_used");

    cJSON *counts = cJSON_GetObjectItemCaseSensitive(json, "counts");
    if (cJSON_IsObject(counts)) {
        out_state->sessions_completed = parse_int_field(counts, "sessions_completed");
    }

    cJSON_Delete(json);
    return ESP_OK;
}

static esp_err_t perform_request(
    esp_http_client_method_t method,
    const char *path,
    const char *body,
    echoforest_state_t *out_state
)
{
    char url[192];
    esp_err_t err = build_url(path, url, sizeof(url));
    if (err != ESP_OK) {
        return err;
    }

    char response[1024] = { 0 };
    response_buffer_t response_buffer = {
        .data = response,
        .capacity = sizeof(response),
        .length = 0,
    };

    esp_http_client_config_t config = {
        .url = url,
        .method = method,
        .event_handler = http_event_handler,
        .user_data = &response_buffer,
        .timeout_ms = 5000,
    };

    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL) {
        return ESP_FAIL;
    }

    esp_http_client_set_header(client, "Content-Type", "application/json");
    if (body != NULL) {
        esp_http_client_set_post_field(client, body, strlen(body));
    }

    err = esp_http_client_perform(client);
    int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP request failed for %s: %s", path, esp_err_to_name(err));
        return err;
    }
    if (status < 200 || status >= 300) {
        ESP_LOGE(TAG, "HTTP request returned status %d for %s", status, path);
        return ESP_FAIL;
    }
    if (out_state == NULL) {
        return ESP_OK;
    }
    return parse_state_json(response, out_state);
}

esp_err_t cloud_client_init(const cloud_client_config_t *config)
{
    if (config == NULL || config->base_url[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    memset(&s_config, 0, sizeof(s_config));
    copy_string(s_config.base_url, sizeof(s_config.base_url), config->base_url);
    ESP_LOGI(TAG, "backend base URL configured");
    return ESP_OK;
}

esp_err_t cloud_client_post_device_data(
    const echoforest_device_data_t *device_data,
    echoforest_state_t *out_state
)
{
    if (device_data == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    cJSON *json = cJSON_CreateObject();
    if (json == NULL) {
        return ESP_ERR_NO_MEM;
    }

    cJSON_AddStringToObject(json, "device_id", device_data->device_id);
    cJSON_AddStringToObject(json, "mode", device_data->mode);
    cJSON_AddNumberToObject(json, "light", device_data->light);
    cJSON_AddNumberToObject(json, "noise", device_data->noise);
    cJSON_AddNumberToObject(json, "temp", device_data->temp);
    cJSON_AddNumberToObject(json, "humi", device_data->humi);
    cJSON_AddNumberToObject(json, "button", device_data->button);
    cJSON_AddBoolToObject(json, "camera_used", device_data->camera_used);

    char *body = cJSON_PrintUnformatted(json);
    cJSON_Delete(json);
    if (body == NULL) {
        return ESP_ERR_NO_MEM;
    }

    esp_err_t err = perform_request(
        HTTP_METHOD_POST,
        ECHOFOREST_API_DEVICE_DATA_PATH,
        body,
        out_state
    );
    cJSON_free(body);
    return err;
}

esp_err_t cloud_client_get_state(echoforest_state_t *out_state)
{
    return perform_request(HTTP_METHOD_GET, ECHOFOREST_API_STATE_PATH, NULL, out_state);
}

esp_err_t cloud_client_start_session(const char *target_text, echoforest_state_t *out_state)
{
    cJSON *json = cJSON_CreateObject();
    if (json == NULL) {
        return ESP_ERR_NO_MEM;
    }
    cJSON_AddStringToObject(json, "target_text", target_text != NULL ? target_text : "");

    char *body = cJSON_PrintUnformatted(json);
    cJSON_Delete(json);
    if (body == NULL) {
        return ESP_ERR_NO_MEM;
    }

    esp_err_t err = perform_request(
        HTTP_METHOD_POST,
        ECHOFOREST_API_SESSION_START_PATH,
        body,
        out_state
    );
    cJSON_free(body);
    return err;
}

esp_err_t cloud_client_end_session(echoforest_state_t *out_state)
{
    return perform_request(
        HTTP_METHOD_POST,
        ECHOFOREST_API_SESSION_END_PATH,
        "{}",
        out_state
    );
}

esp_err_t cloud_client_start_recovery(echoforest_state_t *out_state)
{
    return perform_request(
        HTTP_METHOD_POST,
        ECHOFOREST_API_SESSION_RECOVER_PATH,
        "{}",
        out_state
    );
}
