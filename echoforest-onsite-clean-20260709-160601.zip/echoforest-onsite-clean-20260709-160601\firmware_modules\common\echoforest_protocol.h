#ifndef ECHOFOREST_PROTOCOL_H
#define ECHOFOREST_PROTOCOL_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ECHOFOREST_MAX_DEVICE_ID_LEN 32
#define ECHOFOREST_MAX_MODE_LEN 16
#define ECHOFOREST_MAX_FOREST_STATE_LEN 32
#define ECHOFOREST_MAX_SCREEN_LINE_LEN 64
#define ECHOFOREST_MAX_FEEDBACK_MODE_LEN 32
#define ECHOFOREST_MAX_MESSAGE_LEN 160
#define ECHOFOREST_MAX_TASK_TITLE_LEN 80

#define ECHOFOREST_API_STATE_PATH "/api/state"
#define ECHOFOREST_API_DEVICE_DATA_PATH "/api/device_data"
#define ECHOFOREST_API_SESSION_START_PATH "/api/session/start"
#define ECHOFOREST_API_SESSION_END_PATH "/api/session/end"
#define ECHOFOREST_API_SESSION_RECOVER_PATH "/api/session/recover"

typedef struct {
    char device_id[ECHOFOREST_MAX_DEVICE_ID_LEN];
    char mode[ECHOFOREST_MAX_MODE_LEN];
    float light;
    float noise;
    float temp;
    float humi;
    int button;
    bool camera_used;
} echoforest_device_data_t;

typedef struct {
    char mode[ECHOFOREST_MAX_MODE_LEN];
    char forest_state[ECHOFOREST_MAX_FOREST_STATE_LEN];
    char screen_line1[ECHOFOREST_MAX_SCREEN_LINE_LEN];
    char screen_line2[ECHOFOREST_MAX_SCREEN_LINE_LEN];
    char rgb_mode[ECHOFOREST_MAX_FEEDBACK_MODE_LEN];
    char buzzer_mode[ECHOFOREST_MAX_FEEDBACK_MODE_LEN];
    char message[ECHOFOREST_MAX_MESSAGE_LEN];
    char task_title[ECHOFOREST_MAX_TASK_TITLE_LEN];
    int sessions_completed;
    float light;
    float noise;
    float temp;
    float humi;
    char device_id[ECHOFOREST_MAX_DEVICE_ID_LEN];
    int button;
    bool camera_used;
} echoforest_state_t;

typedef enum {
    ECHOFOREST_ACTION_NONE = 0,
    ECHOFOREST_ACTION_START,
    ECHOFOREST_ACTION_END,
    ECHOFOREST_ACTION_REST
} echoforest_action_t;

static inline const char *echoforest_action_to_string(echoforest_action_t action)
{
    switch (action) {
    case ECHOFOREST_ACTION_START:
        return "start";
    case ECHOFOREST_ACTION_END:
        return "end";
    case ECHOFOREST_ACTION_REST:
        return "rest";
    case ECHOFOREST_ACTION_NONE:
    default:
        return "none";
    }
}

#ifdef __cplusplus
}
#endif

#endif
