# EchoForest 当前版本测试说明

这份说明给测试同学使用。当前版本包含后端、网页控制台、设备模拟器，以及 ESP32-S3 / ESP32-C5 固件交互骨架。

注意：固件骨架不是完整 ESP-IDF 工程，不能直接烧录。当前可直接测试的是本地软件闭环；固件部分用于给硬件同学接入真实 S3/C5 工程。

## 1. 测试前准备

需要安装：

- Node.js
- Windows CMD 或 PowerShell

建议先确认项目路径：

```cmd
cd /d "C:\Users\35174\Desktop\物联网\echoforest-harness"
```

如果是从压缩包解压出来，请进入解压后的项目目录。

## 2. 一键检查

在项目根目录运行：

```cmd
scripts\verify.cmd
```

预期：

- 后端依赖安装成功。
- 后端测试通过。
- 前端测试和构建通过。
- 模拟器测试通过。

如果卡在 frontend dependency install，通常是本机 npm 环境或网络/缓存问题。可以分开测试：

```cmd
cd /d "项目目录\backend"
npm.cmd install --no-package-lock
npm.cmd test

cd /d "项目目录\frontend"
npm.cmd install --no-package-lock
npm.cmd test
npm.cmd run build

cd /d "项目目录"
node --test simulator\test\device_simulator.test.js
```

## 3. 启动本地演示

打开第一个终端，启动后端：

```cmd
cd /d "项目目录\backend"
npm.cmd install --no-package-lock
npm.cmd start
```

后端默认端口：

```text
http://localhost:3000
```

打开第二个终端，启动前端：

```cmd
cd /d "项目目录\frontend"
npm.cmd install --no-package-lock
npm.cmd run dev
```

网页地址：

```text
http://localhost:5173/
```

## 4. 软件闭环测试流程

1. 打开网页 `http://localhost:5173/`。
2. 输入学习目标。
3. 点击“开始学习”。
4. 打开第三个终端，在项目根目录运行模拟器：

```cmd
node simulator\device_simulator.js --scenario cycle --interval 2000 --count 8 --base-url http://localhost:3000
```

5. 观察网页环境数据是否更新：

```text
light
noise
temp
humi
```

6. 观察网页状态是否随模拟器变化：

```text
growing
low_light
noisy
uncomfortable
```

7. 点击“开始休息”，观察状态是否进入休息。
8. 点击“结束学习”，观察最新学习日志是否出现。

## 5. 单场景测试命令

正常学习：

```cmd
node simulator\device_simulator.js --scenario normal --interval 2000 --count 5 --base-url http://localhost:3000
```

光线过暗：

```cmd
node simulator\device_simulator.js --scenario low_light --interval 2000 --count 5 --base-url http://localhost:3000
```

环境偏吵：

```cmd
node simulator\device_simulator.js --scenario noisy --interval 2000 --count 5 --base-url http://localhost:3000
```

温湿度不适：

```cmd
node simulator\device_simulator.js --scenario uncomfortable --interval 2000 --count 5 --base-url http://localhost:3000
```

## 6. 直接用 curl 测 API

读取状态：

```cmd
curl http://localhost:3000/api/state
```

开始学习：

```cmd
curl -X POST http://localhost:3000/api/session/start -H "Content-Type: application/json" -d "{\"target_text\":\"测试学习任务\"}"
```

上传设备数据：

```cmd
curl -X POST http://localhost:3000/api/device_data -H "Content-Type: application/json" -d "{\"device_id\":\"echoforest_s3_001\",\"mode\":\"focus\",\"light\":320,\"noise\":88,\"temp\":26,\"humi\":55,\"button\":0,\"camera_used\":false}"
```

结束学习：

```cmd
curl -X POST http://localhost:3000/api/session/end
```

## 7. 固件骨架检查

固件骨架静态检查：

```cmd
scripts\review_firmware_skeleton.cmd
```

预期输出：

```text
PASS
```

这个检查只确认固件模块文件、API 路径、协议结构、配置占位符和交付范围，不会编译 ESP-IDF 工程。

## 8. 硬件同学接入时的测试方式

ESP32 不能访问 `localhost:3000`。硬件测试时后端地址必须改成电脑局域网 IP，例如：

```text
http://192.168.1.23:3000
```

电脑 IP 可用 Windows 命令查看：

```cmd
ipconfig
```

接入建议：

1. 先只接 Wi-Fi 和 HTTP。
2. S3 先用 `sensor_mock` 上传假数据。
3. 确认后端和网页能显示 S3 上传的数据。
4. 再逐个替换真实 DHT11、BH1750、INMP441。
5. C5 先轮询 `/api/state` 显示状态。
6. 再把触摸区域接成开始学习、结束学习、开始休息。

## 9. 常见问题

网页打不开：

- 检查前端是否启动。
- 检查地址是否是 `http://localhost:5173/`。

网页没有数据：

- 检查后端是否启动。
- 检查模拟器是否在向 `http://localhost:3000/api/device_data` 上传。
- 检查 Vite proxy 是否生效。

ESP32 连不上后端：

- 不要用 localhost。
- 确认电脑和 ESP32 在同一个局域网。
- 确认 Windows 防火墙没有拦截 3000 端口。
- 确认后端监听端口是 3000。

模拟器报 fetch 问题：

- 检查 Node.js 版本。
- 建议使用带内置 fetch 的新版 Node.js。

