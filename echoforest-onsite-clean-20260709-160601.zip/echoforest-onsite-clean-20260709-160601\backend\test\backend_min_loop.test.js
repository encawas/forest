// EchoForest Phase 1 -- Backend Minimal Loop Tests
// Uses node:test (built-in) and fetch (built-in); zero extra dependencies

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const app = require('../src/app');

let server;
let baseUrl;

before(async () => {
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  const port = server.address().port;
  baseUrl = `http://localhost:${port}`;
});

after(() => {
  if (server) server.close();
});

// Helper: POST JSON
async function post(path, body) {
  const res = await fetch(`${baseUrl}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, data: await res.json() };
}

// Helper: GET JSON
async function get(path) {
  const res = await fetch(`${baseUrl}${path}`);
  return { status: res.status, data: await res.json() };
}

// Helper: assert all required response fields present
function assertRequiredFields(data) {
  const required = [
    'mode', 'forest_state', 'screen_line1', 'screen_line2',
    'rgb_mode', 'buzzer_mode', 'message', 'task_title', 'log', 'counts',
  ];
  for (const field of required) {
    assert.ok(field in data, `Missing required field: ${field}`);
  }
}

// ---- State engine unit tests ----
describe('State Engine', () => {
  const { computeForestState, getDisplayMapping } = require('../src/stateEngine');

  const ALLOWED_STATES = ['normal', 'growing', 'low_light', 'noisy', 'uncomfortable', 'completed', 'recovering'];

  it('returns completed when mode is completed', () => {
    assert.strictEqual(computeForestState('completed', 500, 50, 24, 50), 'completed');
  });

  it('returns recovering when mode is rest', () => {
    assert.strictEqual(computeForestState('rest', 500, 50, 24, 50), 'recovering');
  });

  it('returns low_light when light is below threshold', () => {
    assert.strictEqual(computeForestState('focus', 50, 50, 24, 50), 'low_light');
  });

  it('returns noisy when noise is above threshold', () => {
    assert.strictEqual(computeForestState('focus', 500, 90, 24, 50), 'noisy');
  });

  it('returns uncomfortable when temp is out of comfort range', () => {
    assert.strictEqual(computeForestState('focus', 500, 50, 35, 50), 'uncomfortable');
    assert.strictEqual(computeForestState('focus', 500, 50, 10, 50), 'uncomfortable');
  });

  it('returns uncomfortable when humi is out of comfort range', () => {
    assert.strictEqual(computeForestState('focus', 500, 50, 24, 10), 'uncomfortable');
    assert.strictEqual(computeForestState('focus', 500, 50, 24, 90), 'uncomfortable');
  });

  it('returns growing for focus mode with normal environment', () => {
    assert.strictEqual(computeForestState('focus', 500, 50, 24, 50), 'growing');
  });

  it('returns normal for idle mode', () => {
    assert.strictEqual(computeForestState('idle', 500, 50, 24, 50), 'normal');
  });

  it('handles null/undefined environment values gracefully', () => {
    assert.strictEqual(computeForestState('focus', null, null, null, null), 'growing');
    assert.strictEqual(computeForestState('idle', undefined, undefined, undefined, undefined), 'normal');
  });

  it('all returned states are in the allowed list', () => {
    const modes = ['completed', 'rest', 'focus', 'idle'];
    const envScenarios = [
      { light: 50, noise: 50, temp: 24, humi: 50 },
      { light: 500, noise: 90, temp: 24, humi: 50 },
      { light: 500, noise: 50, temp: 35, humi: 50 },
      { light: 500, noise: 50, temp: 24, humi: 10 },
      { light: 500, noise: 50, temp: 24, humi: 50 },
    ];
    for (const mode of modes) {
      for (const env of envScenarios) {
        const state = computeForestState(mode, env.light, env.noise, env.temp, env.humi);
        assert.ok(ALLOWED_STATES.includes(state), `State "${state}" not in allowed list`);
      }
    }
  });

  it('priority: completed beats all others', () => {
    // Even with low light, high noise, bad temp/humi -> completed wins
    assert.strictEqual(computeForestState('completed', 10, 90, 10, 10), 'completed');
  });

  it('priority: recovering beats environment conditions', () => {
    assert.strictEqual(computeForestState('rest', 10, 90, 10, 10), 'recovering');
  });

  it('priority: low_light beats noisy', () => {
    // Low light AND high noise -> low_light wins (higher priority)
    assert.strictEqual(computeForestState('focus', 50, 90, 24, 50), 'low_light');
  });

  // ---- Display mapping tests ----
  it('getDisplayMapping returns correct mapping for each state', () => {
    const normal = getDisplayMapping('normal');
    assert.strictEqual(normal.screen_line1, 'EchoForest');
    assert.strictEqual(normal.screen_line2, '准备就绪');
    assert.strictEqual(normal.rgb_mode, 'ready');
    assert.strictEqual(normal.buzzer_mode, 'none');

    const growing = getDisplayMapping('growing');
    assert.strictEqual(growing.screen_line1, '专注中');
    assert.strictEqual(growing.screen_line2, '森林成长中');
    assert.strictEqual(growing.rgb_mode, 'focus');

    const lowLight = getDisplayMapping('low_light');
    assert.strictEqual(lowLight.screen_line1, '光线过暗');
    assert.strictEqual(lowLight.screen_line2, '请打开灯');
    assert.strictEqual(lowLight.rgb_mode, 'warning_slow');
    assert.strictEqual(lowLight.buzzer_mode, 'warning');

    const noisy = getDisplayMapping('noisy');
    assert.strictEqual(noisy.screen_line1, '环境偏吵');
    assert.strictEqual(noisy.screen_line2, '请降低噪声');
    assert.strictEqual(noisy.rgb_mode, 'warning_fast');

    const uncomfortable = getDisplayMapping('uncomfortable');
    assert.strictEqual(uncomfortable.screen_line1, '环境不适');
    assert.strictEqual(uncomfortable.screen_line2, '调整温湿度');
    assert.strictEqual(uncomfortable.rgb_mode, 'warning_soft');
    assert.strictEqual(uncomfortable.buzzer_mode, 'short');

    const completed = getDisplayMapping('completed');
    assert.strictEqual(completed.screen_line1, '学习完成');
    assert.strictEqual(completed.screen_line2, '森林已成长');
    assert.strictEqual(completed.rgb_mode, 'done');
    assert.strictEqual(completed.buzzer_mode, 'done');

    const recovering = getDisplayMapping('recovering');
    assert.strictEqual(recovering.screen_line1, '休息中');
    assert.strictEqual(recovering.screen_line2, '放松一下');
    assert.strictEqual(recovering.rgb_mode, 'rest');
  });
});

// ---- API endpoint integration tests ----
describe('API Endpoints', () => {

  describe('POST /api/session/start', () => {
    it('starts a session with focus mode', async () => {
      const { status, data } = await post('/api/session/start', { target_text: 'Study math' });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.mode, 'focus');
      assert.ok(data.task_title.includes('Study math') || data.task_title.includes('专注学习'));
      assertRequiredFields(data);
    });

    it('starts a session without target_text', async () => {
      const { status, data } = await post('/api/session/start', {});
      assert.strictEqual(status, 200);
      assert.strictEqual(data.mode, 'focus');
      assertRequiredFields(data);
    });
  });

  describe('POST /api/session/end', () => {
    it('completes a session and generates a log', async () => {
      await post('/api/session/start', { target_text: 'Study physics' });
      const { status, data } = await post('/api/session/end', {});
      assert.strictEqual(status, 200);
      assert.strictEqual(data.mode, 'completed');
      assert.strictEqual(data.forest_state, 'completed');
      assert.ok(data.log !== null, 'Log should be generated');
      assert.strictEqual(data.log.target, 'Study physics');
      assert.ok(data.log.duration_minutes >= 0);
      assert.strictEqual(data.log.forest_state, 'completed');
      assert.strictEqual(data.log.summary, `本次学习已完成，用时 ${data.log.duration_minutes} 分钟。`);
      assert.ok(data.counts.sessions_completed >= 1);
      assertRequiredFields(data);
    });
  });

  describe('POST /api/session/recover', () => {
    it('enters recovery mode', async () => {
      await post('/api/session/start', { target_text: 'Study' });
      const { status, data } = await post('/api/session/recover', {});
      assert.strictEqual(status, 200);
      assert.strictEqual(data.mode, 'rest');
      assert.strictEqual(data.forest_state, 'recovering');
      assertRequiredFields(data);
    });
  });

  describe('POST /api/device_data', () => {
    it('returns low_light for dim light', async () => {
      await post('/api/session/start', { target_text: 'Reading' });
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001',
        mode: 'focus',
        light: 30,
        noise: 50,
        temp: 24,
        humi: 50,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'low_light');
      assert.strictEqual(data.screen_line1, '光线过暗');
      assert.strictEqual(data.message, '当前光线偏暗，建议打开台灯或调整环境光。');
      assert.strictEqual(data.task_title, '光线提醒');
      assertRequiredFields(data);
    });

    it('returns noisy for loud environment', async () => {
      await post('/api/session/start', { target_text: 'Coding' });
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001',
        mode: 'focus',
        light: 500,
        noise: 80,
        temp: 24,
        humi: 50,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'noisy');
      assert.strictEqual(data.screen_line1, '环境偏吵');
      assert.strictEqual(data.screen_line2, '请降低噪声');
      assert.strictEqual(data.message, '当前噪声偏高，建议换到更安静的位置或使用耳塞。');
      assert.strictEqual(data.task_title, '噪声提醒');
      assertRequiredFields(data);
    });

    it('returns growing for normal focus environment', async () => {
      await post('/api/session/start', { target_text: 'Writing' });
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001',
        mode: 'focus',
        light: 500,
        noise: 40,
        temp: 24,
        humi: 55,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'growing');
      assert.strictEqual(data.rgb_mode, 'focus');
      assert.strictEqual(data.screen_line1, '专注中');
      assert.strictEqual(data.screen_line2, '森林成长中');
      assertRequiredFields(data);
    });

    it('returns uncomfortable for out-of-range temp or humi', async () => {
      await post('/api/session/start', { target_text: 'Review' });
      const resHot = await post('/api/device_data', {
        device_id: 'echoforest_s3_001', mode: 'focus',
        light: 500, noise: 40, temp: 32, humi: 55,
      });
      assert.strictEqual(resHot.status, 200);
      assert.strictEqual(resHot.data.forest_state, 'uncomfortable');

      const resDry = await post('/api/device_data', {
        device_id: 'echoforest_s3_001', mode: 'focus',
        light: 500, noise: 40, temp: 24, humi: 20,
      });
      assert.strictEqual(resDry.status, 200);
      assert.strictEqual(resDry.data.forest_state, 'uncomfortable');
    });

    it('returns completed when body.mode is completed', async () => {
      await post('/api/session/start', { target_text: 'Done task' });
      await post('/api/session/end', {});
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001', mode: 'completed',
        light: 500, noise: 40, temp: 24, humi: 55,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'completed');
      assertRequiredFields(data);
    });

    it('returns recovering when body.mode is rest', async () => {
      await post('/api/session/start', { target_text: 'Break time' });
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001', mode: 'rest',
        light: 500, noise: 40, temp: 24, humi: 55,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'recovering');
      assert.strictEqual(data.screen_line1, '休息中');
      assert.strictEqual(data.screen_line2, '放松一下');
      assert.strictEqual(data.message, '进入休息阶段，稍微放松一下再继续。');
      assert.strictEqual(data.task_title, '休息时间');
      assertRequiredFields(data);
    });

    it('returns completed when body.mode is completed without session', async () => {
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_001', mode: 'completed',
        light: 500, noise: 40, temp: 24, humi: 55,
      });
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'completed');
      assertRequiredFields(data);
    });

    it('validates required fields', async () => {
      const res1 = await post('/api/device_data', {});
      assert.strictEqual(res1.status, 400);

      const res2 = await post('/api/device_data', { device_id: 'd1' });
      assert.strictEqual(res2.status, 400);

      const res3 = await post('/api/device_data', { device_id: 'd1', mode: 'focus' });
      assert.strictEqual(res3.status, 400);

      const res4 = await post('/api/device_data', { device_id: 'd1', mode: 'focus', light: 500 });
      assert.strictEqual(res4.status, 400);
    });

    it('handles optional fields (temp, humi, button, camera_used, target_text, timestamp)', async () => {
      await post('/api/session/start', { target_text: 'Test' });
      const { status, data } = await post('/api/device_data', {
        device_id: 'echoforest_s3_002',
        mode: 'focus',
        light: 500,
        noise: 40,
        temp: 22.5,
        humi: 60,
        button: 0,
        camera_used: false,
        target_text: 'Optional target',
        timestamp: '2026-07-04T12:00:00Z',
      });
      assert.strictEqual(status, 200);
      assertRequiredFields(data);
    });
  });

  describe('GET /api/state', () => {
    it('returns current state with all required fields', async () => {
      await post('/api/session/start', { target_text: 'Poll test' });
      await post('/api/device_data', {
        device_id: 'd1', mode: 'focus', light: 500, noise: 40,
      });
      const { status, data } = await get('/api/state');
      assert.strictEqual(status, 200);
      assert.strictEqual(data.forest_state, 'growing');
      assertRequiredFields(data);
    });

    it('exposes latest device fields after noisy device upload', async () => {
      await post('/api/session/start', { target_text: 'Live integration' });
      await post('/api/device_data', {
        device_id: 'echoforest_s3_009',
        mode: 'focus',
        light: 500,
        noise: 80,
        temp: 24,
        humi: 50,
        button: 0,
        camera_used: false,
      });

      const { status, data } = await get('/api/state');
      assert.strictEqual(status, 200);
      assert.strictEqual(data.mode, 'focus');
      assert.strictEqual(data.forest_state, 'noisy');
      assert.strictEqual(data.device_id, 'echoforest_s3_009');
      assert.strictEqual(data.light, 500);
      assert.strictEqual(data.noise, 80);
      assert.strictEqual(data.temp, 24);
      assert.strictEqual(data.humi, 50);
      assert.strictEqual(data.button, 0);
      assert.strictEqual(data.camera_used, false);
      assertRequiredFields(data);
    });

    it('returns idle/normal when no session is active', async () => {
      // Reset by completing a session then check initial state
      const { status, data } = await get('/api/state');
      assert.strictEqual(status, 200);
      // After session/end from previous test, mode may be completed
      // The test just validates the response shape
      assert.ok(['normal', 'growing', 'noisy', 'completed', 'recovering'].includes(data.forest_state));
      assertRequiredFields(data);
    });
  });

  describe('Full Loop', () => {
    it('completes the minimal demo loop', async () => {
      // 1. Start session
      const start = await post('/api/session/start', { target_text: 'Study OS' });
      assert.strictEqual(start.data.mode, 'focus');

      // 2. Send device data (growing)
      const growing = await post('/api/device_data', {
        device_id: 's3_001', mode: 'focus', light: 400, noise: 45, temp: 23, humi: 50,
      });
      assert.strictEqual(growing.data.forest_state, 'growing');

      // 3. Send device data (low_light)
      const lowLight = await post('/api/device_data', {
        device_id: 's3_001', mode: 'focus', light: 40, noise: 45, temp: 23, humi: 50,
      });
      assert.strictEqual(lowLight.data.forest_state, 'low_light');
      assert.strictEqual(lowLight.data.screen_line1, '光线过暗');

      // 4. Send device data (noisy)
      const noisy = await post('/api/device_data', {
        device_id: 's3_001', mode: 'focus', light: 400, noise: 80, temp: 23, humi: 50,
      });
      assert.strictEqual(noisy.data.forest_state, 'noisy');

      // 5. End session -> completed
      const end = await post('/api/session/end', {});
      assert.strictEqual(end.data.forest_state, 'completed');
      assert.strictEqual(end.data.log.target, 'Study OS');
      assert.ok(end.data.log.duration_minutes >= 0);
    });
  });
});
