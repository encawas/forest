# EchoForest Field Configuration Tool

This document explains the on-site configuration tool for hardware teammates.

The goal is to remove the user from the tuning loop. Hardware teammates can choose values on site, run one simple command, and generate the C header used by S3/C5 firmware.

## Entry Point

Run:

```cmd
field_config\configure.cmd
```

The tool opens a menu for:

- backend base URL
- Wi-Fi SSID and password
- S3 DHT11 GPIO
- light threshold
- noise threshold
- temperature range
- humidity range
- C5 touch button rectangles
- copying the generated config header into S3/C5 ESP-IDF projects

## Generated Header

Output:

```text
field_config\generated\echoforest_field_config.h
```

The header defines:

```c
#define ECHOFOREST_WIFI_SSID "..."
#define ECHOFOREST_WIFI_PASSWORD "..."
#define ECHOFOREST_BACKEND_BASE_URL "http://192.168.x.x:3000"
#define ECHOFOREST_DHT11_PIN GPIO_NUM_0
#define ECHOFOREST_LOW_LIGHT_THRESHOLD 80.0f
#define ECHOFOREST_NOISE_THRESHOLD 62.0f
```

It also defines C5 touch rectangles:

```c
ECHOFOREST_TOUCH_START_*
ECHOFOREST_TOUCH_REST_*
ECHOFOREST_TOUCH_END_*
```

## Safety Rules

- `config.local.json` is local and ignored by git.
- `generated/` is local and ignored by git.
- Do not commit real Wi-Fi credentials.
- Do not use `localhost` as ESP32 backend URL.
- Use the PC LAN IP, for example `http://192.168.1.23:3000`.

## Recommended Firmware Usage

S3 and C5 firmware should include:

```c
#include "echoforest_field_config.h"
```

Then read values from macros instead of hardcoding:

```c
ECHOFOREST_WIFI_SSID
ECHOFOREST_WIFI_PASSWORD
ECHOFOREST_BACKEND_BASE_URL
ECHOFOREST_DHT11_PIN
ECHOFOREST_NOISE_THRESHOLD
```

This keeps现场调参 inside one generated file instead of editing many source files.

## S3 Base Project Auto Patch

For the received S3 base project, the tool can also patch source macros automatically:

```cmd
node field_config\apply_config.js --patch-s3-base D:\s3_project
```

It copies `echoforest_field_config.h` into:

- `D:\s3_project\main`
- `D:\s3_project\components\dht11`
- `D:\s3_project\components\WIFISTA`

Then it patches:

- `components\dht11\dht11.h`
  - `DHT11_DQ_GPIO_PIN` becomes `ECHOFOREST_DHT11_PIN`
- `components\WIFISTA\wifista.h`
  - `DEFAULT_SSID` becomes `ECHOFOREST_WIFI_SSID`
  - `DEFAULT_PWD` becomes `ECHOFOREST_WIFI_PASSWORD`

This is intentionally small-scope. It does not rewrite the whole S3 project and does not touch camera, LCD, or UDP code.

## C5 Touch Helper Auto Patch

For C5, the tool can create a small touch helper without guessing the full C5 project layout:

```cmd
node field_config\apply_config.js --patch-c5-base D:\c5_project
```

It writes:

- `D:\c5_project\main\echoforest_field_config.h`
- `D:\c5_project\main\echoforest_c5_touch_bridge.h`

The generated bridge exposes:

```c
int echoforest_field_touch_action_id(int x, int y);
const char *echoforest_field_touch_action_name(int action_id);
```

Hardware teammates can call this from their existing touch demo after reading coordinates, then tune the rectangles in `configure.cmd`.
