#ifndef ECHOFOREST_TOUCH_ACTIONS_H
#define ECHOFOREST_TOUCH_ACTIONS_H

#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

void touch_actions_init(void);
echoforest_action_t touch_actions_read(void);
echoforest_action_t touch_actions_map_point(int x, int y);

#ifdef __cplusplus
}
#endif

#endif
