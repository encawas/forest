// EchoForest Phase 1 Template Functions
// Template task title, message, and log generation (no real LLM API)

/**
 * Generate a task title for the current session state.
 */
function generateTaskTitle(mode, forestState, targetText) {
  if (mode === 'focus' && forestState === 'growing') return targetText || '专注学习';
  if (mode === 'focus' && forestState === 'low_light') return '光线提醒';
  if (mode === 'focus' && forestState === 'noisy') return '噪声提醒';
  if (mode === 'focus' && forestState === 'uncomfortable') return '舒适度提醒';
  if (mode === 'focus') return targetText || '专注学习';
  if (mode === 'rest') return '休息时间';
  if (mode === 'completed') return '学习完成';
  return 'EchoForest 就绪';
}

/**
 * Generate a human-readable message for the current forest state.
 */
function generateMessage(forestState, targetText) {
  const messages = {
    normal: '设置学习目标后开始学习。',
    growing: targetText
      ? `你的森林正在成长，继续保持专注：${targetText}。`
      : '你的森林正在成长，继续保持专注。',
    low_light: '当前光线偏暗，建议打开台灯或调整环境光。',
    noisy: '当前噪声偏高，建议换到更安静的位置或使用耳塞。',
    uncomfortable: '当前温湿度不太舒适，建议调整空调或通风。',
    completed: '本次学习完成，干得不错。',
    recovering: '进入休息阶段，稍微放松一下再继续。',
  };
  return messages[forestState] || messages.normal;
}

/**
 * Generate a session log entry after the session ends.
 */
function generateLog(session) {
  if (!session) return null;

  const start = session.startTime ? new Date(session.startTime) : new Date();
  const end = session.endTime ? new Date(session.endTime) : new Date();
  const durationMin = Math.max(0, Math.round((end - start) / 60000));

  return {
    session_start: session.startTime || start.toISOString(),
    session_end: session.endTime || end.toISOString(),
    target: session.targetText || '未设置学习目标',
    duration_minutes: durationMin,
    forest_state: 'completed',
    summary: `本次学习已完成，用时 ${durationMin} 分钟。`,
  };
}

module.exports = { generateTaskTitle, generateMessage, generateLog };
