@echo off
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo === EchoForest Firmware Interaction Skeleton Review ===
echo.

set "PASS=1"

for %%F in (
  "firmware_modules\README.md"
  "firmware_modules\common\echoforest_protocol.h"
  "firmware_modules\common\cloud_client.h"
  "firmware_modules\common\cloud_client.c"
  "firmware_modules\common\wifi_manager.h"
  "firmware_modules\common\wifi_manager.c"
  "firmware_modules\common\echoforest_config.example.h"
  "firmware_modules\s3\sensor_mock.h"
  "firmware_modules\s3\sensor_mock.c"
  "firmware_modules\s3\sensor_real_adapter.h"
  "firmware_modules\s3\sensor_real_adapter.c"
  "firmware_modules\s3\main_screen_renderer.h"
  "firmware_modules\s3\main_screen_renderer.c"
  "firmware_modules\s3\s3_app.h"
  "firmware_modules\s3\s3_app.c"
  "firmware_modules\c5\touch_actions.h"
  "firmware_modules\c5\touch_actions.c"
  "firmware_modules\c5\control_screen_renderer.h"
  "firmware_modules\c5\control_screen_renderer.c"
  "firmware_modules\c5\c5_app.h"
  "firmware_modules\c5\c5_app.c"
  "scripts\review_firmware_skeleton.cmd"
) do (
  if not exist %%F (
    echo FAIL: missing %%F
    set "PASS=0"
  )
)

if "!PASS!"=="0" exit /b 1
echo Required files: OK
echo.

echo Checking cloud client API paths...
findstr /C:"/api/device_data" "firmware_modules\common\cloud_client.c" >nul || (echo FAIL: missing /api/device_data & exit /b 1)
findstr /C:"/api/state" "firmware_modules\common\cloud_client.c" >nul || (echo FAIL: missing /api/state & exit /b 1)
findstr /C:"/api/session/start" "firmware_modules\common\cloud_client.c" >nul || (echo FAIL: missing /api/session/start & exit /b 1)
findstr /C:"/api/session/end" "firmware_modules\common\cloud_client.c" >nul || (echo FAIL: missing /api/session/end & exit /b 1)
findstr /C:"/api/session/recover" "firmware_modules\common\cloud_client.c" >nul || (echo FAIL: missing /api/session/recover & exit /b 1)
echo API paths: OK
echo.

echo Checking protocol types and actions...
findstr /C:"echoforest_device_data_t" "firmware_modules\common\echoforest_protocol.h" >nul || (echo FAIL: missing echoforest_device_data_t & exit /b 1)
findstr /C:"echoforest_state_t" "firmware_modules\common\echoforest_protocol.h" >nul || (echo FAIL: missing echoforest_state_t & exit /b 1)
findstr /C:"ECHOFOREST_ACTION_START" "firmware_modules\common\echoforest_protocol.h" >nul || (echo FAIL: missing ECHOFOREST_ACTION_START & exit /b 1)
findstr /C:"ECHOFOREST_ACTION_END" "firmware_modules\common\echoforest_protocol.h" >nul || (echo FAIL: missing ECHOFOREST_ACTION_END & exit /b 1)
findstr /C:"ECHOFOREST_ACTION_REST" "firmware_modules\common\echoforest_protocol.h" >nul || (echo FAIL: missing ECHOFOREST_ACTION_REST & exit /b 1)
echo Protocol: OK
echo.

echo Checking config example...
findstr /C:"ECHOFOREST_WIFI_SSID" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: missing ECHOFOREST_WIFI_SSID & exit /b 1)
findstr /C:"ECHOFOREST_WIFI_PASSWORD" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: missing ECHOFOREST_WIFI_PASSWORD & exit /b 1)
findstr /C:"ECHOFOREST_BACKEND_BASE_URL" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: missing ECHOFOREST_BACKEND_BASE_URL & exit /b 1)
findstr /C:"ECHOFOREST_DHT11_PIN GPIO_NUM_0" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: missing DHT11 GPIO0 default & exit /b 1)
findstr /C:"ECHOFOREST_NOISE_THRESHOLD" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: missing noise threshold default & exit /b 1)
findstr /C:"your_wifi_password" "firmware_modules\common\echoforest_config.example.h" >nul || (echo FAIL: config must use your_wifi_password placeholder & exit /b 1)
findstr /I /C:"localhost" "firmware_modules\common\echoforest_config.example.h" >nul && (echo FAIL: config example must not contain localhost & exit /b 1)
findstr /I /C:"127.0.0.1" "firmware_modules\common\echoforest_config.example.h" >nul && (echo FAIL: config example must not contain 127.0.0.1 & exit /b 1)
echo Config example: OK
echo.

echo Checking field config integration points...
findstr /C:"s3_app_init_from_field_config" "firmware_modules\s3\s3_app.c" >nul || (echo FAIL: missing S3 field config init & exit /b 1)
findstr /C:"s3_app_run_once_real_sensors" "firmware_modules\s3\s3_app.c" >nul || (echo FAIL: missing S3 real sensor loop & exit /b 1)
findstr /C:"sensor_real_adapter_read" "firmware_modules\s3\sensor_real_adapter.c" >nul || (echo FAIL: missing real sensor adapter read & exit /b 1)
findstr /C:"bh1750_read_data" "firmware_modules\s3\sensor_real_adapter.c" >nul || (echo FAIL: missing BH1750 adapter call & exit /b 1)
findstr /C:"dht11_read_data" "firmware_modules\s3\sensor_real_adapter.c" >nul || (echo FAIL: missing DHT11 adapter call & exit /b 1)
findstr /C:"i2s_mic_read_rms" "firmware_modules\s3\sensor_real_adapter.c" >nul || (echo FAIL: missing INMP441 adapter call & exit /b 1)
findstr /C:"c5_app_init_from_field_config" "firmware_modules\c5\c5_app.c" >nul || (echo FAIL: missing C5 field config init & exit /b 1)
findstr /C:"touch_actions_map_point" "firmware_modules\c5\touch_actions.c" >nul || (echo FAIL: missing C5 touch map helper & exit /b 1)
echo Field config integration: OK
echo.

if exist "package-lock.json" (
  echo FAIL: root package-lock.json exists
  exit /b 1
)
if exist "backend\package-lock.json" (
  echo FAIL: backend package-lock.json exists
  exit /b 1
)
if exist "frontend\package-lock.json" (
  echo FAIL: frontend package-lock.json exists
  exit /b 1
)

echo Checking git status scope...
git status --short --untracked-files=all
if %ERRORLEVEL% neq 0 exit /b 1

for /f "delims=" %%L in ('git status --short --untracked-files=all') do (
  set "LINE=%%L"
  set "PATHPART=!LINE:~3!"

  if /I "!PATHPART:~0,8!"=="backend/" (
    echo FAIL: backend modification detected: !PATHPART!
    exit /b 1
  )
  if /I "!PATHPART:~0,9!"=="frontend/" (
    echo FAIL: frontend modification detected: !PATHPART!
    exit /b 1
  )
  if /I "!PATHPART:~0,10!"=="simulator/" (
    echo FAIL: simulator modification detected: !PATHPART!
    exit /b 1
  )
  if /I "!PATHPART!"=="package.json" (
    echo FAIL: package.json change detected
    exit /b 1
  )
  if /I "!PATHPART!"=="backend/package.json" (
    echo FAIL: backend package.json change detected
    exit /b 1
  )
  if /I "!PATHPART!"=="frontend/package.json" (
    echo FAIL: frontend package.json change detected
    exit /b 1
  )
  if /I "!PATHPART!"=="package-lock.json" (
    echo FAIL: package-lock.json change detected
    exit /b 1
  )
  if /I "!PATHPART!"=="backend/package-lock.json" (
    echo FAIL: backend package-lock.json change detected
    exit /b 1
  )
  if /I "!PATHPART!"=="frontend/package-lock.json" (
    echo FAIL: frontend package-lock.json change detected
    exit /b 1
  )
)

echo Git status scope: OK
echo.
echo PASS
exit /b 0
