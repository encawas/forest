# EchoForest Delivery Manifest

This package contains the current EchoForest Phase 1 software loop, firmware interaction skeleton, S3/C5 onsite configuration tool, and hardware handoff documents.

## Main Entry

- `START_HERE_ONSITE.md`: first document for onsite hardware teammates.
- `docs\onsite_handoff_workflow.md`: ordered onsite workflow.
- `docs\future_task_plan.md`: follow-up task plan from software loop to real S3/C5 loop.
- `field_config\configure.cmd`: menu-driven onsite configuration entry.
- `scripts\create_onsite_package.cmd`: creates a clean zip package for teammate delivery.

## Software Loop

- `backend\`: Express backend and in-memory state engine.
- `frontend\`: React/Vite dashboard.
- `simulator\`: device data simulator for software demo fallback.

## Firmware Modules

- `firmware_modules\common\`: protocol, cloud client, Wi-Fi wrapper, config example.
- `firmware_modules\s3\`: mock sensor loop, real sensor adapter skeleton, S3 screen renderer placeholder.
- `firmware_modules\c5\`: touch action mapping, C5 app skeleton, control screen renderer placeholder.

## Onsite Configuration

- `field_config\apply_config.js`: generates and copies `echoforest_field_config.h`.
- `field_config\configure.cmd`: simple menu entry.
- Supports:
  - backend URL
  - Wi-Fi SSID/password
  - DHT11 GPIO
  - light/noise/temp/humi thresholds
  - C5 touch rectangles
  - S3 base project patch
  - C5 touch helper generation

## Review Scripts

- `scripts\review_field_config.cmd`
- `scripts\review_firmware_skeleton.cmd`
- `scripts\review_hardware_delivery.cmd`
- `scripts\create_onsite_package.cmd`

Expected final hardware delivery check:

```cmd
scripts\review_hardware_delivery.cmd
```

Expected result:

```text
PASS
```

To create a clean delivery zip after checks:

```cmd
scripts\create_onsite_package.cmd
```

## Exclusions

The delivery package should not include:

- `.git`
- `node_modules`
- frontend `dist`
- ESP-IDF `build`
- `managed_components`
- `package-lock.json`
- real Wi-Fi credentials
