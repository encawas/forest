# ESP32-S3 Base Project Inspection

This document records useful facts extracted from the S3 zip received on 2026-07-09.

The zip is a real ESP-IDF base project for ESP32-S3. It is useful for hardware integration, but it is not yet an EchoForest backend HTTP integration project.

## Project Summary

- Target: ESP32-S3
- ESP-IDF: 5.5.4
- Main entry: `main/main.c`
- Flash config: 2MB
- PSRAM: disabled in `sdkconfig`
- Main components: LCD, BH1750, dht11, noise, WIFISTA, UDP client, camera

Current S3 flow:

```text
NVS init
-> connect to C5_AP
-> start UDP client to C5
-> start camera web server
-> init INMP441
-> init BH1750
-> init DHT11
-> play LCD animation
-> loop reading light/temp/humi/noise and log values
```

## LCD Facts

- Driver style: ST7789
- Resolution: 240 x 320
- SPI host: `SPI2_HOST`
- SCLK: GPIO21
- MOSI: GPIO47
- MISO: GPIO48
- CS: GPIO42
- DC / RS: GPIO41
- RST: -1
- Color order: BGR
- SPI clock: 27 MHz
- Touch is intentionally not used in this S3 display code.

Reusable functions:

- `lcd_display_init()`
- `lcd_fill_screen()`
- `lcd_fill_rect()`
- `lcd_draw_rect()`
- `lcd_draw_string()`
- `lcd_draw_string_center()`
- `lcd_show_echoforest_demo()`
- `lcd_play_boot_animation()`

## Sensor Facts

BH1750:

- I2C port: `I2C_NUM_0`
- SDA: GPIO5
- SCL: GPIO4
- Address: `0x23`
- Current main conversion: `light = bh1750_read_data() / 1.2`

DHT11:

- Current S3 zip DATA pin: GPIO0
- Earlier notes mentioned GPIO13. This is a conflict that needs hardware confirmation.
- Functions: `dht11_init()`, `dht11_read_data(&temperature, &humidity)`

INMP441:

- BCLK: GPIO35
- WS: GPIO36
- DIN: GPIO37
- I2S port: `I2S_NUM_0`
- Sample rate: 16000
- Data width: 32-bit
- Slot mode: mono, left slot
- Block size: 512
- Algorithm: mean removal, spike filtering, RMS, smoothing
- Current main conversion: `db_raw = 20.0f * log10f(rms + 1.0f)`

## Wi-Fi, UDP, And Camera Facts

Current S3 code connects to the C5 hotspot:

- SSID: `C5_AP`
- Password: `12345678`

Current UDP target:

- IP: `192.168.4.1`
- Port: `3333`
- Sends `S3_CONNECTED`
- Waits for `ACK_FROM_C5`

The S3 zip also includes an OV2640 camera web server on port 80. Camera recognition remains out of scope for EchoForest Phase 1.

## EchoForest Integration Decision

Use this S3 project as hardware driver evidence, not as the final state architecture.

Keep EchoForest state flow backend-centered:

```text
S3 -> backend /api/device_data
C5 -> backend session APIs and /api/state
Web -> backend /api/state
```

Do not continue using S3-C5 UDP as the main state synchronization path.

## Updated Next Step

The next useful firmware task should be an S3 real-sensor adapter task:

1. Copy `firmware_modules/common` and `firmware_modules/s3` into the S3 base project.
2. Replace S3 `sensor_mock` with an adapter over existing BH1750, DHT11, and INMP441 functions.
3. Replace S3 UDP status sync with HTTP POST `/api/device_data`.
4. Keep camera disabled or isolated.
5. Render backend response with simple LCD text first, not final animation.

