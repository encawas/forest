#include "main_screen_renderer.h"

#include <string.h>
#include "esp_log.h"

static const char *TAG = "echoforest_s3_screen";

static void log_scene(const char *scene_name, const echoforest_state_t *state)
{
    if (state == NULL) {
        ESP_LOGW(TAG, "%s: missing state", scene_name);
        return;
    }

    ESP_LOGI(TAG, "%s state=%s line1=%s line2=%s message=%s",
             scene_name,
             state->forest_state,
             state->screen_line1,
             state->screen_line2,
             state->message);
}

static void draw_growing_scene(const echoforest_state_t *state)
{
    log_scene("draw_growing_scene", state);
}

static void draw_low_light_scene(const echoforest_state_t *state)
{
    log_scene("draw_low_light_scene", state);
}

static void draw_noisy_scene(const echoforest_state_t *state)
{
    log_scene("draw_noisy_scene", state);
}

static void draw_uncomfortable_scene(const echoforest_state_t *state)
{
    log_scene("draw_uncomfortable_scene", state);
}

static void draw_completed_scene(const echoforest_state_t *state)
{
    log_scene("draw_completed_scene", state);
}

static void draw_rest_scene(const echoforest_state_t *state)
{
    log_scene("draw_rest_scene", state);
}

static void draw_idle_scene(const echoforest_state_t *state)
{
    log_scene("draw_idle_scene", state);
}

void main_screen_init(void)
{
    /*
     * TODO: Connect these placeholders to HSD024290 LCD drawing code after
     * the S3 base project is available. Replace logs with text, images, and
     * lightweight animation rendering later.
     */
    ESP_LOGI(TAG, "main forest screen renderer initialized as log-only skeleton");
}

void main_screen_show_state(const echoforest_state_t *state)
{
    if (state == NULL) {
        main_screen_show_error("missing backend state");
        return;
    }

    if (strcmp(state->forest_state, "growing") == 0) {
        draw_growing_scene(state);
    } else if (strcmp(state->forest_state, "low_light") == 0) {
        draw_low_light_scene(state);
    } else if (strcmp(state->forest_state, "noisy") == 0) {
        draw_noisy_scene(state);
    } else if (strcmp(state->forest_state, "uncomfortable") == 0) {
        draw_uncomfortable_scene(state);
    } else if (strcmp(state->forest_state, "completed") == 0) {
        draw_completed_scene(state);
    } else if (strcmp(state->forest_state, "recovering") == 0) {
        draw_rest_scene(state);
    } else {
        draw_idle_scene(state);
    }
}

void main_screen_show_error(const char *message)
{
    ESP_LOGW(TAG, "screen error: %s", message != NULL ? message : "unknown error");
}
