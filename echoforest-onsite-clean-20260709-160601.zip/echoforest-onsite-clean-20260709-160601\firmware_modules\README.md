# EchoForest 固件交互骨架

这个目录不是一个完整的 ESP-IDF 工程。这里放的是可复用模块，后续需要复制到现有的 ESP32-S3 和 ESP32-C5 ESP-IDF 基础工程里使用。

## 架构原则

- 后端是唯一状态中心。
- Web、S3、C5 都读取或更新后端状态。
- S3 和 C5 不直接同步复杂状态。
- ESP32 访问本地后端时必须使用电脑局域网 IP，例如 `http://<PC-LAN-IP>:3000`。
- ESP32 不能使用 `localhost`，因为那会指向 ESP32 自己。

## S3 角色

ESP32-S3 负责：

- 上传环境传感器数据。
- 驱动主森林屏。
- 第一版先使用 mock sensor 数据。
- 后续再替换为 BH1750、INMP441、DHT11 的真实读取。

已知 S3 信息：

- 控制器：ESP32-S3
- 屏幕：HSD024290
- 分辨率：240 x 320
- 用途：主森林屏
- 真实 LCD 驱动代码还未接入，所以当前 renderer 只输出日志占位。

## C5 角色

ESP32-C5 负责：

- 触摸控制。
- 控制/状态/环境数据显示。
- 后续可接入 TTS。

已知 C5 信息：

- 控制器：ESP32-C5
- 屏幕：P183B001
- LCD 风格：ST7789V
- 分辨率：240 x 284
- LCD SPI：GPIO23/24/25/26/5
- Touch I2C：GPIO2/3，地址 `0x15`

## 本骨架已经包含

- `common/echoforest_protocol.h`：协议结构体、动作枚举、后端 API 路径常量。
- `common/cloud_client.c/.h`：HTTP JSON 客户端骨架。
- `common/wifi_manager.c/.h`：Wi-Fi STA wrapper 骨架。
- `s3/sensor_mock.c/.h`：S3 mock 环境数据。
- `s3/sensor_real_adapter.c/.h`：S3 真实 BH1750 / DHT11 / INMP441 适配骨架。
- `s3/s3_app.c/.h`：S3 mock 上传闭环。
- `s3/main_screen_renderer.c/.h`：S3 主森林屏 renderer 占位。
- `c5/touch_actions.c/.h`：C5 非阻塞触摸动作抽象占位。
- `c5/c5_app.c/.h`：C5 控制端状态轮询和会话动作闭环。
- `c5/control_screen_renderer.c/.h`：C5 控制屏 renderer 占位。

## 本骨架故意不包含

- 真实 LCD 驱动。
- 真实 P183B001 驱动。
- 真实 HSD024290 驱动。
- 真实 touch driver。
- 真实 BH1750 driver。
- 真实 INMP441 噪声算法。
- 真实 DHT11 driver。
- 最终森林动画。
- S3 与 C5 直接通信。

## 配置方式

在真实 ESP-IDF 工程里：

1. 把 `common/echoforest_config.example.h` 复制为 `echoforest_config.h`。
2. 填入本地 Wi-Fi 名称和密码。
3. 填入后端地址，格式类似：

```c
#define ECHOFOREST_BACKEND_BASE_URL "http://192.168.1.23:3000"
```

不要提交真实 Wi-Fi SSID、真实 Wi-Fi 密码或个人电脑固定 IP。

## 接入方式

推荐复制方式：

- 把 `common` 模块复制到 S3 和 C5 两个工程。
- 把 `s3` 模块复制到 S3 工程。
- 把 `c5` 模块复制到 C5 工程。
- 把 S3 renderer 函数接到现有 HSD024290 LCD 绘制代码。
- 把 C5 renderer 函数接到现有 P183B001 ST7789V 绘制代码。
- 把 `touch_actions_read()` 接到现有 C5 触摸读取代码。
- 用真实传感器读取替换 `sensor_mock`。

第一轮硬件闭环建议：

```text
C5 触摸开始学习
-> POST /api/session/start
-> S3 mock 或真实传感器上传 /api/device_data
-> 后端计算 forest_state
-> Web 显示状态
-> C5 显示 mode/state/sensor data
-> S3 显示主森林状态
-> C5 或 Web 结束学习
```

## S3 zip 新确认信息

2026-07-09 收到的 S3 zip 已确认部分真实 S3 基础工程信息：

- Target：ESP32-S3
- ESP-IDF：5.5.4
- LCD：ST7789 风格，240 x 320
- LCD SPI：SCLK GPIO21，MOSI GPIO47，MISO GPIO48，CS GPIO42，DC GPIO41，RST -1
- LCD color order：BGR
- BH1750：I2C_NUM_0，SDA GPIO5，SCL GPIO4，地址 0x23
- DHT11：S3 zip 使用 GPIO0；早先记录过 GPIO13，需要最终确认
- INMP441：BCLK GPIO35，WS GPIO36，DIN GPIO37，I2S_NUM_0，16 kHz，32-bit mono left slot

S3 zip 当前仍是旧硬件 demo：

- S3 连接 C5_AP
- 代码中硬编码了 `12345678`
- S3 通过 UDP 发往 `192.168.4.1:3333`
- S3 启动 camera web server

EchoForest 主链路不继续依赖 S3-C5 UDP。后续应复用其中 LCD 和传感器代码，但把状态同步改成后端 HTTP API。

## 现场配置工具

仓库里的 `field_config` 目录提供现场配置工具：

```cmd
field_config\configure.cmd
```

它可以生成 `echoforest_field_config.h`，也可以自动 patch S3 基础工程：

- `components\dht11\dht11.h` 的 DHT11 引脚改为引用 `ECHOFOREST_DHT11_PIN`
- `components\WIFISTA\wifista.h` 的 Wi-Fi SSID/password 改为引用生成配置

S3/C5 app 也提供了从该配置初始化的入口：

- `s3_app_init_from_field_config()`
- `c5_app_init_from_field_config()`

现场同学后续只需要改配置，不需要在多个源码文件里找数字。
