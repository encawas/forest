#ifndef ECHOFOREST_C5_APP_H
#define ECHOFOREST_C5_APP_H

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t c5_app_init(const char *wifi_ssid, const char *wifi_password, const char *backend_base_url);
esp_err_t c5_app_init_from_field_config(void);
void c5_app_run_once(void);

#ifdef __cplusplus
}
#endif

#endif
