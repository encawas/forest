import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const appSource = readFileSync(join(root, 'src', 'App.jsx'), 'utf8');
const stylesSource = readFileSync(join(root, 'src', 'styles.css'), 'utf8');
const packageJson = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));

describe('frontend console source contract', () => {
  it('uses only approved minimal dependencies', () => {
    assert.deepEqual(Object.keys(packageJson.dependencies).sort(), ['react', 'react-dom', 'vite']);
  });

  it('contains all required reference UI landmarks', () => {
    [
      'EchoForest 控制台',
      '第一阶段控制台',
      '森林生长度',
      '学习任务',
      '环境数据',
      '设备反馈预览',
      '最新学习日志',
      '开始学习',
      '结束学习',
      '开始休息',
      '刷新状态',
    ].forEach((label) => assert.match(appSource, new RegExp(label)));
  });

  it('contains visual QA copy and device feedback descriptions', () => {
    [
      '暂无学习日志。点击“结束学习”后，这里会显示本轮目标、用时和总结。',
      '待机灯效',
      '专注灯效',
      '环境提醒音',
      '无提示音',
      'device-feedback-description',
    ].forEach((label) => assert.match(appSource, new RegExp(label)));
  });

  it('keeps rest action wired to the existing recover endpoint', () => {
    assert.match(appSource, /recover:\s*'\/api\/session\/recover'/);
    assert.match(appSource, /handleAction\('recover'\)/);
    assert.doesNotMatch(appSource, /开始恢复/);
  });

  it('calls the required backend endpoints', () => {
    [
      '/api/state',
      '/api/session/start',
      '/api/session/end',
      '/api/session/recover',
    ].forEach((endpoint) => assert.match(appSource, new RegExp(endpoint.replaceAll('/', '\\/'))));
  });

  it('polls the required state endpoint', () => {
    assert.match(appSource, /fetch\('\/api\/state'\)/);
    assert.match(appSource, /setInterval\(refreshState,\s*3000\)/);
  });

  it('references all required API fields', () => {
    [
      'mode',
      'forest_state',
      'light',
      'noise',
      'temp',
      'humi',
      'screen_line1',
      'screen_line2',
      'rgb_mode',
      'buzzer_mode',
      'message',
      'task_title',
      'log',
      'counts',
      'device_id',
      'button',
      'camera_used',
    ].forEach((field) => assert.match(appSource, new RegExp(field)));
  });

  it('keeps state enum values unchanged', () => {
    [
      'normal',
      'growing',
      'low_light',
      'noisy',
      'uncomfortable',
      'completed',
      'recovering',
    ].forEach((state) => assert.match(appSource, new RegExp(state)));
  });

  it('does not hardcode backend URLs or fake local environment logic', () => {
    assert.doesNotMatch(appSource, /http:\/\/localhost:3000/);
    assert.doesNotMatch(appSource, /127\.0\.0\.1:3000/);
    assert.doesNotMatch(appSource, /Math\.random/);
    assert.doesNotMatch(appSource, /simulateEnvironment/);
    assert.doesNotMatch(appSource, /fonts\.googleapis\.com/);
    ['healthy', 'stuffy', 'dim'].forEach((term) => {
      assert.doesNotMatch(appSource, new RegExp(term));
    });
  });

  it('contains reference theme and visual QA CSS hooks', () => {
    [
      '--bg-deep',
      '--panel',
      '--moss-bright',
      '.site-header',
      '.hero',
      '.sensor-card',
      '.device-screen',
      '.growth-badge',
      '.rest-button',
      '.device-feedback-description',
      '.log-empty',
    ].forEach((token) => assert.match(stylesSource, new RegExp(token.replaceAll('.', '\\.'))));
  });
});
