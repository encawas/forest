#ifndef ECHOFOREST_CLOUD_CLIENT_H
#define ECHOFOREST_CLOUD_CLIENT_H

#include "esp_err.h"
#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    char base_url[128];
} cloud_client_config_t;

esp_err_t cloud_client_init(const cloud_client_config_t *config);

esp_err_t cloud_client_post_device_data(
    const echoforest_device_data_t *device_data,
    echoforest_state_t *out_state
);

esp_err_t cloud_client_get_state(echoforest_state_t *out_state);

esp_err_t cloud_client_start_session(
    const char *target_text,
    echoforest_state_t *out_state
);

esp_err_t cloud_client_end_session(echoforest_state_t *out_state);

esp_err_t cloud_client_start_recovery(echoforest_state_t *out_state);

#ifdef __cplusplus
}
#endif

#endif
