#include "control_screen_renderer.h"

#include "esp_log.h"

static const char *TAG = "echoforest_c5_screen";

void control_screen_init(void)
{
    /*
     * TODO: Connect this renderer to existing P183B001 ST7789V LCD primitives.
     * Add TTS only on state change later, not on every polling tick.
     */
    ESP_LOGI(TAG, "C5 control screen renderer initialized as log-only skeleton");
}

void control_screen_show_state(const echoforest_state_t *state)
{
    if (state == NULL) {
        ESP_LOGW(TAG, "missing backend state");
        return;
    }

    ESP_LOGI(TAG,
             "mode=%s forest_state=%s line1=%s line2=%s light=%.1f noise=%.1f temp=%.1f humi=%.1f task=%s sessions=%d",
             state->mode,
             state->forest_state,
             state->screen_line1,
             state->screen_line2,
             state->light,
             state->noise,
             state->temp,
             state->humi,
             state->task_title,
             state->sessions_completed);
}

void control_screen_show_network_status(bool connected)
{
    ESP_LOGI(TAG, "network connected=%s", connected ? "true" : "false");
}

void control_screen_show_upload_status(bool ok)
{
    ESP_LOGI(TAG, "backend request ok=%s", ok ? "true" : "false");
}
