@echo off
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo === EchoForest Hardware Delivery Review ===
echo.

for %%F in (
  "START_HERE_ONSITE.md"
  "DELIVERY_MANIFEST.md"
  "docs\onsite_handoff_workflow.md"
  "docs\future_task_plan.md"
  "docs\field_config_tool.md"
  "docs\s3_base_project_inspection.md"
  "docs\firmware_limitations_missing_info.md"
  "docs\firmware_test_instructions.md"
  "field_config\configure.cmd"
  "field_config\apply_config.js"
  "field_config\config.local.example.json"
  "firmware_modules\s3\sensor_real_adapter.c"
  "firmware_modules\s3\sensor_real_adapter.h"
  "firmware_modules\s3\s3_app.c"
  "firmware_modules\c5\c5_app.c"
  "firmware_modules\c5\touch_actions.c"
  "scripts\review_field_config.cmd"
  "scripts\review_firmware_skeleton.cmd"
  "scripts\create_onsite_package.cmd"
) do (
  if not exist %%F (
    echo FAIL: missing %%F
    exit /b 1
  )
)

findstr /C:"field_config\configure.cmd" "START_HERE_ONSITE.md" >nul || (echo FAIL: START_HERE missing config entry & exit /b 1)
findstr /C:"Patch S3" "START_HERE_ONSITE.md" >nul || (echo FAIL: START_HERE missing S3 patch instruction & exit /b 1)
findstr /C:"Patch C5" "START_HERE_ONSITE.md" >nul || (echo FAIL: START_HERE missing C5 patch instruction & exit /b 1)
findstr /C:"review_hardware_delivery.cmd" "DELIVERY_MANIFEST.md" >nul || (echo FAIL: manifest missing hardware review script & exit /b 1)
findstr /C:"create_onsite_package.cmd" "DELIVERY_MANIFEST.md" >nul || (echo FAIL: manifest missing package script & exit /b 1)
findstr /C:"docs\future_task_plan.md" "DELIVERY_MANIFEST.md" >nul || (echo FAIL: manifest missing future task plan & exit /b 1)
findstr /C:"docs\future_task_plan.md" "START_HERE_ONSITE.md" >nul || (echo FAIL: START_HERE missing future task plan & exit /b 1)

findstr /C:"field_config\configure.cmd" "docs\onsite_handoff_workflow.md" >nul || (echo FAIL: onsite workflow missing config entry & exit /b 1)
findstr /C:"Patch S3 base project" "docs\onsite_handoff_workflow.md" >nul || (echo FAIL: onsite workflow missing S3 patch step & exit /b 1)
findstr /C:"s3_app_run_once_real_sensors" "docs\onsite_handoff_workflow.md" >nul || (echo FAIL: onsite workflow missing S3 real sensor loop & exit /b 1)
findstr /C:"touch_actions_map_point" "docs\onsite_handoff_workflow.md" >nul || (echo FAIL: onsite workflow missing C5 touch map helper & exit /b 1)
findstr /C:"field_config\configure.cmd" "docs\future_task_plan.md" >nul || (echo FAIL: future task plan missing config tool entry & exit /b 1)
findstr /C:"POST /api/device_data" "docs\future_task_plan.md" >nul || (echo FAIL: future task plan missing device_data loop & exit /b 1)
findstr /C:"POST /api/session/start" "docs\future_task_plan.md" >nul || (echo FAIL: future task plan missing C5 start action & exit /b 1)

findstr /C:"--patch-s3-base" "field_config\apply_config.js" >nul || (echo FAIL: field config missing S3 patch command & exit /b 1)
findstr /C:"--patch-c5-base" "field_config\apply_config.js" >nul || (echo FAIL: field config missing C5 patch command & exit /b 1)
findstr /C:"sensor_real_adapter_read" "firmware_modules\s3\sensor_real_adapter.c" >nul || (echo FAIL: missing real sensor adapter read & exit /b 1)
findstr /C:"s3_app_init_from_field_config" "firmware_modules\s3\s3_app.c" >nul || (echo FAIL: missing S3 field config init & exit /b 1)
findstr /C:"c5_app_init_from_field_config" "firmware_modules\c5\c5_app.c" >nul || (echo FAIL: missing C5 field config init & exit /b 1)
findstr /C:"touch_actions_map_point" "firmware_modules\c5\touch_actions.c" >nul || (echo FAIL: missing touch action map helper & exit /b 1)
findstr /C:"field_config\config.local.json" "scripts\create_onsite_package.cmd" >nul || (echo FAIL: package script missing local field config & exit /b 1)
findstr /C:"field_config\generated\echoforest_field_config.h" "scripts\create_onsite_package.cmd" >nul || (echo FAIL: package script missing generated field config & exit /b 1)
findstr /C:"package-lock.json" "scripts\create_onsite_package.cmd" >nul || (echo FAIL: package script must exclude lockfiles & exit /b 1)

call scripts\review_field_config.cmd
if %ERRORLEVEL% neq 0 (
  echo FAIL: field config review failed
  exit /b 1
)

call scripts\review_firmware_skeleton.cmd
if %ERRORLEVEL% neq 0 (
  echo FAIL: firmware skeleton review failed
  exit /b 1
)

echo Git status:
git status --short --untracked-files=all
if %ERRORLEVEL% neq 0 exit /b 1

echo.
echo PASS
exit /b 0
