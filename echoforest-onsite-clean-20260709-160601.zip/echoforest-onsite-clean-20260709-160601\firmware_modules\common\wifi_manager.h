#ifndef ECHOFOREST_WIFI_MANAGER_H
#define ECHOFOREST_WIFI_MANAGER_H

#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t wifi_manager_init_sta(const char *ssid, const char *password);
bool wifi_manager_is_connected(void);

#ifdef __cplusplus
}
#endif

#endif
