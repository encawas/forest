# EchoForest Onsite Handoff Workflow

这份文档给现场硬件同学使用。目标是：现场自己配置、自己调数值、自己 patch S3/C5 工程，不需要项目负责人到现场反复看日志。

## 0. 现场需要准备

- 一台运行后端和网页的电脑。
- ESP32-S3 基础工程。
- ESP32-C5 基础工程。
- Node.js。
- ESP-IDF 编译/烧录环境。

## 1. 启动软件侧

后端：

```cmd
cd /d "项目目录\backend"
npm.cmd install --no-package-lock
npm.cmd start
```

前端：

```cmd
cd /d "项目目录\frontend"
npm.cmd install --no-package-lock
npm.cmd run dev
```

网页：

```text
http://localhost:5173/
```

电脑局域网 IP 用下面命令看：

```cmd
ipconfig
```

ESP32 后端地址必须写成：

```text
http://电脑局域网IP:3000
```

不要写 `localhost`。

## 2. 打开现场配置工具

在 EchoForest 项目根目录运行：

```cmd
field_config\configure.cmd
```

先选择：

```text
1. Edit backend, Wi-Fi, sensor thresholds
```

填写：

- backend URL，例如 `http://192.168.1.23:3000`
- Wi-Fi 名称
- Wi-Fi 密码
- DHT11 GPIO，默认 `0`
- 光照阈值
- 噪声阈值
- 温湿度范围

再选择：

```text
5. Generate echoforest_field_config.h
```

## 3. Patch S3 工程

在配置工具菜单里选择：

```text
8. Patch S3 base project DHT11/Wi-Fi config
```

输入 S3 工程根目录，例如：

```text
D:\s3_project
```

脚本会自动：

- 复制 `echoforest_field_config.h`
- 修改 `components\dht11\dht11.h`
- 修改 `components\WIFISTA\wifista.h`

改完后，S3 工程里的 DHT11 引脚和 Wi-Fi 就跟随配置文件。

## 4. 复制到 C5 工程

在配置工具菜单里选择：

```text
7. Copy generated header to C5 project
```

输入 C5 工程根目录，例如：

```text
D:\c5_project
```

脚本会复制：

```text
D:\c5_project\main\echoforest_field_config.h
```

If they also need a C5 touch-area helper, choose:

```text
9. Patch C5 base project touch helper
```

It also generates:

```text
D:\c5_project\main\echoforest_c5_touch_bridge.h
```

After the existing C5 touch code reads a point, call:

```c
int action = echoforest_field_touch_action_id(x, y);
printf("TOUCH_ACTION=%s\n", echoforest_field_touch_action_name(action));
```

Then tune touch rectangles in `field_config\configure.cmd`.

## 5. S3 固件接入建议

S3 app 优先使用：

```c
s3_app_init_from_field_config();
s3_app_run_once_real_sensors();
```

真实传感器适配文件：

```text
firmware_modules\s3\sensor_real_adapter.c
firmware_modules\s3\sensor_real_adapter.h
```

它会把 S3 工程里的：

- BH1750
- DHT11
- INMP441

转换成 EchoForest 上传字段：

```text
light
noise
temp
humi
```

## 6. C5 固件接入建议

C5 app 优先使用：

```c
c5_app_init_from_field_config();
c5_app_run_once();
```

触摸驱动读到坐标后，用：

```c
touch_actions_map_point(x, y)
```

它会按配置文件里的按钮区域返回：

```text
ECHOFOREST_ACTION_START
ECHOFOREST_ACTION_REST
ECHOFOREST_ACTION_END
```

## 7. 现场调参方式

如果现场觉得阈值不合适，不要手改源码。

重新运行：

```cmd
field_config\configure.cmd
```

改配置，然后重新生成和复制。

常见调整：

- 光线过暗误报：降低 `low_light_threshold`
- 光线过暗不报：提高 `low_light_threshold`
- 噪声误报：提高 `noise_threshold`
- 噪声不报：降低 `noise_threshold`
- 触摸按钮不准：调整对应按钮的 x1/y1/x2/y2

## 8. 成功标准

最小成功闭环：

```text
C5 或网页开始学习
-> S3 上传真实 light/noise/temp/humi
-> 后端返回 forest_state
-> 网页显示真实数据
-> S3 显示后端状态
-> C5 显示后端状态
-> C5 或网页结束学习
```

如果硬件暂时不稳定，保留 simulator 作为软件演示备用。

## 9. 不做的事

当前阶段不做：

- camera recognition
- full forest animation
- real LLM API
- database
- login
- WebSocket
- S3-C5 direct state sync
