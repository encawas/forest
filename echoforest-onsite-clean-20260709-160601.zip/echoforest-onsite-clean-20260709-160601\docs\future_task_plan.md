# EchoForest 后续任务计划

这份计划给项目后续接手的同学和现场硬件同学看。目标不是继续扩大功能，而是把当前软件闭环逐步推进到 S3/C5 真机闭环。

## 总原则

- 后端是唯一状态中心，S3、C5、网页都跟随后端状态。
- S3 和 C5 不做复杂直接同步，不把 UDP 当主状态链路。
- 现场调参优先使用 `field_config\configure.cmd`，不要到处手改源码里的数字。
- 现场认为好的 Wi-Fi、后端 IP、DHT11 引脚、阈值、触摸区域，都写进配置工具，由脚本生成代码。
- 调试类问题由现场跑脚本、看网页和串口日志确认，不要求项目负责人到现场。
- 第一版只追求可测试闭环，不做数据库、登录、WebSocket、真实 LLM、摄像头识别、完整森林动画。

## 任务 0：软件闭环基线确认

负责人：任何本地开发同学。

目标：
- 确认后端、前端、模拟器仍然可跑。
- 确认网页能显示 `light/noise/temp/humi` 和 `forest_state`。

操作：
```cmd
scripts\verify.cmd
scripts\review_hardware_delivery.cmd
```

如果 `scripts\verify.cmd` 因前端依赖安装超时失败，先记录环境问题，再至少跑：
```cmd
scripts\review_hardware_delivery.cmd
```

通过标准：
- 后端测试通过。
- 交付 review 输出 `PASS`。
- 模拟器 cycle 能让网页状态变化。

## 任务 1：现场配置入口确认

负责人：现场硬件同学。

目标：
- 现场能用一个菜单配置全部可变参数。
- 不再手动到多个源码文件里改 Wi-Fi、IP、引脚和阈值。

操作：
```cmd
field_config\configure.cmd
```

需要现场填写：
- 电脑后端地址，例如 `http://192.168.1.23:3000`
- Wi-Fi 名称和密码
- DHT11 GPIO，当前 S3 zip 里观察到的是 `GPIO0`
- 光照阈值
- 噪声阈值
- 温湿度舒适范围
- C5 START / REST / END 触摸区域

通过标准：
- 能生成 `field_config\generated\echoforest_field_config.h`。
- 配置里不使用 `localhost`。
- ESP32 使用电脑局域网 IP。

## 任务 2：S3 基础工程 patch

负责人：现场 S3 同学。

目标：
- 把现场配置自动写入 S3 基础工程。
- DHT11 引脚和 Wi-Fi 不再硬编码在原工程里。

操作：
```cmd
field_config\configure.cmd
```

菜单选择：
```text
8. Patch S3 base project DHT11/Wi-Fi config
```

通过标准：
- S3 工程里生成或更新 `echoforest_field_config.h`。
- `components\dht11\dht11.h` 使用 `ECHOFOREST_DHT11_PIN`。
- `components\WIFISTA\wifista.h` 使用 `ECHOFOREST_WIFI_SSID` 和 `ECHOFOREST_WIFI_PASSWORD`。
- S3 编译时不需要手动再改这些数值。

## 任务 3：S3 传感器上传闭环

负责人：现场 S3 同学。

目标：
- S3 读取真实或 mock 的 `light/noise/temp/humi`。
- S3 调用 `POST /api/device_data`。
- 后端返回 `forest_state`。
- 网页显示 S3 上传的数据。

推荐顺序：
1. 先跑 mock 上传。
2. 再接 DHT11。
3. 再接 BH1750。
4. 最后接 INMP441。

原因：
- DHT11 和 BH1750 更容易稳定读数。
- INMP441 噪声值需要现场校准，先不要阻塞主闭环。

通过标准：
- 串口日志能看到上传 payload。
- 后端返回 `forest_state`。
- 网页环境数据不是 `--`。
- 改变光照、噪声或温湿度后，网页状态能变化。

## 任务 4：C5 基础工程 patch

负责人：现场 C5 同学。

目标：
- C5 使用同一份现场配置。
- C5 触摸点能映射成 START / REST / END。

操作：
```cmd
field_config\configure.cmd
```

菜单选择：
```text
9. Patch C5 base project touch helper
```

通过标准：
- C5 工程 `main` 目录里有 `echoforest_field_config.h`。
- C5 工程 `main` 目录里有 `echoforest_c5_touch_bridge.h`。
- 触摸 demo 读到坐标后，调用：

```c
int action = echoforest_field_touch_action_id(x, y);
const char *name = echoforest_field_touch_action_name(action);
```

- 点 START 区域输出 START。
- 点 REST 区域输出 REST。
- 点 END 区域输出 END。

## 任务 5：C5 控制后端闭环

负责人：现场 C5 同学。

目标：
- C5 触摸 START 调用 `POST /api/session/start`。
- C5 触摸 REST 调用 `POST /api/session/recover`。
- C5 触摸 END 调用 `POST /api/session/end`。
- C5 空闲时轮询 `GET /api/state`。

通过标准：
- C5 点开始后，网页 mode 变成 `focus`。
- C5 点休息后，网页显示休息状态。
- C5 点结束后，网页出现最新学习日志。
- C5 屏幕或串口能显示后端返回的 mode、forest_state、传感器数据。

## 任务 6：S3 主屏显示接入

负责人：现场 S3 显示同学。

目标：
- 先显示文字状态，不急着做完整动画。
- 用后端返回的 `screen_line1/screen_line2/message/forest_state` 驱动屏幕。

推荐顺序：
1. 只显示文字。
2. 加简单颜色或图标。
3. 再做低光、噪声、温湿度提示画面。
4. 最后再做森林成长动画。

通过标准：
- `growing` 显示专注/成长。
- `low_light` 显示光线提醒。
- `noisy` 显示噪声提醒。
- `uncomfortable` 显示温湿度提醒。
- `completed` 显示完成。
- `recovering` 显示休息。

## 任务 7：C5 控制屏显示接入

负责人：现场 C5 显示同学。

目标：
- C5 显示当前模式、状态、传感器数据和操作反馈。
- TTS 可以预留，但不阻塞第一版闭环。

通过标准：
- C5 能显示 mode。
- C5 能显示 forest_state。
- C5 能显示 light/noise/temp/humi。
- C5 能显示最近一次操作是否成功。
- TTS 如接入，只在状态变化时播报，不要每次轮询都播报。

## 任务 8：现场阈值调参

负责人：现场硬件同学。

目标：
- 找到现场可接受的光照、噪声、温湿度阈值。
- 所有阈值通过 `field_config\configure.cmd` 修改。

调参规则：
- 光线太暗却不提醒：提高 `low_light_threshold`。
- 光线正常却提醒太暗：降低 `low_light_threshold`。
- 噪声大却不提醒：降低 `noise_threshold`。
- 安静环境却提醒噪声：提高 `noise_threshold`。
- 温湿度提醒不符合现场感受：调整 temp/humi min/max。

通过标准：
- 现场同学认为提醒时机基本合理。
- 修改阈值不需要手改多个源码文件。
- 重新生成配置、重新编译烧录后行为生效。

## 任务 9：真机最小演示冻结

负责人：现场硬件同学 + 项目整理同学。

目标：
- 冻结一个能稳定演示的组合版本。

演示流程：
1. 后端启动。
2. 前端启动。
3. C5 点开始学习。
4. S3 上传真实传感器数据。
5. 网页显示数据和状态。
6. S3 显示状态。
7. C5 显示状态。
8. C5 或网页结束学习。
9. 网页出现学习日志。

通过标准：
- 连续演示 3 次不需要改代码。
- 若现场网络 IP 变化，只需要重跑配置工具。
- 若阈值不合适，只需要重跑配置工具。

## 暂不做清单

以下内容不要塞进第一版真机闭环：

- 数据库
- 登录
- WebSocket
- 真实 LLM API
- 摄像头识别
- S3/C5 复杂直连同步
- 完整森林动画
- 长时间后台历史统计

## 交付给现场时的最短说明

把压缩包发给现场后，让他们先看：

```text
START_HERE_ONSITE.md
```

需要改数值时只跑：

```cmd
field_config\configure.cmd
```

需要重新打包时只跑：

```cmd
scripts\create_onsite_package.cmd
```
