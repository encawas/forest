#include "touch_actions.h"

#include <stdbool.h>
#include "esp_log.h"

#if __has_include("echoforest_field_config.h")
#include "echoforest_field_config.h"
#else
#define ECHOFOREST_TOUCH_START_X1 20
#define ECHOFOREST_TOUCH_START_Y1 20
#define ECHOFOREST_TOUCH_START_X2 220
#define ECHOFOREST_TOUCH_START_Y2 90
#define ECHOFOREST_TOUCH_REST_X1 20
#define ECHOFOREST_TOUCH_REST_Y1 105
#define ECHOFOREST_TOUCH_REST_X2 220
#define ECHOFOREST_TOUCH_REST_Y2 175
#define ECHOFOREST_TOUCH_END_X1 20
#define ECHOFOREST_TOUCH_END_Y1 190
#define ECHOFOREST_TOUCH_END_X2 220
#define ECHOFOREST_TOUCH_END_Y2 260
#endif

static const char *TAG = "echoforest_touch";

static bool point_in_rect(int x, int y, int x1, int y1, int x2, int y2)
{
    return x >= x1 && x <= x2 && y >= y1 && y <= y2;
}

void touch_actions_init(void)
{
    /*
     * TODO: Integrate existing P183B001 I2C touch code here.
     * Known C5 facts:
     * - Touch port: I2C_NUM_0
     * - SDA: GPIO2
     * - SCL: GPIO3
     * - Observed address: 0x15
     * - Coordinate transform: y = LCD_HEIGHT - 1 - raw_y
     *
     * Convert stable touch regions into:
     * - ECHOFOREST_ACTION_START
     * - ECHOFOREST_ACTION_END
     * - ECHOFOREST_ACTION_REST
     */
    ESP_LOGI(TAG, "touch action abstraction initialized as non-blocking placeholder");
}

echoforest_action_t touch_actions_read(void)
{
    return ECHOFOREST_ACTION_NONE;
}

echoforest_action_t touch_actions_map_point(int x, int y)
{
    if (point_in_rect(x, y,
                      ECHOFOREST_TOUCH_START_X1,
                      ECHOFOREST_TOUCH_START_Y1,
                      ECHOFOREST_TOUCH_START_X2,
                      ECHOFOREST_TOUCH_START_Y2)) {
        return ECHOFOREST_ACTION_START;
    }

    if (point_in_rect(x, y,
                      ECHOFOREST_TOUCH_REST_X1,
                      ECHOFOREST_TOUCH_REST_Y1,
                      ECHOFOREST_TOUCH_REST_X2,
                      ECHOFOREST_TOUCH_REST_Y2)) {
        return ECHOFOREST_ACTION_REST;
    }

    if (point_in_rect(x, y,
                      ECHOFOREST_TOUCH_END_X1,
                      ECHOFOREST_TOUCH_END_Y1,
                      ECHOFOREST_TOUCH_END_X2,
                      ECHOFOREST_TOUCH_END_Y2)) {
        return ECHOFOREST_ACTION_END;
    }

    return ECHOFOREST_ACTION_NONE;
}
