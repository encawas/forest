# EchoForest Firmware Integration Plan

## 1. Purpose

This document defines the firmware-cloud integration plan for EchoForest hardware.

The goal is to connect the ESP32-S3 / ESP32-C5 hardware system with the existing EchoForest backend and frontend dashboard.

The current software side already provides:

- Web dashboard
- Backend state API
- Device data upload API
- Device simulator
- Local demo flow

The next firmware goal is:

```text
ESP32 hardware uploads environment data
-> backend computes forest_state
-> backend returns display/control fields
-> hardware updates screens and local feedback
-> web dashboard shows the same state
```

This document is a planning document. It does not implement firmware code yet.

## 2. Known Hardware Information

### 2.1 Main Controllers

| Item | Information |
| --- | --- |
| Controller 1 | ESP32-S3 |
| Controller 2 | ESP32-C5 |
| Architecture | Dual controller |
| Development framework | ESP-IDF |
| Current status | Basic image display and simple touch code exist |
| Wi-Fi | Already available / expected to work |
| Backend integration | Local PC backend over LAN |

### 2.2 Screen Assignment

| Screen | Connected controller | Resolution | Current role |
| --- | --- | --- | --- |
| HSD024290 | ESP32-S3 | 240 x 320 | Main forest screen |
| P183B001 | ESP32-C5 | 240 x 284 | Control / touch / data screen |

Recommended screen responsibility:

ESP32-S3 + HSD024290:
Main forest screen, forest state, lightweight animation, `screen_line1`, `screen_line2`.

ESP32-C5 + P183B001:
Control screen, touch actions, environment data, `mode`, `forest_state`, upload/network status.

### 2.3 P183B001 Screen Information

| Item | Information |
| --- | --- |
| Screen model | P183B001 |
| Controller | ESP32-C5 |
| Resolution | 240 x 284 |
| LCD driver | ST7789V |
| Display interface | SPI |
| Touch | Works well |
| Recommended use | Control/data/touch screen |

Known P183B001 connector pins:

| Pin | Signal |
| --- | --- |
| 1 | GND |
| 2 | VCC3.3 |
| 3 | LCD SCL |
| 4 | LCD SDI |
| 5 | LCD RST |
| 6 | LCD RS |
| 7 | LCD BL |
| 8 | LCD SDO |
| 9 | LCD CS |
| 10 | TP CS |
| 11 | TP PEN |

Known ESP32-C5 LCD mapping from provided schematic/code:

| Signal | ESP32-C5 GPIO | Status |
| --- | --- | --- |
| LCD_CS | GPIO25 | Known |
| LCD_DC / LCD_RS | GPIO26 | Known |
| LCD_SCL | GPIO24 | From schematic |
| LCD_SDA / LCD_SDI | GPIO23 | From schematic |
| LCD_BLK / PWR_CTRL | GPIO5 | Needs confirmation |
| LCD_RST | Unknown | Missing |
| LCD_SDO | Unknown / maybe unused | Needs confirmation |

Touch information is currently inconsistent.

Earlier touch information:

```c
#define TP_I2C_PORT         I2C_NUM_0
#define TP_SCL_GPIO         GPIO_NUM_3
#define TP_SDA_GPIO         GPIO_NUM_2
```

Another provided I2C initialization snippet uses:

```c
.scl_io_num = GPIO_NUM_4,
.sda_io_num = GPIO_NUM_5,
```

But the P183B001 connector shows:

- TP CS
- TP PEN

Therefore, P183B001 touch interface must be confirmed.

Required confirmation:

- Is P183B001 touch I2C, SPI/resistive, or another interface?
- What is the touch chip model?
- What GPIOs are actually used for TP_SCL/TP_SDA or TP_CS/TP_PEN?

### 2.4 HSD024290 Screen Information

| Item | Information |
| --- | --- |
| Screen model | HSD024290 |
| Controller | ESP32-S3 |
| Resolution | 240 x 320 |
| Display interface | SPI |
| Touch | Poor touch effect |
| Recommended use | Main forest animation/status screen |
| LCD driver | Unknown |
| Current status | Already lights up |

Known connector pins are similar to the LCD/OLED connector:

| Pin | Signal |
| --- | --- |
| 1 | GND |
| 2 | VCC3.3 |
| 3 | LCD SCL |
| 4 | LCD SDI |
| 5 | LCD RST |
| 6 | LCD RS |
| 7 | LCD BL |
| 8 | LCD SDO |
| 9 | LCD CS |
| 10 | TP CS |
| 11 | TP PEN |

Known ESP32-S3 LCD-related schematic labels:

| Signal | ESP32-S3 GPIO | Status |
| --- | --- | --- |
| LCD_CS | GPIO42 | From schematic |
| LCD_RS / LCD_DC | GPIO41 | From schematic |
| LCD_SCL | GPIO14 | From schematic |
| LCD_SDI | GPIO21 | From schematic |
| LCD_SDO | GPIO48 | From schematic |
| LCD_RST | GPIO45 | From schematic |
| TP_CS | GPIO46 | From schematic |
| TP_PEN | GPIO2 | From schematic |

Potential shared SPI labels also appear:

| Signal | ESP32-S3 GPIO | Note |
| --- | --- | --- |
| SPI_MISO | GPIO40 | Needs confirmation |
| SPI_SCK | GPIO39 | Needs confirmation |
| SPI_MOSI | GPIO38 | Needs confirmation |

Required confirmation:

- Which SPI pin group is used by the actual HSD024290 display code?
- What is the HSD024290 driver chip?
- Can hardware teammates provide `lcd.c` / `lcd.h` / `spi.c` / `spi.h` for the working display test?

### 2.5 Sensors

| Sensor | Purpose | Known information |
| --- | --- | --- |
| BH1750 | light | I2C light sensor |
| INMP441 | noise | I2S microphone |
| DHT11 | temp / humi | temperature and humidity |

Known INMP441 pins:

```c
#define I2S_MIC_BCLK_GPIO    GPIO_NUM_35
#define I2S_MIC_WS_GPIO      GPIO_NUM_36
#define I2S_MIC_DIN_GPIO     GPIO_NUM_37
```

Known DHT11 pin:

```c
#define DHT11_DQ_GPIO_PIN    GPIO_NUM_13
```

Missing BH1750 details:

- BH1750 SDA GPIO
- BH1750 SCL GPIO
- I2C port
- I2C address, likely `0x23` but not confirmed

Missing INMP441 details:

- I2S port
- Sample rate
- Sample bits
- Noise algorithm: RMS / peak / rough dB / normalized intensity

Missing DHT11 details:

- Current DHT11 driver
- Whether stable temp/humi reading already works

## 3. Recommended System Architecture

The recommended architecture is:

- ESP32-S3 uploads sensor data and drives the main forest screen.
- ESP32-C5 handles touch control and drives the control/data screen.
- Backend is the single source of truth.
- Web dashboard, S3 screen, and C5 screen all synchronize through backend state.

Do not make S3 and C5 maintain separate independent states.

Avoid complex direct S3-C5 synchronization in the first integration stage.

Recommended state flow:

```text
S3 sensor upload
-> backend updates state
-> S3 receives response and updates main screen

C5 touch control
-> backend session API updates mode
-> C5 reads /api/state and updates control screen

Web dashboard
-> polls /api/state
-> displays the same state
```

This gives one unified state model:

```text
Backend state = Web state = S3 main screen state = C5 control screen state
```

## 4. Backend Integration

### 4.1 Local Backend Address

During local integration, backend runs on the local computer.

ESP32 devices must not use:

```text
localhost:3000
```

For ESP32, `localhost` means the ESP32 itself.

ESP32 should use the PC LAN IP:

```text
http://<PC-LAN-IP>:3000
```

Example:

```text
http://192.168.1.23:3000
```

Device upload endpoint:

```text
http://<PC-LAN-IP>:3000/api/device_data
```

The PC IP can be checked on Windows CMD:

```cmd
ipconfig
```

Use the IPv4 address of the current Wi-Fi or Ethernet adapter.

### 4.2 Backend Endpoints

| Method | Path | Used by |
| --- | --- | --- |
| GET | `/api/state` | Web, C5, optional S3 |
| POST | `/api/device_data` | S3 sensor upload |
| POST | `/api/session/start` | Web, C5 touch |
| POST | `/api/session/end` | Web, C5 touch |
| POST | `/api/session/recover` | Web, C5 touch |

## 5. JSON Protocol

### 5.1 Device Upload Request

ESP32-S3 should POST this JSON to `/api/device_data`:

```json
{
  "device_id": "echoforest_s3_001",
  "mode": "focus",
  "light": 320,
  "noise": 80,
  "temp": 26,
  "humi": 55,
  "button": 0,
  "camera_used": false
}
```

Field meanings:

| Field | Type | Meaning |
| --- | --- | --- |
| device_id | string | Hardware device identity |
| mode | string | Current device mode, usually `focus` during study |
| light | number | Light value from BH1750 |
| noise | number | Noise value from INMP441 processing |
| temp | number | Temperature from DHT11 |
| humi | number | Humidity from DHT11 |
| button | number | Optional hardware button state |
| camera_used | boolean | Currently false |

### 5.2 Backend Response

Backend returns state and device feedback fields:

```json
{
  "mode": "focus",
  "forest_state": "noisy",
  "screen_line1": "环境偏吵",
  "screen_line2": "请降低噪声",
  "rgb_mode": "warning_fast",
  "buzzer_mode": "warning",
  "message": "当前噪声偏高，建议换到更安静的位置或使用耳塞。",
  "task_title": "噪声提醒",
  "counts": {
    "sessions_completed": 0
  }
}
```

Important fields for firmware:

| Field | Used by |
| --- | --- |
| forest_state | Main screen scene selection |
| screen_line1 | LCD text line 1 |
| screen_line2 | LCD text line 2 |
| rgb_mode | Optional RGB mode |
| buzzer_mode | Optional buzzer mode |
| message | Long message, optional for small screens |
| mode | Current system mode |
| counts.sessions_completed | Growth/progress display |

### 5.3 C5 Session Control Requests

Start study:

```text
POST /api/session/start
```

Body:

```json
{
  "target_text": "学习操作系统"
}
```

End study:

```text
POST /api/session/end
```

Recover / rest:

```text
POST /api/session/recover
```

Read state:

```text
GET /api/state
```

## 6. State Enum

Backend uses fixed `forest_state` values.

Do not rename them in firmware.

| forest_state | Chinese display | Main screen behavior |
| --- | --- | --- |
| normal | 准备就绪 | Waiting / idle forest |
| growing | 森林成长中 | Green growth scene |
| low_light | 光线过暗 | Dark scene / lamp reminder |
| noisy | 环境偏吵 | Warning / shake / noise reminder |
| uncomfortable | 环境不适 | Temperature/humidity reminder |
| completed | 学习完成 | Completion scene |
| recovering | 休息中 | Rest scene |

Firmware should preserve the raw enum value and map it to local display functions.

Example:

```c
if (strcmp(state->forest_state, "noisy") == 0) {
    main_screen_show_noisy(state);
}
```

## 7. Proposed C Data Structures

### 7.1 Device Upload Data

```c
typedef struct {
    char device_id[32];
    char mode[16];

    float light;
    float noise;
    float temp;
    float humi;

    int button;
    bool camera_used;
} echoforest_device_data_t;
```

### 7.2 Backend State Response

```c
typedef struct {
    char mode[16];
    char forest_state[32];

    char screen_line1[64];
    char screen_line2[64];

    char rgb_mode[32];
    char buzzer_mode[32];

    char message[160];
    char task_title[80];

    int sessions_completed;

    float light;
    float noise;
    float temp;
    float humi;
} echoforest_state_t;
```

### 7.3 Session Action Enum

Initial draft:

```c
typedef enum {
    ECHOFORest_ACTION_NONE = 0,
    ECHOFORest_ACTION_START,
    ECHOFORest_ACTION_END,
    ECHOFORest_ACTION_REST
} echoforest_action_t;
```

Recommended corrected naming before implementation:

```c
typedef enum {
    ECHOFOREST_ACTION_NONE = 0,
    ECHOFOREST_ACTION_START,
    ECHOFOREST_ACTION_END,
    ECHOFOREST_ACTION_REST
} echoforest_action_t;
```

## 8. Proposed Firmware Module Structure

Because hardware teammates already have working display/touch code, do not rewrite the whole display driver from scratch.

Recommended approach:

- Keep their existing lcd/spi/touch base project.
- Add EchoForest modules into the existing ESP-IDF projects.

Proposed module layout:

```text
firmware_modules/
  common/
    echoforest_protocol.h
    cloud_client.c
    cloud_client.h
    wifi_manager.c
    wifi_manager.h

  s3/
    sensor_mock.c
    sensor_mock.h
    sensor_bh1750.c
    sensor_bh1750.h
    sensor_inmp441.c
    sensor_inmp441.h
    sensor_dht11.c
    sensor_dht11.h
    main_screen_renderer.c
    main_screen_renderer.h
    s3_app.c
    s3_app.h

  c5/
    touch_actions.c
    touch_actions.h
    control_screen_renderer.c
    control_screen_renderer.h
    c5_app.c
    c5_app.h
```

Do not create full independent ESP-IDF projects until the hardware base projects are available.

Instead, first create modules that can be copied into:

```text
s3_base_project/main/
c5_base_project/main/
```

## 9. S3 Firmware Responsibilities

ESP32-S3 should be responsible for:

1. Connect Wi-Fi.
2. Read sensors:
   - BH1750 -> light
   - INMP441 -> noise
   - DHT11 -> temp/humi
3. Build `echoforest_device_data_t`.
4. POST JSON to backend `/api/device_data`.
5. Parse backend response into `echoforest_state_t`.
6. Update HSD024290 main screen.
7. Display `forest_state` scene and `screen_line1`/`screen_line2`.

Suggested S3 loop:

```text
wifi_connect()
main_screen_init()
sensor_init()

loop:
  read sensor data
  upload to /api/device_data
  parse backend response
  render main screen by forest_state
  delay 1-3 seconds
```

First milestone should use mock sensor data:

```c
device.light = 320;
device.noise = 80;
device.temp = 26;
device.humi = 55;
```

Then replace with real sensors one by one.

## 10. C5 Firmware Responsibilities

ESP32-C5 should be responsible for:

1. Connect Wi-Fi.
2. Initialize P183B001 display.
3. Initialize touch input.
4. Display `mode`, `forest_state`, `light`/`noise`/`temp`/`humi`.
5. Convert touch regions into actions:
   - start study
   - end study
   - start rest
6. Send session API requests:
   - `/api/session/start`
   - `/api/session/end`
   - `/api/session/recover`
7. Periodically GET `/api/state`.
8. Render current state on control screen.

Suggested C5 loop:

```text
wifi_connect()
control_screen_init()
touch_init()

loop:
  read touch action
  if start: POST /api/session/start
  if end: POST /api/session/end
  if rest: POST /api/session/recover

  GET /api/state
  render control screen
  delay 0.5-2 seconds
```

Touch action mapping should be separated from backend logic.

Example:

```c
echoforest_action_t touch_actions_read(void);
```

## 11. Renderer Interface Design

### 11.1 S3 Main Screen Renderer

The S3 main screen renderer should not know HTTP details.

Recommended interface:

```c
void main_screen_init(void);
void main_screen_show_state(const echoforest_state_t *state);
void main_screen_show_error(const char *message);
```

Possible internal mapping:

```c
void main_screen_show_state(const echoforest_state_t *state)
{
    if (strcmp(state->forest_state, "growing") == 0) {
        draw_growing_scene(state->screen_line1, state->screen_line2);
    } else if (strcmp(state->forest_state, "low_light") == 0) {
        draw_low_light_scene(state->screen_line1, state->screen_line2);
    } else if (strcmp(state->forest_state, "noisy") == 0) {
        draw_noisy_scene(state->screen_line1, state->screen_line2);
    } else if (strcmp(state->forest_state, "uncomfortable") == 0) {
        draw_uncomfortable_scene(state->screen_line1, state->screen_line2);
    } else if (strcmp(state->forest_state, "completed") == 0) {
        draw_completed_scene(state->screen_line1, state->screen_line2);
    } else if (strcmp(state->forest_state, "recovering") == 0) {
        draw_rest_scene(state->screen_line1, state->screen_line2);
    } else {
        draw_idle_scene(state->screen_line1, state->screen_line2);
    }
}
```

For the first firmware version, these draw functions can be simple text/status drawing functions.

Later, they can be replaced with image frames or lightweight animation.

### 11.2 C5 Control Screen Renderer

Recommended interface:

```c
void control_screen_init(void);
void control_screen_show_state(const echoforest_state_t *state);
void control_screen_show_network_status(bool connected);
void control_screen_show_upload_status(bool ok);
```

The C5 screen should display:

- `mode`
- `forest_state`
- `light`
- `noise`
- `temp`
- `humi`
- Wi-Fi status
- Backend status
- Touch controls

## 12. Cloud Client Module

The `cloud_client` should hide HTTP/JSON details.

Recommended interface:

```c
typedef struct {
    char base_url[128];
} cloud_client_config_t;

esp_err_t cloud_client_init(const cloud_client_config_t *config);

esp_err_t cloud_client_post_device_data(
    const echoforest_device_data_t *device_data,
    echoforest_state_t *out_state
);

esp_err_t cloud_client_get_state(echoforest_state_t *out_state);

esp_err_t cloud_client_start_session(
    const char *target_text,
    echoforest_state_t *out_state
);

esp_err_t cloud_client_end_session(echoforest_state_t *out_state);

esp_err_t cloud_client_start_recovery(echoforest_state_t *out_state);
```

Implementation should use ESP-IDF `esp_http_client`.

JSON parsing/generation should use the JSON library already available in the ESP-IDF project if possible, usually cJSON.

## 13. Wi-Fi Module

Recommended interface:

```c
esp_err_t wifi_manager_init_sta(const char *ssid, const char *password);
bool wifi_manager_is_connected(void);
```

The Wi-Fi config should not be hardcoded inside cloud code.

Use a config header during local development:

```c
#define WIFI_SSID        "your_wifi"
#define WIFI_PASSWORD    "your_password"
#define BACKEND_BASE_URL "http://192.168.1.23:3000"
```

Do not commit real Wi-Fi password to shared repository.

## 14. First Implementation Milestone

### Milestone 1: Mock Sensor Cloud Loop

Goal:

ESP32-S3 sends mock sensor data to backend and renders backend response.

Scope:

- Use ESP32-S3.
- Use mock sensor values.
- Use backend running on local PC.
- Use HTTP POST `/api/device_data`.
- Parse response.
- Call `main_screen_show_state()`.

Do not implement yet:

- Real BH1750 driver
- Real INMP441 algorithm
- Real DHT11 integration
- Complex LCD animation
- S3-C5 synchronization

Expected result:

- Changing mock noise/light/temp values changes backend `forest_state`.
- S3 receives `screen_line1`/`screen_line2`.
- S3 display layer can show the returned state.
- Web dashboard also shows the same state.

### Milestone 2: C5 Touch Control Cloud Loop

Goal:

ESP32-C5 touch screen controls study/rest state through backend.

Scope:

- Use ESP32-C5.
- Use touch action mapping.
- POST `/api/session/start`.
- POST `/api/session/end`.
- POST `/api/session/recover`.
- GET `/api/state`.
- Render current state on P183B001.

Expected result:

- Touch start changes backend mode to `focus`.
- Touch rest changes backend mode to `recovering`.
- Touch end completes session and creates log.
- Web dashboard shows the same state.

### Milestone 3: Replace Mock Sensors With Real Sensors

Order:

1. DHT11 temp/humi
2. BH1750 light
3. INMP441 noise

Reason:

DHT11 and BH1750 are simpler.
INMP441 requires I2S configuration and noise algorithm tuning.

### Milestone 4: Lightweight Screen Animation

Do after cloud loop is stable.

Each `forest_state` maps to one local scene:

- `growing` -> growing scene
- `low_light` -> dim scene
- `noisy` -> warning scene
- `uncomfortable` -> discomfort scene
- `completed` -> completion scene
- `recovering` -> rest scene

Initial animation can be simple:

- static background
- text
- icon
- small flashing / breathing effect

Do not require cloud video streaming.

Recommended animation architecture:

- local assets on device
- backend sends `forest_state` / `scene_id`
- firmware selects local scene

## 15. Missing Information Before Real Firmware Implementation

Required from hardware teammates:

1. S3 base ESP-IDF project:
   - `main.c`
   - `lcd.c` / `lcd.h`
   - `spi.c` / `spi.h`
   - `CMakeLists.txt`
   - `sdkconfig`
   - working HSD024290 display test
2. C5 base ESP-IDF project:
   - `main.c`
   - `lcd.c` / `lcd.h`
   - `spi.c` / `spi.h`
   - `touch.c` / `touch.h`
   - `CMakeLists.txt`
   - `sdkconfig`
   - working P183B001 display and touch test
3. HSD024290 LCD driver chip.
4. Actual HSD024290 GPIO mapping used by the working code.
5. P183B001 touch interface final confirmation:
   - I2C or TP_CS/TP_PEN
   - touch chip model
   - actual GPIO mapping
6. BH1750 GPIO:
   - SDA
   - SCL
   - I2C port
   - address
7. INMP441 configuration:
   - I2S port
   - sample rate
   - bits per sample
   - noise algorithm expectation
8. DHT11 driver status:
   - whether current reading is stable
   - driver source if available
9. ESP-IDF version.
10. Backend local PC IP during integration.

## 16. Risks

### 16.1 LCD Driver Mismatch

Risk:

Screen driver chips and SPI pin groups are not fully confirmed.

Mitigation:

Do not rewrite LCD driver from scratch.
Integrate with the working lcd/spi code from hardware teammates.

### 16.2 Touch Interface Ambiguity

Risk:

P183B001 touch has inconsistent descriptions: I2C touch vs TP_CS/TP_PEN.

Mitigation:

Wait for actual touch code and confirmed chip/interface before writing touch driver.
Use touch_actions abstraction first.

### 16.3 Backend IP Changes

Risk:

Local PC IP changes when Wi-Fi/network changes.

Mitigation:

Keep `BACKEND_BASE_URL` in one config header.
Print backend URL at boot.
Document `ipconfig` usage.

### 16.4 INMP441 Noise Calibration

Risk:

Noise values may not match backend thresholds directly.

Mitigation:

Start with normalized 0-100 noise score.
Calibrate after real sampling.
Adjust backend thresholds if needed.

### 16.5 Dual-Controller State Conflict

Risk:

S3 and C5 could both try to manage mode/state independently.

Mitigation:

Backend is the only state center.
S3 uploads sensors.
C5 sends user actions.
Both read backend state.

## 17. Rollback Plan

If firmware-cloud integration becomes unstable:

1. Keep backend and web dashboard unchanged.
2. Use existing simulator to continue software demo.
3. Disable real sensor upload temporarily.
4. Use mock sensor firmware payloads.
5. Restore previous hardware display-only code.

The firmware integration should be additive.

It should not require changing the backend API unless absolutely necessary.

## 18. Immediate Next Step

Before writing firmware code:

1. Save this plan as `docs/firmware_integration_plan.md`.
2. Ask hardware teammates for S3/C5 base projects.
3. Confirm missing GPIO and touch details.
4. Start Firmware Task 01: ESP-IDF cloud client + protocol module + mock sensor loop.

Recommended Firmware Task 01 scope:

Create `firmware_modules/common`:

- `echoforest_protocol.h`
- `cloud_client.h`
- `cloud_client.c`
- `wifi_manager.h`
- `wifi_manager.c`

Create `firmware_modules/s3`:

- `sensor_mock.h`
- `sensor_mock.c`
- `main_screen_renderer.h`
- `main_screen_renderer.c`
- `s3_app.h`
- `s3_app.c`

Do not implement actual LCD driver.
Do not implement actual BH1750/INMP441/DHT11 driver.
Do not implement final animation.

## 19. S3 Zip Inspection Update 2026-07-09

The received S3 zip is a real ESP32-S3 ESP-IDF base project. It provides useful driver evidence, but it does not implement the EchoForest backend HTTP architecture yet.

Confirmed S3 base facts:

| Item | Value |
| --- | --- |
| Target | ESP32-S3 |
| ESP-IDF | 5.5.4 |
| Flash | 2MB |
| PSRAM | disabled |
| Main entry | `main/main.c` |
| LCD driver style | ST7789 |
| LCD resolution | 240 x 320 |
| LCD SPI host | SPI2_HOST |
| LCD SCLK | GPIO21 |
| LCD MOSI | GPIO47 |
| LCD MISO | GPIO48 |
| LCD CS | GPIO42 |
| LCD DC / RS | GPIO41 |
| LCD RST | -1 |
| LCD color order | BGR |
| LCD SPI clock | 27 MHz |

Confirmed S3 sensors:

| Sensor | Confirmed information |
| --- | --- |
| BH1750 | I2C_NUM_0, SDA GPIO5, SCL GPIO4, address 0x23 |
| DHT11 | S3 zip uses DATA GPIO0 |
| INMP441 | BCLK GPIO35, WS GPIO36, DIN GPIO37, I2S_NUM_0, 16000 Hz, 32-bit mono left slot |

Important correction:

- DHT11 was previously recorded as GPIO13, but the S3 zip uses GPIO0. Confirm final wiring before real integration.

Current S3 zip architecture:

- Connects to C5 hotspot `C5_AP`.
- Contains hardcoded password `12345678`.
- Sends UDP to C5 at `192.168.4.1:3333`.
- Starts an OV2640 camera web server.
- Reads BH1750, DHT11, and INMP441 locally.

EchoForest decision:

- Reuse S3 LCD and sensor driver code as adapters.
- Do not use S3-C5 UDP as the main EchoForest state path.
- Replace S3 UDP state sync with HTTP POST `/api/device_data`.
- Keep camera disabled or isolated because camera recognition is out of scope for Phase 1.
