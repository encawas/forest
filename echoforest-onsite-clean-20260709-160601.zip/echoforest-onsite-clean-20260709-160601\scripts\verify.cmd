@echo off
setlocal enabledelayedexpansion
set "PASS=1"

echo === EchoForest Harness Verification ===
echo.

REM ---- Harness file existence checks ----
set "ROOT=%~dp0.."
if not exist "%ROOT%\AGENTS.md"                 (echo FAIL: missing AGENTS.md & set PASS=0)
if not exist "%ROOT%\README.md"                 (echo FAIL: missing README.md & set PASS=0)
if not exist "%ROOT%\docs\product_spec.md"      (echo FAIL: missing docs\product_spec.md & set PASS=0)
if not exist "%ROOT%\docs\assumptions.md"       (echo FAIL: missing docs\assumptions.md & set PASS=0)
if not exist "%ROOT%\docs\open_questions.md"    (echo FAIL: missing docs\open_questions.md & set PASS=0)
if not exist "%ROOT%\docs\decision_log.md"      (echo FAIL: missing docs\decision_log.md & set PASS=0)
if not exist "%ROOT%\docs\api_contract.md"      (echo FAIL: missing docs\api_contract.md & set PASS=0)
if not exist "%ROOT%\docs\state_machine.md"     (echo FAIL: missing docs\state_machine.md & set PASS=0)
if not exist "%ROOT%\docs\architecture.md"      (echo FAIL: missing docs\architecture.md & set PASS=0)
if not exist "%ROOT%\docs\review_checklist.md"  (echo FAIL: missing docs\review_checklist.md & set PASS=0)
if not exist "%ROOT%\docs\model_routing.md"     (echo FAIL: missing docs\model_routing.md & set PASS=0)
if not exist "%ROOT%\tasks\00_impact_map_template.md" (echo FAIL: missing tasks\00_impact_map_template.md & set PASS=0)
if not exist "%ROOT%\tasks\01_backend_min_loop.md"    (echo FAIL: missing tasks\01_backend_min_loop.md & set PASS=0)
if !PASS! equ 0 (echo. & echo Harness check FAILED. & exit /b 1)
echo Harness files: OK
echo.

REM ---- Backend verification ----
cd /d "%ROOT%\backend"
if not exist "package.json" (
  echo FAIL: missing backend\package.json
  exit /b 1
)

echo Installing dependencies...
call npm install --no-package-lock
if %ERRORLEVEL% neq 0 (
  echo FAIL: npm install failed
  exit /b 1
)
echo npm install: OK
echo.

echo Running tests...
call npm test
if %ERRORLEVEL% neq 0 (
  echo FAIL: npm test failed
  exit /b 1
)
echo npm test: OK
echo.

REM ---- Frontend verification ----
cd /d "%ROOT%\frontend"
if not exist "package.json" (
  echo FAIL: missing frontend\package.json
  exit /b 1
)

echo Installing frontend dependencies...
call npm install --no-package-lock
if %ERRORLEVEL% neq 0 (
  echo FAIL: frontend npm install failed
  exit /b 1
)
echo frontend npm install: OK
echo.

echo Running frontend tests...
call npm test
if %ERRORLEVEL% neq 0 (
  echo FAIL: frontend npm test failed
  exit /b 1
)
echo frontend npm test: OK
echo.

echo Building frontend...
call npm run build
if %ERRORLEVEL% neq 0 (
  echo FAIL: frontend build failed
  exit /b 1
)
echo frontend build: OK
echo.

REM ---- Simulator verification ----
cd /d "%ROOT%"
if not exist "simulator\device_simulator.js" (
  echo FAIL: missing simulator\device_simulator.js
  exit /b 1
)
if not exist "simulator\test\device_simulator.test.js" (
  echo FAIL: missing simulator\test\device_simulator.test.js
  exit /b 1
)

echo Running simulator tests...
node --test simulator\test\device_simulator.test.js
if %ERRORLEVEL% neq 0 (
  echo FAIL: simulator tests failed
  exit /b 1
)
echo simulator tests: OK
echo.

echo === PASS ===
exit /b 0
