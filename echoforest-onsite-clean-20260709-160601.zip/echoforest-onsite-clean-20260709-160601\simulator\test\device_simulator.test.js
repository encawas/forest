const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  CYCLE_ORDER,
  buildEndpoint,
  createPayload,
  parseArgs,
  scenarioForIteration,
} = require('../device_simulator');

const FIXED_TIME = '2026-07-05T00:00:00.000Z';

function requiredFields(payload) {
  return ['device_id', 'mode', 'light', 'noise'].every((field) => (
    Object.prototype.hasOwnProperty.call(payload, field)
  ));
}

describe('device simulator payload generation', () => {
  it('creates a normal focus payload with API fields', () => {
    const payload = createPayload('normal', FIXED_TIME);
    assert.equal(requiredFields(payload), true);
    assert.equal(payload.device_id, 'simulator_001');
    assert.equal(payload.mode, 'focus');
    assert.equal(payload.light, 320);
    assert.equal(payload.noise, 48);
    assert.equal(payload.temp, 26);
    assert.equal(payload.humi, 55);
    assert.equal(payload.button, 0);
    assert.equal(payload.camera_used, false);
    assert.equal(payload.target_text, 'study operating systems');
    assert.equal(payload.timestamp, FIXED_TIME);
  });

  it('creates a low_light payload below the demo light threshold', () => {
    const payload = createPayload('low_light', FIXED_TIME);
    assert.equal(payload.light, 60);
    assert.equal(payload.noise, 48);
  });

  it('creates a noisy payload above the demo noise threshold', () => {
    const payload = createPayload('noisy', FIXED_TIME);
    assert.equal(payload.light, 320);
    assert.equal(payload.noise, 80);
  });

  it('creates an uncomfortable payload outside the demo temp range', () => {
    const payload = createPayload('uncomfortable', FIXED_TIME);
    assert.equal(payload.temp, 33);
    assert.equal(payload.humi, 55);
  });

  it('cycles through normal, low_light, noisy, and uncomfortable scenarios', () => {
    const actual = Array.from({ length: 6 }, (_value, index) => (
      scenarioForIteration('cycle', index)
    ));
    assert.deepEqual(actual, ['normal', 'low_light', 'noisy', 'uncomfortable', 'normal', 'low_light']);
    assert.deepEqual(CYCLE_ORDER, ['normal', 'low_light', 'noisy', 'uncomfortable']);
  });

  it('uses the required device data endpoint path', () => {
    assert.equal(buildEndpoint('http://localhost:3000'), 'http://localhost:3000/api/device_data');
    assert.equal(buildEndpoint('http://localhost:3000/'), 'http://localhost:3000/api/device_data');
  });
});

describe('device simulator CLI options', () => {
  it('parses scenario, interval, count, and base URL', () => {
    const options = parseArgs([
      '--scenario', 'noisy',
      '--interval', '2000',
      '--count', '10',
      '--base-url', 'http://localhost:3000',
    ]);

    assert.deepEqual(options, {
      scenario: 'noisy',
      interval: 2000,
      count: 10,
      baseUrl: 'http://localhost:3000',
    });
  });

  it('rejects unknown scenarios', () => {
    assert.throws(() => parseArgs(['--scenario', 'camera']), /--scenario must be one of/);
  });
});
