# EchoForest Harness

This repo is a harness-first implementation workspace for EchoForest Phase 1.

The goal is not to let AI freely generate a full app.
The goal is to constrain AI work through specs, contracts, tasks, verification, and review.

Phase 1 demo loop:
1. Web console starts a study session.
2. ESP32-S3 or simulator uploads environment data.
3. Backend decides forest_state.
4. Backend returns fields for web and hardware display.
5. Web console shows state and generates a study log.

Start by reading AGENTS.md and docs/product_spec.md.
