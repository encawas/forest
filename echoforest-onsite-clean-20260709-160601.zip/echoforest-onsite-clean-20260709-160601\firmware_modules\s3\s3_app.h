#ifndef ECHOFOREST_S3_APP_H
#define ECHOFOREST_S3_APP_H

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t s3_app_init(const char *wifi_ssid, const char *wifi_password, const char *backend_base_url);
esp_err_t s3_app_init_from_field_config(void);
void s3_app_set_mock_scenario(int scenario);
void s3_app_run_once_mock(void);
void s3_app_run_once_real_sensors(void);

#ifdef __cplusplus
}
#endif

#endif
