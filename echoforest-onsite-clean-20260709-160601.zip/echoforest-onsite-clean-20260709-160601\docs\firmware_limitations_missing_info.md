# EchoForest 当前限制与缺失信息

这份文档说明当前版本已经具备什么、还不能做什么，以及后续接入真实硬件前需要硬件同学补充哪些信息。

## 1. 当前已经完成

软件侧已经完成第一版本地闭环：

```text
网页输入学习目标
-> 后端进入学习状态
-> 模拟器上传 light/noise/temp/humi
-> 后端计算 forest_state
-> 网页显示环境数据、状态、设备反馈和学习日志
```

固件侧已经完成交互骨架：

- 通用协议结构体。
- 后端 API 路径常量。
- ESP-IDF 风格 HTTP client 骨架。
- Wi-Fi wrapper 骨架。
- S3 mock sensor 上传骨架。
- S3 主森林屏 renderer 占位。
- C5 touch action 占位。
- C5 控制屏 renderer 占位。
- C5 开始学习、结束学习、开始休息、读取状态的 app 骨架。

## 2. 当前不能直接做的事

当前固件模块不能直接烧录运行。

原因：

- 它不是完整 ESP-IDF 工程。
- 没有 `CMakeLists.txt` 接线。
- 没有 `app_main`。
- 没有目标板 sdkconfig。
- 没有真实 LCD/touch/sensor 驱动。

当前固件 renderer 只打日志，不画真实屏幕。

当前 touch action 只返回 `ECHOFOREST_ACTION_NONE`，不会读取真实触摸。

当前 S3 sensor 是 mock 数据，不读取真实传感器。

## 3. 明确不包含的功能

当前版本故意不包含：

- 真实 HSD024290 LCD 驱动。
- 真实 P183B001 LCD 驱动。
- 真实 touch driver。
- 真实 BH1750 driver。
- 真实 INMP441 噪声算法。
- 真实 DHT11 driver。
- 最终森林动画。
- S3 和 C5 直接通信。
- 数据库。
- 登录。
- WebSocket。
- 真实 LLM API。
- 摄像头识别。

## 4. 后续目标模式

目标不是让 S3 和 C5 互相维护复杂状态，而是都跟随后端。

目标链路：

```text
C5 触摸开始学习
-> C5 调 POST /api/session/start
-> 后端 mode 变成 focus
-> S3 上传 light/noise/temp/humi 到 POST /api/device_data
-> 后端计算 forest_state
-> 网页显示状态
-> C5 显示 mode/state/sensor data
-> S3 主屏显示森林状态
-> C5 或网页结束学习
-> 后端生成日志
```

## 5. 需要硬件同学补充的信息

### S3 主屏

需要：

- S3 完整 ESP-IDF 基础工程。
- HSD024290 当前能点亮的显示测试代码。
- `main.c`
- `lcd.c / lcd.h`
- `spi.c / spi.h`
- `CMakeLists.txt`
- `sdkconfig`
- HSD024290 实际 LCD driver chip。
- 实际使用的 SPI GPIO。
- 横屏/竖屏方向要求。
- 颜色顺序是 RGB 还是 BGR。

目前已知：

- 控制器：ESP32-S3
- 屏幕：HSD024290
- 分辨率：240 x 320
- 用途：主森林屏
- 目前实际 LCD driver 代码还没有接入本仓库。

### C5 控制屏

需要：

- C5 完整 ESP-IDF 基础工程。
- P183B001 当前能显示和触摸的代码。
- `main.c`
- `lcd.c / lcd.h`
- `spi.c / spi.h`
- `touch.c / touch.h`
- `CMakeLists.txt`
- `sdkconfig`

目前已知：

- 控制器：ESP32-C5
- 屏幕：P183B001
- 分辨率：240 x 284
- LCD driver 风格：ST7789V
- LCD SPI host：SPI2_HOST
- MOSI / LCD_SDI：GPIO23
- SCLK / LCD_SCL：GPIO24
- CS：GPIO25
- DC / RS：GPIO26
- BL / 背光：GPIO5
- MISO / SDO：未使用
- Touch：I2C
- Touch port：I2C_NUM_0
- Touch SDA：GPIO2
- Touch SCL：GPIO3
- Touch address：0x15
- 坐标变换：`y = LCD_HEIGHT - 1 - raw_y`

仍需确认：

- 触摸芯片型号。
- 触摸坐标是否需要进一步校准。
- 最终按钮区域设计。

### 传感器

BH1750 光照：

- 已知 SDA：GPIO5
- 已知 SCL：GPIO4
- 已知 I2C port：I2C_NUM_0
- 已知地址：0x23
- 已知频率：100 kHz
- 仍需真实读取代码接入和实地校准。

DHT11 温湿度：

- 已知 DATA：GPIO13
- 已有较稳定读取代码，约 2 秒读一次。
- 仍需提供可复用 driver 源码并接进 S3 工程。

INMP441 麦克风：

- 已知有相关文件在 `Voise-file` 仓库。
- 已知大致使用 I2S 读取 RMS / 相对 dB。
- 仍需确认最终 I2S GPIO、采样率、位宽、通道配置和噪声分数换算。
- 噪声阈值需要现场校准。

### 网络配置

需要测试现场确认：

- 电脑局域网 IP。
- ESP32 和电脑是否在同一个 Wi-Fi。
- Windows 防火墙是否允许 3000 端口。
- 后端是否稳定运行在 `http://<PC-LAN-IP>:3000`。

ESP32 不能使用：

```text
localhost:3000
```

必须使用：

```text
http://<PC-LAN-IP>:3000
```

## 6. 建议测试顺序

第一步：纯软件测试。

- 后端启动。
- 前端启动。
- 模拟器 cycle 跑通。

第二步：S3 mock 上传。

- S3 只接 Wi-Fi 和 HTTP。
- 不接真实传感器。
- 用 mock light/noise/temp/humi 上传。
- 网页能显示 S3 数据即可。

第三步：C5 状态显示。

- C5 只 GET `/api/state`。
- 控制屏显示 mode、forest_state、light/noise/temp/humi。

第四步：C5 触摸动作。

- 把触摸区域映射成开始学习、结束学习、开始休息。
- 确认网页和 C5 显示同步变化。

第五步：替换真实传感器。

建议顺序：

1. DHT11
2. BH1750
3. INMP441

原因：

- DHT11 和 BH1750 更容易形成稳定读数。
- INMP441 需要现场噪声校准。

第六步：屏幕绘制。

- 先画文字和状态。
- 再画简单图标。
- 最后再做森林动画。

## 7. 风险

主要风险：

- S3 显示驱动还没接入。
- C5 触摸代码目前还是 demo/blocking 风格，需要拆成非阻塞读取。
- Wi-Fi 代码不能提交真实 SSID/password。
- 本地电脑 IP 会变。
- INMP441 噪声值和后端阈值不一定直接匹配。
- 固件模块还没有在真实 ESP-IDF 工程里编译验证。

## 8. 对应处理办法

- 如果真实硬件暂时不稳定，继续用 simulator 做软件演示。
- 如果 S3 传感器没接好，先用 S3 mock sensor 上传。
- 如果 C5 触摸没接好，先只显示 `/api/state`。
- 如果屏幕绘制没接好，先用日志确认状态闭环。
- 如果电脑 IP 变化，只改本地 `echoforest_config.h`，不要改仓库源码。

## 9. 2026-07-09 S3 zip 补充结论

这次收到的 S3 zip 是一个可用的 ESP32-S3 ESP-IDF 基础工程，不是 EchoForest 后端 HTTP 集成工程。

已经确认的 S3 信息：

- Target：ESP32-S3
- ESP-IDF：5.5.4
- Flash：2MB
- PSRAM：未启用
- LCD：ST7789 风格，240 x 320
- LCD SPI host：SPI2_HOST
- LCD SCLK：GPIO21
- LCD MOSI：GPIO47
- LCD MISO：GPIO48
- LCD CS：GPIO42
- LCD DC / RS：GPIO41
- LCD RST：-1
- LCD color order：BGR
- LCD SPI clock：27 MHz

已经确认的传感器信息：

- BH1750：I2C_NUM_0，SDA GPIO5，SCL GPIO4，地址 0x23。
- DHT11：S3 zip 使用 GPIO0；之前记录过 GPIO13，最终接线需要确认。
- INMP441：BCLK GPIO35，WS GPIO36，DIN GPIO37，I2S_NUM_0，16000 Hz，32-bit mono left slot。
- INMP441 算法：去均值、尖峰过滤、RMS、平滑；当前 raw dB 为 `20.0f * log10f(rms + 1.0f)`。

当前 S3 zip 的现状：

- S3 连接 C5 热点 `C5_AP`。
- 代码里硬编码了密码 `12345678`。
- S3 通过 UDP 发到 C5 `192.168.4.1:3333`。
- S3 启动 camera web server。
- S3 会读取 BH1750、DHT11、INMP441 并打印数据。

EchoForest 后续处理原则：

- 可以复用 S3 zip 里的 LCD、BH1750、DHT11、INMP441 代码。
- 不要把 S3-C5 UDP 当成 EchoForest 主状态同步方式。
- 主链路仍然是 `S3 -> POST /api/device_data -> 后端`。
- Wi-Fi SSID/password 必须改成配置项，不能提交真实密码。
- Camera 识别仍然不进 Phase 1。

