#ifndef ECHOFOREST_SENSOR_REAL_ADAPTER_H
#define ECHOFOREST_SENSOR_REAL_ADAPTER_H

#include "esp_err.h"
#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t sensor_real_adapter_init(void);
esp_err_t sensor_real_adapter_read(echoforest_device_data_t *out);

#ifdef __cplusplus
}
#endif

#endif
