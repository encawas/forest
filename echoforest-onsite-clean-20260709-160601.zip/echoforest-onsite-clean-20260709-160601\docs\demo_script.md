# EchoForest Phase 1 Demo Script

## Prerequisites

- Node installed.
- Backend dependencies installed.
- Frontend dependencies installed.
- Backend runs on port `3000`.
- Frontend runs on port `5173`.

## Start Backend

```cmd
cd /d "C:\Users\35174\Desktop\物联网\echoforest-harness\backend"
npm start
```

Expected backend base URL:

```text
http://localhost:3000
```

## Start Frontend

```cmd
cd /d "C:\Users\35174\Desktop\物联网\echoforest-harness\frontend"
npm run dev
```

## Browser URL

Open:

```text
http://localhost:5173/
```

The frontend uses same-origin `/api/state` polling through the Vite proxy and sends session commands through `/api/session/start`, `/api/session/end`, and `/api/session/recover`.

## Demo Flow

1. 输入学习目标。
2. 点击开始学习。
3. 运行 simulator cycle。
4. 观察 `light` / `noise` / `temp` / `humi` 更新。
5. 观察 `forest_state` 在 `growing` / `low_light` / `noisy` / `uncomfortable` 之间变化。
6. 点击开始休息时，页面进入休息提示。
7. 点击结束学习。
8. 查看最新日志。

## Simulator Commands

Run from the repository root:

```cmd
node simulator\device_simulator.js --scenario cycle --interval 2000 --count 8 --base-url http://localhost:3000
```

Focused noisy scenario:

```cmd
node simulator\device_simulator.js --scenario noisy --interval 2000 --count 5 --base-url http://localhost:3000
```

The simulator sends `POST` requests to:

```text
http://localhost:3000/api/device_data
```

## Expected Results

- 页面不是空白。
- `mode` becomes `focus` after start.
- Environment data shows numeric values for `light`, `noise`, `temp`, and `humi`.
- `forest_state` changes with simulator payload.
- Latest log appears after ending session.

## Troubleshooting

- Backend not started: start the backend in `backend` with `npm start`, then retry the simulator.
- Frontend not started: start the frontend in `frontend` with `npm run dev`, then open `http://localhost:5173/`.
- Wrong URL: use `http://localhost:5173/` in the browser and `http://localhost:3000` as the simulator `--base-url`.
- Stale backend after source change: stop and restart the backend process.
- Node fetch version issue: the simulator requires Node built-in `fetch`, available in Node.js 18 or newer.
- Port conflict: stop the process already using port `3000` or `5173`, then restart the backend or frontend.
