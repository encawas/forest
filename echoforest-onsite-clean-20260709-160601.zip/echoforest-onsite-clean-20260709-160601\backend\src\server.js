// EchoForest Phase 1 Backend -- Server Entry Point
const app = require('./app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`EchoForest backend listening on port ${PORT}`);
});