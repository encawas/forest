#include "sensor_real_adapter.h"

#include <math.h>
#include <stdint.h>
#include <string.h>
#include "esp_err.h"
#include "esp_log.h"

#if __has_include("echoforest_field_config.h")
#include "echoforest_field_config.h"
#else
#include "driver/gpio.h"
#define ECHOFOREST_DHT11_PIN GPIO_NUM_0
#endif

/*
 * Adapter over the received S3 base project drivers.
 *
 * Expected S3 project components:
 * - components/BH1750: bh1750_init(), bh1750_read_data()
 * - components/dht11: dht11_init(), dht11_read_data()
 * - components/noise: i2s_mic_init(), i2s_mic_read_rms()
 *
 * This file intentionally does not implement those hardware drivers. It only
 * adapts their values to EchoForest's /api/device_data payload.
 */

#if __has_include("bh1750.h")
#include "bh1750.h"
#define ECHOFOREST_HAS_BH1750 1
#else
#define ECHOFOREST_HAS_BH1750 0
#endif

#if __has_include("dht11.h")
#include "dht11.h"
#define ECHOFOREST_HAS_DHT11 1
#else
#define ECHOFOREST_HAS_DHT11 0
#endif

#if __has_include("noise.h")
#include "noise.h"
#define ECHOFOREST_HAS_NOISE 1
#else
#define ECHOFOREST_HAS_NOISE 0
#endif

static const char *TAG = "echoforest_s3_sensors";

esp_err_t sensor_real_adapter_init(void)
{
#if ECHOFOREST_HAS_BH1750
    bh1750_init();
    ESP_LOGI(TAG, "BH1750 initialized");
#else
    ESP_LOGW(TAG, "BH1750 driver header not found");
#endif

#if ECHOFOREST_HAS_DHT11
    if (dht11_init() != 0) {
        ESP_LOGW(TAG, "DHT11 init failed on configured pin");
    } else {
        ESP_LOGI(TAG, "DHT11 initialized");
    }
#else
    ESP_LOGW(TAG, "DHT11 driver header not found");
#endif

#if ECHOFOREST_HAS_NOISE
    esp_err_t err = i2s_mic_init();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "INMP441 init failed: %s", esp_err_to_name(err));
        return err;
    }
    ESP_LOGI(TAG, "INMP441 initialized");
#else
    ESP_LOGW(TAG, "INMP441 noise driver header not found");
#endif

    ESP_LOGI(TAG, "configured DHT11 pin=%d", ECHOFOREST_DHT11_PIN);
    return ESP_OK;
}

esp_err_t sensor_real_adapter_read(echoforest_device_data_t *out)
{
    if (out == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    memset(out, 0, sizeof(*out));
    strlcpy(out->device_id, "echoforest_s3_001", sizeof(out->device_id));
    strlcpy(out->mode, "focus", sizeof(out->mode));
    out->button = 0;
    out->camera_used = false;

#if ECHOFOREST_HAS_BH1750
    out->light = (float)bh1750_read_data() / 1.2f;
#else
    out->light = 0.0f;
#endif

#if ECHOFOREST_HAS_DHT11
    uint8_t temp = 0;
    uint8_t humi = 0;
    if (dht11_read_data(&temp, &humi) == 0) {
        out->temp = (float)temp;
        out->humi = (float)humi;
    }
#endif

#if ECHOFOREST_HAS_NOISE
    float rms = 0.0f;
    if (i2s_mic_read_rms(&rms) == ESP_OK) {
        out->noise = 20.0f * log10f(rms + 1.0f);
    }
#endif

    ESP_LOGI(TAG, "SENSOR_OK light=%.2f noise=%.2f temp=%.2f humi=%.2f",
             out->light, out->noise, out->temp, out->humi);

    return ESP_OK;
}
