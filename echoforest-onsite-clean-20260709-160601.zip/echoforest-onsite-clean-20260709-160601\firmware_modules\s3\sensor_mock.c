#include "sensor_mock.h"

#include <string.h>

static void fill_base(echoforest_device_data_t *out)
{
    if (out == NULL) {
        return;
    }

    memset(out, 0, sizeof(*out));
    strlcpy(out->device_id, "echoforest_s3_001", sizeof(out->device_id));
    strlcpy(out->mode, "focus", sizeof(out->mode));
    out->button = 0;
    out->camera_used = false;
}

void sensor_mock_fill_focus_normal(echoforest_device_data_t *out)
{
    fill_base(out);
    if (out == NULL) {
        return;
    }
    out->light = 320.0f;
    out->noise = 42.0f;
    out->temp = 26.0f;
    out->humi = 55.0f;
}

void sensor_mock_fill_low_light(echoforest_device_data_t *out)
{
    fill_base(out);
    if (out == NULL) {
        return;
    }
    out->light = 45.0f;
    out->noise = 40.0f;
    out->temp = 26.0f;
    out->humi = 55.0f;
}

void sensor_mock_fill_noisy(echoforest_device_data_t *out)
{
    fill_base(out);
    if (out == NULL) {
        return;
    }
    out->light = 320.0f;
    out->noise = 88.0f;
    out->temp = 26.0f;
    out->humi = 55.0f;
}

void sensor_mock_fill_uncomfortable(echoforest_device_data_t *out)
{
    fill_base(out);
    if (out == NULL) {
        return;
    }
    out->light = 320.0f;
    out->noise = 42.0f;
    out->temp = 33.0f;
    out->humi = 78.0f;
}
