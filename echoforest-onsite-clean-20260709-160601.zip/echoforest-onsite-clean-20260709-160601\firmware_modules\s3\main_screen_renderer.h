#ifndef ECHOFOREST_MAIN_SCREEN_RENDERER_H
#define ECHOFOREST_MAIN_SCREEN_RENDERER_H

#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

void main_screen_init(void);
void main_screen_show_state(const echoforest_state_t *state);
void main_screen_show_error(const char *message);

#ifdef __cplusplus
}
#endif

#endif
