#include "s3_app.h"

#include <string.h>
#include "cloud_client.h"
#include "esp_err.h"
#include "esp_log.h"
#include "main_screen_renderer.h"
#include "sensor_mock.h"
#include "sensor_real_adapter.h"
#include "wifi_manager.h"

#if __has_include("echoforest_field_config.h")
#include "echoforest_field_config.h"
#define ECHOFOREST_HAS_FIELD_CONFIG 1
#else
#define ECHOFOREST_HAS_FIELD_CONFIG 0
#endif

enum {
    S3_MOCK_NORMAL = 0,
    S3_MOCK_LOW_LIGHT = 1,
    S3_MOCK_NOISY = 2,
    S3_MOCK_UNCOMFORTABLE = 3,
};

static const char *TAG = "echoforest_s3_app";
static int s_mock_scenario = S3_MOCK_NORMAL;

esp_err_t s3_app_init(const char *wifi_ssid, const char *wifi_password, const char *backend_base_url)
{
    esp_err_t err = wifi_manager_init_sta(wifi_ssid, wifi_password);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "Wi-Fi init failed: %s", esp_err_to_name(err));
        return err;
    }

    cloud_client_config_t config = { 0 };
    strlcpy(config.base_url, backend_base_url, sizeof(config.base_url));

    err = cloud_client_init(&config);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "cloud client init failed: %s", esp_err_to_name(err));
        return err;
    }

    main_screen_init();
    return ESP_OK;
}

esp_err_t s3_app_init_from_field_config(void)
{
#if ECHOFOREST_HAS_FIELD_CONFIG
    esp_err_t err = s3_app_init(
        ECHOFOREST_WIFI_SSID,
        ECHOFOREST_WIFI_PASSWORD,
        ECHOFOREST_BACKEND_BASE_URL
    );
    if (err != ESP_OK) {
        return err;
    }
    return sensor_real_adapter_init();
#else
    ESP_LOGE(TAG, "echoforest_field_config.h not found");
    return ESP_ERR_NOT_FOUND;
#endif
}

void s3_app_set_mock_scenario(int scenario)
{
    if (scenario < S3_MOCK_NORMAL || scenario > S3_MOCK_UNCOMFORTABLE) {
        s_mock_scenario = S3_MOCK_NORMAL;
        return;
    }
    s_mock_scenario = scenario;
}

void s3_app_run_once_mock(void)
{
    echoforest_device_data_t device_data;
    echoforest_state_t state;

    switch (s_mock_scenario) {
    case S3_MOCK_LOW_LIGHT:
        sensor_mock_fill_low_light(&device_data);
        break;
    case S3_MOCK_NOISY:
        sensor_mock_fill_noisy(&device_data);
        break;
    case S3_MOCK_UNCOMFORTABLE:
        sensor_mock_fill_uncomfortable(&device_data);
        break;
    case S3_MOCK_NORMAL:
    default:
        sensor_mock_fill_focus_normal(&device_data);
        break;
    }

    esp_err_t err = cloud_client_post_device_data(&device_data, &state);
    if (err == ESP_OK) {
        main_screen_show_state(&state);
    } else {
        ESP_LOGW(TAG, "device upload failed: %s", esp_err_to_name(err));
        main_screen_show_error("backend upload failed");
    }
}

void s3_app_run_once_real_sensors(void)
{
    echoforest_device_data_t device_data;
    echoforest_state_t state;

    esp_err_t err = sensor_real_adapter_read(&device_data);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "real sensor read failed: %s", esp_err_to_name(err));
        main_screen_show_error("sensor read failed");
        return;
    }

    err = cloud_client_post_device_data(&device_data, &state);
    if (err == ESP_OK) {
        main_screen_show_state(&state);
    } else {
        ESP_LOGW(TAG, "real sensor upload failed: %s", esp_err_to_name(err));
        main_screen_show_error("backend upload failed");
    }
}
