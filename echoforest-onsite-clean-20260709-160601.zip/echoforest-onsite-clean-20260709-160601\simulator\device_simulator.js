const DEFAULT_BASE_URL = 'http://localhost:3000';
const DEFAULT_INTERVAL = 1000;
const DEFAULT_COUNT = 1;
const DEVICE_ID = 'simulator_001';
const TARGET_TEXT = 'study operating systems';
const SCENARIOS = ['normal', 'low_light', 'noisy', 'uncomfortable', 'cycle'];
const CYCLE_ORDER = ['normal', 'low_light', 'noisy', 'uncomfortable'];

function createPayload(scenario, timestamp = new Date().toISOString()) {
  const base = {
    device_id: DEVICE_ID,
    mode: 'focus',
    target_text: TARGET_TEXT,
    light: 320,
    noise: 48,
    temp: 26,
    humi: 55,
    button: 0,
    camera_used: false,
    timestamp,
  };

  if (scenario === 'normal') return base;
  if (scenario === 'low_light') return { ...base, light: 60 };
  if (scenario === 'noisy') return { ...base, noise: 80 };
  if (scenario === 'uncomfortable') return { ...base, temp: 33 };
  throw new Error(`Unknown scenario: ${scenario}`);
}

function scenarioForIteration(scenario, index) {
  if (scenario !== 'cycle') return scenario;
  return CYCLE_ORDER[index % CYCLE_ORDER.length];
}

function buildEndpoint(baseUrl) {
  return `${baseUrl.replace(/\/+$/, '')}/api/device_data`;
}

function parsePositiveInteger(value, name) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

function parseArgs(argv) {
  const options = {
    scenario: 'normal',
    interval: DEFAULT_INTERVAL,
    count: DEFAULT_COUNT,
    baseUrl: DEFAULT_BASE_URL,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = argv[i + 1];
    if (arg === '--scenario') {
      options.scenario = next;
      i += 1;
    } else if (arg === '--interval') {
      options.interval = parsePositiveInteger(next, '--interval');
      i += 1;
    } else if (arg === '--count') {
      options.count = parsePositiveInteger(next, '--count');
      i += 1;
    } else if (arg === '--base-url') {
      options.baseUrl = next;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!SCENARIOS.includes(options.scenario)) {
    throw new Error(`--scenario must be one of: ${SCENARIOS.join(', ')}`);
  }
  if (!options.baseUrl) {
    throw new Error('--base-url is required when provided');
  }

  return options;
}

function delay(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function postPayload(endpoint, payload) {
  if (typeof fetch !== 'function') {
    throw new Error('Node built-in fetch is not available. Use Node.js 18 or newer.');
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const text = await response.text();
  let data = text;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (_err) {
    data = text;
  }

  if (!response.ok) {
    throw new Error(`POST failed with ${response.status}: ${text}`);
  }
  return data;
}

async function runSimulator(options) {
  const endpoint = buildEndpoint(options.baseUrl);
  for (let i = 0; i < options.count; i += 1) {
    const scenario = scenarioForIteration(options.scenario, i);
    const payload = createPayload(scenario);
    console.log(`scenario: ${scenario}`);
    console.log(`request payload: ${JSON.stringify(payload)}`);
    const response = await postPayload(endpoint, payload);
    console.log(`backend response: ${JSON.stringify(response)}`);
    if (i < options.count - 1) {
      await delay(options.interval);
    }
  }
}

async function main() {
  try {
    const options = parseArgs(process.argv.slice(2));
    await runSimulator(options);
  } catch (err) {
    console.error(err.message);
    process.exitCode = 1;
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  CYCLE_ORDER,
  SCENARIOS,
  buildEndpoint,
  createPayload,
  parseArgs,
  scenarioForIteration,
};
