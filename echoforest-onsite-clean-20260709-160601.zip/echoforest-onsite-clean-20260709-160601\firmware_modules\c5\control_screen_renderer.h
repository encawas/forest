#ifndef ECHOFOREST_CONTROL_SCREEN_RENDERER_H
#define ECHOFOREST_CONTROL_SCREEN_RENDERER_H

#include <stdbool.h>
#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

void control_screen_init(void);
void control_screen_show_state(const echoforest_state_t *state);
void control_screen_show_network_status(bool connected);
void control_screen_show_upload_status(bool ok);

#ifdef __cplusplus
}
#endif

#endif
