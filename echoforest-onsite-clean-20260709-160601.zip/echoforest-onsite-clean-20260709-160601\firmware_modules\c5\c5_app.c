#include "c5_app.h"

#include <string.h>
#include "cloud_client.h"
#include "control_screen_renderer.h"
#include "esp_err.h"
#include "esp_log.h"
#include "touch_actions.h"
#include "wifi_manager.h"

#if __has_include("echoforest_field_config.h")
#include "echoforest_field_config.h"
#define ECHOFOREST_HAS_FIELD_CONFIG 1
#else
#define ECHOFOREST_HAS_FIELD_CONFIG 0
#endif

static const char *TAG = "echoforest_c5_app";

esp_err_t c5_app_init(const char *wifi_ssid, const char *wifi_password, const char *backend_base_url)
{
    esp_err_t err = wifi_manager_init_sta(wifi_ssid, wifi_password);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "Wi-Fi init failed: %s", esp_err_to_name(err));
        return err;
    }

    cloud_client_config_t config = { 0 };
    strlcpy(config.base_url, backend_base_url, sizeof(config.base_url));

    err = cloud_client_init(&config);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "cloud client init failed: %s", esp_err_to_name(err));
        return err;
    }

    control_screen_init();
    touch_actions_init();
    control_screen_show_network_status(wifi_manager_is_connected());
    return ESP_OK;
}

esp_err_t c5_app_init_from_field_config(void)
{
#if ECHOFOREST_HAS_FIELD_CONFIG
    return c5_app_init(
        ECHOFOREST_WIFI_SSID,
        ECHOFOREST_WIFI_PASSWORD,
        ECHOFOREST_BACKEND_BASE_URL
    );
#else
    ESP_LOGE(TAG, "echoforest_field_config.h not found");
    return ESP_ERR_NOT_FOUND;
#endif
}

void c5_app_run_once(void)
{
    echoforest_state_t state;
    echoforest_action_t action = touch_actions_read();
    esp_err_t err;

    switch (action) {
    case ECHOFOREST_ACTION_START:
        err = cloud_client_start_session("hardware study task", &state);
        break;
    case ECHOFOREST_ACTION_END:
        err = cloud_client_end_session(&state);
        break;
    case ECHOFOREST_ACTION_REST:
        err = cloud_client_start_recovery(&state);
        break;
    case ECHOFOREST_ACTION_NONE:
    default:
        err = cloud_client_get_state(&state);
        break;
    }

    bool ok = (err == ESP_OK);
    control_screen_show_network_status(wifi_manager_is_connected());
    control_screen_show_upload_status(ok);

    if (ok) {
        control_screen_show_state(&state);
    } else {
        ESP_LOGW(TAG, "backend request failed for action=%s: %s",
                 echoforest_action_to_string(action),
                 esp_err_to_name(err));
    }
}
