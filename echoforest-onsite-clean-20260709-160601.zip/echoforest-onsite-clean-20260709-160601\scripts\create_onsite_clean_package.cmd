@echo off
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo === EchoForest Clean Onsite Package Builder ===
echo.

where powershell >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: PowerShell is required to create the zip package.
  exit /b 1
)

where robocopy >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: robocopy is required to stage the package.
  exit /b 1
)

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "STAMP=%%I"

set "PACKAGE_NAME=echoforest-onsite-clean-%STAMP%"
set "STAGE_ROOT=%ROOT%\_package_tmp"
set "STAGE=%STAGE_ROOT%\%PACKAGE_NAME%"
set "ZIP_PATH=%ROOT%\..\%PACKAGE_NAME%.zip"

if exist "%STAGE%" (
  echo FAIL: staging path already exists: %STAGE%
  exit /b 1
)

mkdir "%STAGE%" >nul 2>nul
mkdir "%STAGE%\docs" >nul 2>nul
mkdir "%STAGE%\scripts" >nul 2>nul

echo Copying runtime folders...
robocopy "%ROOT%\backend" "%STAGE%\backend" /E /XD "node_modules" "dist" "build" /XF "package-lock.json" "npm-shrinkwrap.json" >nul
if %ERRORLEVEL% GEQ 8 exit /b 1
robocopy "%ROOT%\frontend" "%STAGE%\frontend" /E /XD "node_modules" "dist" "build" /XF "package-lock.json" "npm-shrinkwrap.json" >nul
if %ERRORLEVEL% GEQ 8 exit /b 1
robocopy "%ROOT%\simulator" "%STAGE%\simulator" /E /XD "node_modules" "dist" "build" /XF "package-lock.json" "npm-shrinkwrap.json" >nul
if %ERRORLEVEL% GEQ 8 exit /b 1
robocopy "%ROOT%\firmware_modules" "%STAGE%\firmware_modules" /E /XD "build" "managed_components" /XF "package-lock.json" "npm-shrinkwrap.json" >nul
if %ERRORLEVEL% GEQ 8 exit /b 1
robocopy "%ROOT%\field_config" "%STAGE%\field_config" /E /XD "_review_tmp" /XF "package-lock.json" "npm-shrinkwrap.json" >nul
if %ERRORLEVEL% GEQ 8 exit /b 1

echo Copying onsite documents...
copy "%ROOT%\README.md" "%STAGE%\README.md" >nul
copy "%ROOT%\START_HERE_ONSITE.md" "%STAGE%\START_HERE_ONSITE.md" >nul
copy "%ROOT%\DELIVERY_MANIFEST.md" "%STAGE%\DELIVERY_MANIFEST.md" >nul
copy "%ROOT%\docs\demo_script.md" "%STAGE%\docs\demo_script.md" >nul
copy "%ROOT%\docs\field_config_tool.md" "%STAGE%\docs\field_config_tool.md" >nul
copy "%ROOT%\docs\firmware_integration_plan.md" "%STAGE%\docs\firmware_integration_plan.md" >nul
copy "%ROOT%\docs\firmware_limitations_missing_info.md" "%STAGE%\docs\firmware_limitations_missing_info.md" >nul
copy "%ROOT%\docs\firmware_test_instructions.md" "%STAGE%\docs\firmware_test_instructions.md" >nul
copy "%ROOT%\docs\future_task_plan.md" "%STAGE%\docs\future_task_plan.md" >nul
copy "%ROOT%\docs\onsite_handoff_workflow.md" "%STAGE%\docs\onsite_handoff_workflow.md" >nul
copy "%ROOT%\docs\s3_base_project_inspection.md" "%STAGE%\docs\s3_base_project_inspection.md" >nul

echo Copying onsite scripts...
copy "%ROOT%\scripts\verify.cmd" "%STAGE%\scripts\verify.cmd" >nul
copy "%ROOT%\scripts\review_demo_ready.cmd" "%STAGE%\scripts\review_demo_ready.cmd" >nul
copy "%ROOT%\scripts\review_field_config.cmd" "%STAGE%\scripts\review_field_config.cmd" >nul
copy "%ROOT%\scripts\review_firmware_skeleton.cmd" "%STAGE%\scripts\review_firmware_skeleton.cmd" >nul
copy "%ROOT%\scripts\review_hardware_delivery.cmd" "%STAGE%\scripts\review_hardware_delivery.cmd" >nul
copy "%ROOT%\scripts\create_onsite_clean_package.cmd" "%STAGE%\scripts\create_onsite_clean_package.cmd" >nul

echo Checking staged package...
for %%F in (
  "START_HERE_ONSITE.md"
  "DELIVERY_MANIFEST.md"
  "backend\src\app.js"
  "frontend\src\App.jsx"
  "simulator\device_simulator.js"
  "firmware_modules\README.md"
  "field_config\configure.cmd"
  "field_config\config.local.json"
  "field_config\generated\echoforest_field_config.h"
  "docs\future_task_plan.md"
  "docs\onsite_handoff_workflow.md"
  "docs\firmware_test_instructions.md"
  "docs\firmware_limitations_missing_info.md"
  "scripts\verify.cmd"
) do (
  if not exist "%STAGE%\%%F" (
    echo FAIL: staged package missing %%F
    exit /b 1
  )
)

for %%F in (
  "AGENTS.md"
  "docs\project_agent_full_context.md"
  "docs\model_routing.md"
  "docs\openclaw_delegation.md"
  "docs\review_checklist.md"
  "docs\assumptions.md"
  "docs\open_questions.md"
  "docs\decision_log.md"
  "tasks\00_impact_map_template.md"
) do (
  if exist "%STAGE%\%%F" (
    echo FAIL: staged package contains AI/harness file %%F
    exit /b 1
  )
)

if exist "%STAGE%\package-lock.json" (
  echo FAIL: package-lock.json should not be included.
  exit /b 1
)

if exist "%STAGE%\frontend\package-lock.json" (
  echo FAIL: frontend package-lock.json should not be included.
  exit /b 1
)

if exist "%STAGE%\backend\package-lock.json" (
  echo FAIL: backend package-lock.json should not be included.
  exit /b 1
)

if exist "%ZIP_PATH%" del "%ZIP_PATH%"

echo Creating zip...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%STAGE%' -DestinationPath '%ZIP_PATH%' -Force"
if %ERRORLEVEL% neq 0 (
  echo FAIL: failed to create zip.
  exit /b 1
)

if not exist "%ZIP_PATH%" (
  echo FAIL: zip was not created.
  exit /b 1
)

echo Cleaning staging files...
rmdir /s /q "%STAGE_ROOT%" >nul 2>nul

echo.
echo PASS
echo Package: %ZIP_PATH%
exit /b 0
