#ifndef ECHOFOREST_SENSOR_MOCK_H
#define ECHOFOREST_SENSOR_MOCK_H

#include "echoforest_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

void sensor_mock_fill_focus_normal(echoforest_device_data_t *out);
void sensor_mock_fill_low_light(echoforest_device_data_t *out);
void sensor_mock_fill_noisy(echoforest_device_data_t *out);
void sensor_mock_fill_uncomfortable(echoforest_device_data_t *out);

#ifdef __cplusplus
}
#endif

#endif
