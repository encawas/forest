@echo off
setlocal enabledelayedexpansion

set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo === EchoForest Field Config Review ===
echo.

for %%F in (
  "field_config\README.md"
  "field_config\.gitignore"
  "field_config\configure.cmd"
  "field_config\apply_config.js"
  "field_config\config.local.example.json"
  "field_config\config.local.json"
  "field_config\generated\echoforest_field_config.h"
  "docs\field_config_tool.md"
) do (
  if not exist %%F (
    echo FAIL: missing %%F
    exit /b 1
  )
)

findstr /C:"config.local.json" "field_config\.gitignore" >nul || (echo FAIL: config.local.json must be ignored & exit /b 1)
findstr /C:"generated/" "field_config\.gitignore" >nul || (echo FAIL: generated output must be ignored & exit /b 1)
findstr /C:"_review_tmp/" "field_config\.gitignore" >nul || (echo FAIL: review temp dir must be ignored & exit /b 1)

findstr /C:"ECHOFOREST_WIFI_SSID" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing Wi-Fi SSID macro & exit /b 1)
findstr /C:"ECHOFOREST_WIFI_PASSWORD" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing Wi-Fi password macro & exit /b 1)
findstr /C:"ECHOFOREST_BACKEND_BASE_URL" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing backend URL macro & exit /b 1)
findstr /C:"ECHOFOREST_DHT11_PIN GPIO_NUM_0" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: DHT11 default must be GPIO_NUM_0 & exit /b 1)
findstr /C:"ECHOFOREST_LOW_LIGHT_THRESHOLD" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing light threshold & exit /b 1)
findstr /C:"ECHOFOREST_NOISE_THRESHOLD" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing noise threshold & exit /b 1)
findstr /C:"ECHOFOREST_TOUCH_START_X1" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing start touch area & exit /b 1)
findstr /C:"ECHOFOREST_TOUCH_REST_X1" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing rest touch area & exit /b 1)
findstr /C:"ECHOFOREST_TOUCH_END_X1" "field_config\generated\echoforest_field_config.h" >nul || (echo FAIL: missing end touch area & exit /b 1)

findstr /C:"12345678" "field_config\config.local.example.json" "field_config\config.local.json" "field_config\generated\echoforest_field_config.h" >nul
if %ERRORLEVEL% equ 0 (
  echo FAIL: copied real/demo Wi-Fi password found
  exit /b 1
)

findstr /I /C:"localhost" "field_config\config.local.example.json" "field_config\config.local.json" "field_config\generated\echoforest_field_config.h" >nul
if %ERRORLEVEL% equ 0 (
  echo FAIL: ESP32 backend URL must not use localhost
  exit /b 1
)

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: Node.js not found
  exit /b 1
)

node field_config\apply_config.js --check
if %ERRORLEVEL% neq 0 (
  echo FAIL: field config check failed
  exit /b 1
)

node field_config\apply_config.js --generate >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: field config generation failed
  exit /b 1
)

findstr /C:"--patch-s3-base" "field_config\apply_config.js" >nul || (echo FAIL: missing S3 patch command & exit /b 1)
findstr /C:"--patch-c5-base" "field_config\apply_config.js" >nul || (echo FAIL: missing C5 patch command & exit /b 1)

set "TMP=field_config\_review_tmp\s3_project"
if exist "field_config\_review_tmp" rmdir /s /q "field_config\_review_tmp"
mkdir "%TMP%\main"
mkdir "%TMP%\components\dht11"
mkdir "%TMP%\components\WIFISTA"
(
  echo #ifndef DHT11_H
  echo #define DHT11_H
  echo #include "driver/gpio.h"
  echo #define DHT11_DQ_GPIO_PIN GPIO_NUM_13
  echo #endif
) > "%TMP%\components\dht11\dht11.h"
(
  echo #ifndef WIFISTA_H
  echo #define WIFISTA_H
  echo #define DEFAULT_SSID "C5_AP"
  echo #define DEFAULT_PWD  "demo_password"
  echo #endif
) > "%TMP%\components\WIFISTA\wifista.h"

node field_config\apply_config.js --patch-s3-base "%TMP%" >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: S3 base patch command failed
  exit /b 1
)
findstr /C:"ECHOFOREST_DHT11_PIN" "%TMP%\components\dht11\dht11.h" >nul || (echo FAIL: DHT11 patch did not apply & exit /b 1)
findstr /C:"ECHOFOREST_WIFI_SSID" "%TMP%\components\WIFISTA\wifista.h" >nul || (echo FAIL: Wi-Fi SSID patch did not apply & exit /b 1)
findstr /C:"ECHOFOREST_WIFI_PASSWORD" "%TMP%\components\WIFISTA\wifista.h" >nul || (echo FAIL: Wi-Fi password patch did not apply & exit /b 1)
if not exist "%TMP%\main\echoforest_field_config.h" (
  echo FAIL: generated header was not copied to S3 main
  exit /b 1
)

set "C5TMP=field_config\_review_tmp\c5_project"
mkdir "%C5TMP%\main"
node field_config\apply_config.js --patch-c5-base "%C5TMP%" >nul
if %ERRORLEVEL% neq 0 (
  echo FAIL: C5 base patch command failed
  exit /b 1
)
if not exist "%C5TMP%\main\echoforest_c5_touch_bridge.h" (
  echo FAIL: C5 touch bridge was not generated
  exit /b 1
)
findstr /C:"echoforest_field_touch_action_id" "%C5TMP%\main\echoforest_c5_touch_bridge.h" >nul || (echo FAIL: C5 touch bridge missing action id helper & exit /b 1)
findstr /C:"ECHOFOREST_TOUCH_START_X1" "%C5TMP%\main\echoforest_c5_touch_bridge.h" >nul || (echo FAIL: C5 touch bridge missing configured start area & exit /b 1)

if exist "package-lock.json" (
  echo FAIL: package-lock.json exists at repo root
  exit /b 1
)

echo Git status:
git status --short --untracked-files=all
if %ERRORLEVEL% neq 0 exit /b 1

echo.
echo PASS
exit /b 0
