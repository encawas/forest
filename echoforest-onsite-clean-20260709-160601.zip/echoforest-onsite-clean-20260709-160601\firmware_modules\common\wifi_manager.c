#include "wifi_manager.h"

#include <string.h>
#include "esp_err.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "nvs_flash.h"

static const char *TAG = "echoforest_wifi";
static bool s_connected = false;

esp_err_t wifi_manager_init_sta(const char *ssid, const char *password)
{
    if (ssid == NULL || password == NULL || ssid[0] == '\0') {
        ESP_LOGE(TAG, "missing Wi-Fi SSID or password");
        return ESP_ERR_INVALID_ARG;
    }

    ESP_LOGI(TAG, "starting Wi-Fi STA integration skeleton");

    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS needs erase in target project before Wi-Fi can start");
        return err;
    }
    if (err != ESP_OK) {
        return err;
    }

    err = esp_netif_init();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        return err;
    }

    err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        return err;
    }

    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    err = esp_wifi_init(&cfg);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        return err;
    }

    wifi_config_t wifi_config = { 0 };
    strlcpy((char *)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid));
    strlcpy((char *)wifi_config.sta.password, password, sizeof(wifi_config.sta.password));

    ESP_ERROR_CHECK_WITHOUT_ABORT(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK_WITHOUT_ABORT(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    err = esp_wifi_start();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        return err;
    }

    err = esp_wifi_connect();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "Wi-Fi connect requested but not confirmed yet: %s", esp_err_to_name(err));
        s_connected = false;
        return err;
    }

    /*
     * Integration hook:
     * Real projects should register WIFI_EVENT_STA_CONNECTED,
     * WIFI_EVENT_STA_DISCONNECTED, and IP_EVENT_STA_GOT_IP handlers
     * to update this flag accurately.
     */
    s_connected = true;
    ESP_LOGI(TAG, "Wi-Fi connect requested");
    return ESP_OK;
}

bool wifi_manager_is_connected(void)
{
    return s_connected;
}
