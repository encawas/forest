import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const configSource = readFileSync(join(root, 'vite.config.js'), 'utf8');

describe('vite proxy integration contract', () => {
  it('defines a dev proxy for same-origin api paths', () => {
    assert.match(configSource, /proxy\s*:/);
    assert.match(configSource, /['"]\/api['"]\s*:/);
  });

  it('routes api requests to the local backend port', () => {
    assert.match(configSource, /target\s*:\s*['"]http:\/\/localhost:3000['"]/);
    assert.match(configSource, /changeOrigin\s*:\s*true/);
  });

  it('does not introduce forbidden integration mechanisms', () => {
    [
      'WebSocket',
      'MongoDB',
      'Prisma',
      'Redis',
      'Docker',
      'auth',
      'login',
      'OpenAI',
      'LLM',
      'camera',
    ].forEach((keyword) => {
      assert.doesNotMatch(configSource, new RegExp(keyword, 'i'));
    });
  });
});
